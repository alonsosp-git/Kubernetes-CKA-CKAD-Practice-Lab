"""Guided labs: the preloadable command scripts shipped in ``labs/``."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List, Optional

LABS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "labs")


@dataclass
class Lab:
    file: str
    title: str
    topic: str
    goal: str
    checks: List[str] = field(default_factory=list)

    @property
    def path(self) -> str:
        return os.path.join(LABS_DIR, self.file)

    def exists(self) -> bool:
        return os.path.isfile(self.path)

    def read(self) -> str:
        with open(self.path, encoding="utf-8") as handle:
            return handle.read()

    def commands(self) -> List[str]:
        return [ln.strip() for ln in self.read().splitlines()
                if ln.strip() and not ln.strip().startswith("#")]


LABS: List[Lab] = [
    Lab("01-fundamentals.kubectl", "01 - Fundamentals & first look", "introduction",
        "Explore the cluster the way you would on day one.",
        ["kubectl cluster-info reports 4 nodes",
         "you can list every resource type the API server knows"]),
    Lab("02-architecture.kubectl", "02 - Architecture & nodes", "architecture",
        "Inspect the control plane and worker nodes, their labels and taints.",
        ["control-plane node carries a NoSchedule taint",
         "worker-3 is labelled gpu=true"]),
    Lab("03-pods.kubectl", "03 - Pods", "pods",
        "Create pods imperatively and declaratively, then inspect them.",
        ["a pod appears on the topology bound to a node",
         "kubectl describe shows the scheduling event"]),
    Lab("04-deployments.kubectl", "04 - Deployments, ReplicaSets & rollouts", "deployments",
        "Watch the Deployment -> ReplicaSet -> Pod chain, scale it, roll it forward "
        "and back.",
        ["a second ReplicaSet appears during the rollout",
         "rollout undo restores the previous image"]),
    Lab("05-services.kubectl", "05 - Services & discovery", "services",
        "Expose a Deployment, inspect endpoints, and break the selector on purpose.",
        ["the Service shows 3 endpoints",
         "after breaking the selector the Service shows 0 endpoints"]),
    Lab("06-config.kubectl", "06 - ConfigMaps & Secrets", "configmaps",
        "Inject configuration as env vars and as mounted files.",
        ["kubectl exec ... -- env shows the ConfigMap values",
         "a pod referencing a missing ConfigMap stays Pending"]),
    Lab("07-namespaces.kubectl", "07 - Namespaces & quotas", "namespaces",
        "Isolate workloads and cap them with a ResourceQuota.",
        ["creating a pod over quota is rejected by admission"]),
    Lab("08-storage.kubectl", "08 - PV, PVC, StorageClass", "pvc",
        "Bind a static PV, then let a StorageClass provision one dynamically.",
        ["the static PVC binds to pv-manual",
         "the dynamic PVC gets an auto-created PV"]),
    Lab("09-statefulsets.kubectl", "09 - StatefulSets", "statefulsets",
        "Ordered pods with stable names and their own PVCs.",
        ["pods are named db-0, db-1, db-2 and start in order",
         "each pod has its own PVC"]),
    Lab("10-daemonsets.kubectl", "10 - DaemonSets", "daemonsets",
        "One pod per node, including tainted nodes when tolerated.",
        ["the DaemonSet lands a pod on every node"]),
    Lab("11-jobs.kubectl", "11 - Jobs & CronJobs", "jobs",
        "Run-to-completion workloads and scheduled ones.",
        ["the Job reaches 3/3 completions",
         "the CronJob creates Jobs as ticks advance"]),
    Lab("12-init-multicontainer.kubectl", "12 - Init containers & sidecars",
        "init-containers",
        "Pre-flight init containers and the sidecar pattern.",
        ["the pod shows Init:0/2 before it runs",
         "both containers appear in describe"]),
    Lab("13-labels.kubectl", "13 - Labels, selectors & annotations", "labels",
        "Group and target objects with labels; attach metadata with annotations.",
        ["-l selectors filter the pod list"]),
    Lab("14-scheduling.kubectl", "14 - Taints, affinity & anti-affinity", "taints",
        "Steer pods onto (and away from) specific nodes.",
        ["a pod without a toleration stays Pending on a tainted-only cluster",
         "anti-affinity spreads replicas one per node"]),
    Lab("15-resources-probes.kubectl", "15 - Requests, limits & probes", "resources",
        "Size workloads and gate traffic on readiness.",
        ["an oversized pod is Unschedulable with Insufficient cpu",
         "a failing readiness probe removes the pod from endpoints"]),
    Lab("16-autoscaling.kubectl", "16 - HPA, VPA & cluster autoscaling", "hpa",
        "Drive load into the HPA and watch replicas move.",
        ["the HPA scales up when load exceeds the target",
         "adding a node lets Pending pods schedule"]),
    Lab("17-ingress.kubectl", "17 - Ingress & controller", "ingress",
        "Route two hostnames/paths to two Services.",
        ["the Ingress shows an address once a controller exists",
         "an Ingress pointing at a missing Service is flagged"]),
    Lab("18-security.kubectl", "18 - RBAC, ServiceAccounts & NetworkPolicy", "rbac",
        "Least-privilege access, pod identity and traffic rules.",
        ["bob can list pods but cannot delete deployments",
         "auth can-i answers change with the binding"]),
    Lab("19-helm-kustomize.kubectl", "19 - Helm & Kustomize", "helm",
        "Package once, deploy per environment.",
        ["helm install creates the whole app",
         "the prod overlay renames and relabels the base"]),
    Lab("20-crds.kubectl", "20 - CRDs & operators", "crds",
        "Extend the API with your own resource kind.",
        ["kubectl get crd lists your new type"]),
    Lab("21-observability.kubectl", "21 - Metrics, logs & events", "observability",
        "The three signals you actually use during an incident.",
        ["kubectl top shows per-node utilisation"]),
    Lab("22-troubleshooting.kubectl", "22 - Troubleshooting drills", "troubleshooting",
        "Five broken workloads. Diagnose each from events and logs.",
        ["you can name the cause of every red pod on the topology"]),
    Lab("23-best-practices.kubectl", "23 - Production best practices", "best-practices",
        "Probes, limits, PDBs, anti-affinity and pinned tags together.",
        ["the production deployment satisfies every checklist item"]),
    Lab("24-cka-drills.kubectl", "24 - CKA/CKAD speed drills", "interview",
        "Timed imperative-command drills, the way the exam wants them.",
        ["you can create each object in one line"]),
    # ---- cluster administration ------------------------------------------
    Lab("25-kubeadm-upgrade.kubectl", "25 - kubeadm: join & upgrade",
        "cluster-lifecycle",
        "Upgrade a cluster in the correct order, and get refused when you don't.",
        ["upgrading a node before the control plane is rejected",
         "skipping a minor version is rejected",
         "every node ends up on the new version and Ready"]),
    Lab("26-etcd-backup.kubectl", "26 - etcd backup & restore", "etcd-backup",
        "Take a verified snapshot, destroy something, rewind the cluster.",
        ["etcdctl without the four TLS flags fails",
         "snapshot status shows hash, revision and key count",
         "the deleted Deployment and ConfigMap come back after the restore"]),
    Lab("27-certs-kubeconfig.kubectl", "27 - Certificates, CSRs & kubeconfig",
        "certificates",
        "Create a user from nothing and scope them to one namespace.",
        ["the CSR moves from Pending to Approved,Issued",
         "an approved certificate alone still gets Forbidden",
         "after the RoleBinding, alice can list pods in dev only"]),
    Lab("28-netpol-enforcement.kubectl", "28 - NetworkPolicy enforcement",
        "network-policies",
        "Watch a connection get denied, and read which policy did it.",
        ["curl succeeds before the policy and times out after it",
         "the connectivity matrix flips from ALLOW to DENY",
         "an egress policy blocks the same pod in the other direction"]),
    Lab("29-images-registry.kubectl", "29 - Images, registries & pull secrets",
        "images",
        "Every way an image pull can fail, and how to fix each one.",
        ["a locally built image cannot be pulled by a node",
         "a private image without a secret says 'pull access denied'",
         "the pod with imagePullSecrets starts normally"]),
]


def by_file(name: str) -> Optional[Lab]:
    for lab in LABS:
        if lab.file == name or lab.file.startswith(str(name).split("-")[0] + "-"):
            return lab
    return None


def by_topic(topic: str) -> List[Lab]:
    return [lab for lab in LABS if lab.topic == topic]


def available() -> List[Lab]:
    return [lab for lab in LABS if lab.exists()]
