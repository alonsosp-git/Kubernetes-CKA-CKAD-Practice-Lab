"""Export every lab as shell scripts you can run on a REAL cluster.

The labs are written against the simulator, so they contain three things that a
real cluster does not understand:

    sim ...             lab-only controls (load, chaos, tick, node up/down)
    kubeadm / etcdctl   node-level commands that need SSH onto a control plane
    docker build/push   needs a real daemon and a registry you can write to

The translator keeps every real command, rewrites paths and namespaces to shell
variables, and turns the rest into clearly-marked comments that tell you how to
achieve the same thing for real. Nothing is silently dropped.

Output bundle::

    k8s-lab-commands/
      README.md          how to run it, and what each variable means
      env.sh             every variable, with a comment explaining it
      lib.sh             helpers + aliases (k, kgp, kaf ...) and guards
      run-all.sh         runs every lab in order
      labs/01-....sh     one script per lab, runnable on its own
      manifests/*.yaml   the manifests the scripts apply
"""
from __future__ import annotations

import io
import os
import re
import zipfile
from typing import Dict, List, Optional, Tuple

from . import envsetup, handbook, labs as lab_index

# --------------------------------------------------------------------------
# the two flavours, and the folder names inside the zip
# --------------------------------------------------------------------------
FLAVOURS = ("kubernetes", "minikube")

SH_DIR = "Lab .sh scripts"
ENV_SETUP_NAME = "00-Environment Set up.sh"
CLUSTER_SETUP_NAME = "01-Minikube cluster set up.sh"
KUBECTL_DIR = "Lab .kubectl scripts"
YAML_DIR = "Lab .yaml scripts"

# what changes between a generic cluster and minikube
MINIKUBE_DEFAULTS: Dict[str, str] = {
    "KUBECTL": "minikube kubectl --",
    "STORAGE_CLASS": "standard",
    "INGRESS_CLASS": "nginx",
    "REGISTRY": "docker.io/yourname",
}


# --------------------------------------------------------------------------
# variables -- name, default, what it is for
# --------------------------------------------------------------------------
VARIABLES: List[Tuple[str, str, str]] = [
    ("KUBECTL", "kubectl",
     "The kubectl binary. On minikube you can set this to 'minikube kubectl --' "
     "to use the version that ships with your cluster."),
    ("HELM", "helm", "The helm binary, used by the packaging lab."),
    ("KUSTOMIZE", "kustomize",
     "The kustomize binary. `kubectl apply -k` works too and needs nothing extra."),
    ("NS", "k8s-lab",
     "Default namespace for everything that does not name its own. Created for "
     "you by lib.sh."),
    ("DEV_NS", "dev", "Second namespace, used by the RBAC and quota labs."),
    ("PROD_NS", "prod", "Third namespace, used by the production-practices lab."),
    ("APP", "web",
     "Name of the main demo application. The copied manifests hard-code "
     "'web', so if you change this, change it in manifests/ too (or stick "
     "to the imperative `kubectl create deployment $APP ...` steps)."),
    ("API_APP", "api",
     "Name of the second application (routing and NetworkPolicy labs). "
     "Same caveat as APP: manifests/ names it 'api'."),
    ("IMAGE", "nginx:1.25",
     "Image for the demo app. Pin a tag -- never :latest -- so rollbacks mean "
     "something."),
    ("IMAGE_NEW", "nginx:1.27",
     "The image the rollout lab upgrades to, so you can watch a rolling update."),
    ("BUSYBOX", "busybox:1.36", "Small image for Jobs, CronJobs and debug pods."),
    ("DB_IMAGE", "postgres:16", "StatefulSet image for the storage labs."),
    ("REPLICAS", "3", "Replica count for the demo Deployment."),
    ("PORT", "80", "Container/Service port for the demo app."),
    ("API_PORT", "8080", "Container/Service port for the second app."),
    ("STORAGE_CLASS", "standard",
     "StorageClass for dynamic provisioning. minikube: 'standard'. kind: "
     "'standard'. EKS: 'gp2' or 'gp3'."),
    ("INGRESS_CLASS", "nginx",
     "ingressClassName. On minikube run `minikube addons enable ingress` first."),
    ("HOST", "shop.example.com",
     "Hostname used by the Ingress lab. Add it to /etc/hosts pointing at your "
     "ingress IP to actually curl it."),
    ("REGISTRY", "docker.io/yourname",
     "Registry you can push to, for the image lab. Leave it alone to skip the "
     "push steps."),
    ("WAIT", "120s", "How long the scripts wait for a rollout before giving up."),
    ("PAUSE", "0",
     "Seconds to sleep between commands. Set to 1 or 2 to watch things happen."),
    ("ALLOW_NODE_COMMANDS", "no",
     "yes = actually run kubeadm/etcdctl steps. They need SSH onto a control "
     "plane node and will change your cluster, so they are off by default."),
    ("ALLOW_DOCKER", "no",
     "yes = actually run docker build/tag/push in the image lab."),
    ("ALLOW_DESTRUCTIVE", "no",
     "yes = allow drain, node cordon and delete-namespace steps."),
]

# extra knobs that only make sense on minikube
MINIKUBE_VARIABLES: List[Tuple[str, str, str]] = [
    ("MINIKUBE", "minikube", "The minikube binary."),
    ("PROFILE", "k8s-lab",
     "minikube profile name. Keeps this cluster separate from anything else you "
     "run: `minikube -p k8s-lab ...`."),
    ("NODES", "3",
     "How many nodes to start. The scheduling labs (taints, affinity, DaemonSets) "
     "need at least 2; 3 is comfortable."),
    ("CPUS", "2", "CPUs per node."),
    ("MEMORY", "3000", "Memory per node, in MB."),
    ("K8S_VERSION", "stable",
     "Kubernetes version for the cluster, e.g. v1.31.1 or 'stable'."),
    ("DRIVER", "",
     "minikube driver: docker, hyperkit, hyperv, kvm2... Leave empty to let "
     "minikube choose."),
    ("ADDONS", "ingress,metrics-server,default-storageclass,storage-provisioner",
     "Addons enabled by the setup script. metrics-server is what makes "
     "`kubectl top` and the HPA labs work; ingress is needed by lab 17."),
]


def variables_for(flavour: str) -> List[Tuple[str, str, str]]:
    base = [(name, MINIKUBE_DEFAULTS.get(name, default) if flavour == "minikube"
             else default, help_text) for name, default, help_text in VARIABLES]
    return (MINIKUBE_VARIABLES + base) if flavour == "minikube" else base

# lab commands -> shell, with the pieces a real cluster cannot do explained
SIM_TRANSLATIONS: Dict[str, str] = {
    "tick": "the simulator's clock. On a real cluster just wait -- "
            "`kubectl get pods -w` shows the same convergence.",
    "load": "synthetic CPU load for the HPA. For real, generate traffic: "
            "`kubectl run load --image=busybox -- /bin/sh -c "
            "'while true; do wget -q -O- http://$APP; done'`",
    "chaos": "injected failure. For real: set a bad image "
             "(`kubectl set image deploy/$APP $APP=nginx:doesnotexist`), or "
             "break the readiness probe, or `kubectl delete pod` in a loop.",
    "node": "node lifecycle. minikube: `minikube node add` / `minikube node "
            "stop <name>`; kind: `kind create cluster --config` with more nodes.",
    "rbac": "the simulator's RBAC switch. A real cluster always enforces RBAC.",
    "user": "switching identity. For real use `--as=<user>` (impersonation) or a "
            "second kubeconfig context.",
    "connectivity": "the lab's allow/deny matrix. For real, exec into a pod and "
                    "curl the others -- a denied NetworkPolicy shows as a timeout.",
    "reset": "wipes the lab cluster. For real: `kubectl delete ns $NS` (and "
             "recreate it), or tear the whole cluster down.",
    "age-certs": "fast-forwards certificate expiry, which you cannot do for real. "
                 "Check yours with `kubeadm certs check-expiration` on the node.",
    "save": "snapshots the lab state; use etcdctl on a real control plane.",
    "load-state": "restores the lab state; use etcdctl on a real control plane.",
}

_SUBS: List[Tuple[str, str]] = [
    (r"\bmanifests/([\w.-]+\.yaml)\b", r'"$MANIFESTS/\1"'),
    (r"\bcharts/webapp\b", '"$CHARTS/webapp"'),
    (r"\bkustomize/overlays/(\w+)\b", r'"$KUSTOMIZE_DIR/overlays/\1"'),
    (r"\bkustomize/base\b", '"$KUSTOMIZE_DIR/base"'),
    (r"--image=nginx:1\.25\b", "--image=$IMAGE"),
    (r"--image=nginx:1\.27\b", "--image=$IMAGE_NEW"),
    (r"=nginx:1\.27\b", "=$IMAGE_NEW"),
    (r"--image=busybox:1\.36\b", "--image=$BUSYBOX"),
    (r"\bregistry\.lab/private/", '"$REGISTRY"/'),
    (r"\bregistry\.lab/public/", '"$REGISTRY"/'),
    (r"\bregistry\.lab\b", '"$REGISTRY"'),
    (r"-n dev\b", '-n "$DEV_NS"'),
    (r"-n prod\b", '-n "$PROD_NS"'),
    (r"\bnamespace dev\b", 'namespace "$DEV_NS"'),
    (r"\bnamespace prod\b", 'namespace "$PROD_NS"'),
    (r"--namespace=dev\b", '--namespace="$DEV_NS"'),
    (r"\bdeploy/web\b", 'deploy/"$APP"'),
    (r"\bdeployment web\b", 'deployment "$APP"'),
]


def _shell_quote_comment(text: str) -> str:
    return text.replace("\\", "\\\\")


def translate_command(command: str, flavour: str = "kubernetes") -> Tuple[str, str]:
    """Return (shell_line, note). An empty shell_line means 'comment only'."""
    command = command.strip()
    program = command.split()[0] if command else ""

    if program in ("sim", "lab"):
        parts = command.split()
        action = parts[1] if len(parts) > 1 else ""
        note = SIM_TRANSLATIONS.get(action, "simulator-only command.")
        if action == "tick":
            return 'sleep "${PAUSE:-0}"', f"`{command}` -- {note}"
        # minikube can genuinely add and stop nodes, so do it for real
        if flavour == "minikube" and action == "node" and len(parts) > 3:
            name, mode = parts[2], parts[3]
            real = {"add": 'guard_destructive $MINIKUBE -p "$PROFILE" node add',
                    "remove": f'guard_destructive $MINIKUBE -p "$PROFILE" node '
                              f'delete {name}',
                    "down": f'guard_destructive $MINIKUBE -p "$PROFILE" node '
                            f'stop {name}',
                    "up": f'guard_destructive $MINIKUBE -p "$PROFILE" node '
                          f'start {name}'}.get(mode)
            if real:
                return real, (f"`{command}` -- minikube can really do this "
                              "(guarded by ALLOW_DESTRUCTIVE)")
        return "", f"`{command}` -- {note}"

    if program == "kubeadm":
        return (f"guard_node {command}",
                "needs SSH onto the control-plane node; set "
                "ALLOW_NODE_COMMANDS=yes to run it")
    if program == "etcdctl" or command.startswith("ETCDCTL_API"):
        return (f"guard_node {command}",
                "run this on the control-plane node itself, as root")
    if program == "docker":
        return (f"guard_docker {command}",
                "needs a Docker daemon and a registry you can push to")

    line = command
    for pattern, replacement in _SUBS:
        line = re.sub(pattern, replacement, line)
    line = re.sub(r"^kubectl\b", "$KUBECTL", line)
    line = re.sub(r"^helm\b", "$HELM", line)
    line = re.sub(r"^kustomize\b", "$KUSTOMIZE", line)

    if " drain " in f" {command} " or " cordon " in f" {command} " or \
            command.startswith("kubectl delete namespace"):
        return f"guard_destructive {line[len('$KUBECTL '):]}" if \
            line.startswith("$KUBECTL ") else f"guard_destructive {line}", \
            "changes your real cluster; set ALLOW_DESTRUCTIVE=yes to allow it"
    return line, ""


def lab_script(lab, index: int, flavour: str = "kubernetes") -> str:
    """One runnable .sh for one lab."""
    topic = next((handbook.TOPICS[k] for k in handbook.ORDER
                  if handbook.TOPICS[k].lab == lab.file), None)
    head = [
        "#!/usr/bin/env bash",
        f"# {lab.title}",
        f"# {lab.goal}",
    ]
    if flavour == "minikube":
        head.append("# Flavour:  minikube (run ./00-setup-minikube.sh first)")
    if topic:
        head.append(f"# Handbook: {topic.title}, page "
                    f"{', '.join(str(p) for p in topic.pages)} "
                    f"({topic.section})")
    head += [
        "#",
        "# Run me:   ./labs/%s          (or: bash labs/%s)" % (
            _script_name(lab, index), _script_name(lab, index)),
        "# Variables come from env.sh -- edit that file, not this one.",
        "",
        'set -uo pipefail',
        'HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"',
        '# shellcheck source=env.sh',
        'source "$HERE/env.sh"',
        '# shellcheck source=lib.sh',
        'source "$HERE/lib.sh"',
        "",
        f'banner "{lab.title}"',
        "",
    ]

    body: List[str] = []
    expect = False
    for raw in lab.read().splitlines():
        line = raw.strip()
        if not line:
            body.append("")
            continue
        if line.startswith("#!expect-error"):
            expect = True
            continue
        if line.startswith("#"):
            body.append("#" + line[1:])
            continue
        shell_line, note = translate_command(line, flavour)
        if note:
            body.append(f"# note: {_shell_quote_comment(note)}")
        if not shell_line:
            body.append(f"# skipped: {line}")
            continue
        if expect:
            body.append("# this one is SUPPOSED to fail -- that rejection is the lesson")
            body.append(f"expect_fail {shell_line}")
        else:
            body.append(f"step {shell_line}")
        expect = False

    tail = ["", 'note "lab finished"', ""]
    return "\n".join(head + body + tail)


def _script_name(lab, index: int) -> str:
    stem = lab.file.replace(".kubectl", "")
    return f"{stem}.sh"


def env_sh(overrides: Optional[Dict[str, str]] = None,
           flavour: str = "kubernetes") -> str:
    overrides = overrides or {}
    lines = [
        "#!/usr/bin/env bash",
        "# ---------------------------------------------------------------",
        "# env.sh -- every variable the lab scripts use, and what it means.",
        "# Edit the values here; the scripts never hard-code anything.",
        "# ---------------------------------------------------------------",
        "",
        '# Where this bundle lives (set automatically, do not edit).',
        'LAB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"',
        'MANIFESTS="${MANIFESTS:-$LAB_ROOT/manifests}"',
        'CHARTS="${CHARTS:-$LAB_ROOT/charts}"',
        'KUSTOMIZE_DIR="${KUSTOMIZE_DIR:-$LAB_ROOT/kustomize}"',
        "",
    ]
    for name, default, description in variables_for(flavour):
        value = _escape_default(overrides.get(name, default))
        for wrapped in _wrap(description, 68):
            lines.append(f"# {wrapped}")
        lines.append(f'{name}="${{{name}:-{value}}}"')
        lines.append("")
    if flavour == "minikube":
        lines += [
            '# minikube ships its own kubectl. If you would rather use a kubectl',
            '# from your PATH, set:  KUBECTL=kubectl',
            'export MINIKUBE PROFILE NODES CPUS MEMORY K8S_VERSION DRIVER ADDONS',
            '',
        ]
    lines += [
        'export KUBECTL HELM KUSTOMIZE NS DEV_NS PROD_NS APP API_APP IMAGE',
        'export IMAGE_NEW BUSYBOX DB_IMAGE REPLICAS PORT API_PORT STORAGE_CLASS',
        'export INGRESS_CLASS HOST REGISTRY WAIT PAUSE',
        'export ALLOW_NODE_COMMANDS ALLOW_DOCKER ALLOW_DESTRUCTIVE',
        'export LAB_ROOT MANIFESTS CHARTS KUSTOMIZE_DIR',
        "",
    ]
    return "\n".join(lines)


def _escape_default(value: str) -> str:
    """Make a value safe to sit inside `NAME="${NAME:-here}"`.

    Values can come from the browser (the "set your own variable names" panel),
    and inside double quotes bash still expands `$(...)`, backticks and `${...}`.
    Escaping those four characters means a value is data, never code -- the
    generated env.sh cannot be turned into a command (CWE-78 / CWE-88).
    """
    text = str(value)
    # control characters would corrupt the script; drop them outright
    text = "".join(ch for ch in text if ch == "\t" or ord(ch) >= 32)
    for char in ("\\", '"', "$", "`"):
        text = text.replace(char, "\\" + char)
    return text

def _wrap(text: str, width: int) -> List[str]:
    words, out, current = text.split(), [], ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if len(candidate) <= width:
            current = candidate
        else:
            out.append(current)
            current = word
    if current:
        out.append(current)
    return out


LIB_SH = r'''#!/usr/bin/env bash
# ---------------------------------------------------------------
# lib.sh -- helpers, aliases and guards shared by every lab script
# ---------------------------------------------------------------

BOLD=$'\033[1m'; DIM=$'\033[2m'; RED=$'\033[31m'; GREEN=$'\033[32m'
YELLOW=$'\033[33m'; CYAN=$'\033[36m'; OFF=$'\033[0m'

banner() { printf '\n%s=== %s ===%s\n\n' "$BOLD$CYAN" "$1" "$OFF"; }
note()   { printf '%s# %s%s\n' "$DIM" "$*" "$OFF"; }
ok()     { printf '%s%s%s\n' "$GREEN" "$*" "$OFF"; }
warn()   { printf '%s%s%s\n' "$YELLOW" "$*" "$OFF"; }
fail()   { printf '%s%s%s\n' "$RED" "$*" "$OFF"; }

# step <command...>  -- echo it, run it, keep going if it fails
step() {
  printf '%s$ %s%s\n' "$CYAN" "$*" "$OFF"
  "$@"
  local code=$?
  [ "$code" -ne 0 ] && fail "  ^ exited $code (continuing)"
  [ "${PAUSE:-0}" != "0" ] && sleep "$PAUSE"
  return 0
}

# expect_fail <command...> -- this command is supposed to be rejected
expect_fail() {
  printf '%s$ %s%s\n' "$CYAN" "$*" "$OFF"
  if "$@" 2>&1; then
    warn "  ^ this was expected to FAIL but succeeded -- your cluster may be"
    warn "    more permissive than the lab assumes"
  else
    ok   "  ^ rejected, as intended: that rejection is the lesson"
  fi
  [ "${PAUSE:-0}" != "0" ] && sleep "$PAUSE"
  return 0
}

# guards for anything that needs more than a kubeconfig
guard_node() {
  if [ "${ALLOW_NODE_COMMANDS:-no}" = "yes" ]; then step "$@"; else
    warn "skipped (ALLOW_NODE_COMMANDS=no): $*"
    note "run this on the control-plane node itself"
  fi
}
guard_docker() {
  if [ "${ALLOW_DOCKER:-no}" = "yes" ]; then step "$@"; else
    warn "skipped (ALLOW_DOCKER=no): $*"
  fi
}
guard_destructive() {
  if [ "${ALLOW_DESTRUCTIVE:-no}" = "yes" ]; then step "$@"; else
    warn "skipped (ALLOW_DESTRUCTIVE=no): $*"
  fi
}

# short aliases, the way you would set them up before a CKA exam.
# (aliases need interactive shells, so these are functions -- same effect.)
k()    { $KUBECTL "$@"; }
kg()   { $KUBECTL get "$@"; }
kgp()  { $KUBECTL get pods "$@"; }
kd()   { $KUBECTL describe "$@"; }
kaf()  { $KUBECTL apply -f "$@"; }
kdel() { $KUBECTL delete "$@"; }
kl()   { $KUBECTL logs "$@"; }
kx()   { $KUBECTL exec -it "$@"; }
kns()  { $KUBECTL config set-context --current --namespace="$1"; }
h()    { $HELM "$@"; }

# wait_ready deploy/web  -- block until a rollout finishes
wait_ready() { $KUBECTL rollout status "$1" --timeout="${WAIT:-120s}" || true; }

# make sure the namespaces exist and we are pointed at the right one
lab_setup() {
  for ns in "$NS" "$DEV_NS" "$PROD_NS"; do
    $KUBECTL get namespace "$ns" >/dev/null 2>&1 || \
      $KUBECTL create namespace "$ns" >/dev/null
  done
  $KUBECTL config set-context --current --namespace="$NS" >/dev/null
  note "namespace: $NS   (dev: $DEV_NS, prod: $PROD_NS)"
}

preflight() {
  command -v "${KUBECTL%% *}" >/dev/null 2>&1 || {
    fail "kubectl not found. Install it, or set KUBECTL in env.sh"; exit 1; }
  $KUBECTL cluster-info >/dev/null 2>&1 || {
    fail "no reachable cluster. Start one first:"
    note "  minikube start --nodes 3"
    note "  kind create cluster"
    exit 1; }
  ok "connected to: $($KUBECTL config current-context)"
  lab_setup
}
'''


MINIKUBE_SETUP = r'''#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# 01-Minikube cluster set up.sh -- run me after "00-Environment Set up.sh".
#
# Starts a multi-node minikube profile, enables the addons the labs need, wires
# kubectl/helm/docker to it, and writes aliases.sh for your own shell.
# Safe to re-run: if the profile is already up it just re-checks everything.
# ---------------------------------------------------------------------------
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/env.sh"
source "$HERE/lib.sh"

banner "minikube setup: profile '$PROFILE'"

command -v "$MINIKUBE" >/dev/null 2>&1 || {
  fail "minikube not found."
  note "install it: https://minikube.sigs.k8s.io/docs/start/"
  exit 1; }

# --- 1. start (or reuse) the cluster ---------------------------------------
if $MINIKUBE -p "$PROFILE" status >/dev/null 2>&1; then
  ok "profile '$PROFILE' is already running"
else
  note "starting $NODES node(s), ${CPUS} cpu / ${MEMORY}MB each, kubernetes $K8S_VERSION"
  driver_flag=""
  [ -n "${DRIVER:-}" ] && driver_flag="--driver=$DRIVER"
  step $MINIKUBE start -p "$PROFILE" --nodes "$NODES" --cpus "$CPUS"       --memory "$MEMORY" --kubernetes-version "$K8S_VERSION" $driver_flag
fi

# --- 2. addons the labs depend on ------------------------------------------
#   ingress          -> lab 17 (Ingress + controller)
#   metrics-server   -> kubectl top, and the HPA labs (16)
#   default-storageclass + storage-provisioner -> the storage labs (08, 09)
IFS=',' read -ra WANTED <<< "$ADDONS"
for addon in "${WANTED[@]}"; do
  [ -z "$addon" ] && continue
  step $MINIKUBE -p "$PROFILE" addons enable "$addon"
done

# --- 3. point everything at this profile ------------------------------------
step $MINIKUBE -p "$PROFILE" update-context
note "kubectl in these scripts is: $KUBECTL"

# --- 4. build images straight into the cluster ------------------------------
# With this, `docker build` puts the image where the kubelet can already see it,
# so lab 29 works without pushing to a registry.
if command -v docker >/dev/null 2>&1; then
  note "run this in your shell to build images into minikube:"
  note "    eval \$($MINIKUBE -p $PROFILE docker-env)"
fi

# --- 5. aliases for YOUR shell ----------------------------------------------
cat > "$HERE/aliases.sh" <<EOF
# source me:   source aliases.sh
# Everything below points at the '$PROFILE' minikube profile.
alias kubectl='$MINIKUBE -p $PROFILE kubectl --'
alias k='$MINIKUBE -p $PROFILE kubectl --'
alias kg='k get'
alias kgp='k get pods'
alias kgpw='k get pods -o wide'
alias kd='k describe'
alias kaf='k apply -f'
alias kdel='k delete'
alias kl='k logs'
alias kx='k exec -it'
alias kns='k config set-context --current --namespace'
alias kctx='k config current-context'
alias helm='helm --kube-context $PROFILE'
alias h='helm --kube-context $PROFILE'
alias mk='$MINIKUBE -p $PROFILE'
alias mkip='$MINIKUBE -p $PROFILE ip'
alias mkdash='$MINIKUBE -p $PROFILE dashboard'
alias mkdocker='eval \$($MINIKUBE -p $PROFILE docker-env)'
export do='--dry-run=client -o yaml'      # kubectl create deploy x \$do
EOF
ok "wrote aliases.sh"

# --- 6. show what you have --------------------------------------------------
step $KUBECTL get nodes -o wide
lab_setup
ok "cluster ready. Now run:  ./run-all.sh    (or ./labs/04-deployments.sh)"
note "in your own shell:  source aliases.sh   then use  k get pods"
note "ingress host: add '$($MINIKUBE -p "$PROFILE" ip 2>/dev/null || echo "<minikube ip>") $HOST' to /etc/hosts"
'''


def run_all_sh(labs, flavour: str = "kubernetes") -> str:
    lines = [
        "#!/usr/bin/env bash",
        "# Run every lab in order, on a real cluster.",
        "#",
        "#   ./run-all.sh              run them all",
        '#   run "00-Environment Set up.sh" once first if you have no tools yet;'
        if flavour == "minikube" else
        "#   (a cluster must already be reachable -- kubectl cluster-info)",
        '#   "01-Minikube cluster set up.sh" then starts the cluster for you.'
        if flavour == "minikube" else "#",
        "#   ./run-all.sh 4 5 6        run only labs 4, 5 and 6",
        "#   PAUSE=2 ./run-all.sh      slow it down so you can watch",
        "",
        "set -uo pipefail",
        'HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"',
        'source "$HERE/env.sh"',
        'source "$HERE/lib.sh"',
        "",
        ('preflight' if flavour != "minikube" else
         'bash "$HERE/01-Minikube cluster set up.sh" || exit 1\npreflight'),
        "",
        "declare -a SCRIPTS=(",
    ]
    for index, lab in enumerate(labs, start=1):
        lines.append(f'  "labs/{_script_name(lab, index)}"')
    lines += [
        ")",
        "",
        'wanted=("$@")',
        'for i in "${!SCRIPTS[@]}"; do',
        '  number=$((i + 1))',
        '  if [ ${#wanted[@]} -gt 0 ]; then',
        '    match=no',
        '    for w in "${wanted[@]}"; do [ "$w" = "$number" ] && match=yes; done',
        '    [ "$match" = "no" ] && continue',
        '  fi',
        '  bash "$HERE/${SCRIPTS[$i]}"',
        'done',
        "",
        'banner "all done"',
        'note "clean up with:  kubectl delete namespace $NS $DEV_NS $PROD_NS"',
        "",
    ]
    return "\n".join(lines)


def readme(overrides: Optional[Dict[str, str]] = None,
           flavour: str = "kubernetes") -> str:
    overrides = overrides or {}
    rows = "\n".join(
        f"| `{name}` | `{overrides.get(name, default)}` | {description} |"
        for name, default, description in variables_for(flavour))
    if flavour == "minikube":
        quick = """```bash
# 0. one script does the whole setup: starts minikube, enables the addons,
#    and wires kubectl/helm to it
./00-setup-minikube.sh

# 1. run the labs
./run-all.sh                      # or ./labs/04-deployments.sh
```

`00-setup-minikube.sh` starts a `$NODES`-node profile called `$PROFILE`, enables
ingress + metrics-server + the storage provisioner, points your shell's docker at
minikube's daemon (so `docker build` images are visible to the cluster without a
push), and writes `aliases.sh` -- `source aliases.sh` in your own shell to get
`kubectl`, `k`, `helm` and friends pointing at this profile."""
    else:
        quick = """```bash
# 1. have a cluster
minikube start --nodes 3          # or: kind create cluster
minikube addons enable ingress    # only needed for the Ingress lab

# 2. check the settings
$EDITOR env.sh                    # namespace, images, registry, ...

# 3. run everything
chmod +x run-all.sh labs/*.sh
./run-all.sh

# or one lab at a time
./labs/04-deployments.sh
PAUSE=2 ./run-all.sh 4 5 6        # slower, only those three
```"""
    return f"""# k8s-practice-lab -- the same exercises, on a real cluster

Every lab from the simulator, translated into plain shell scripts that run
against any Kubernetes cluster: minikube, kind, k3s, EKS/GKE/AKS.

## Quick start

{quick}

Clean up with `kubectl delete namespace $NS $DEV_NS $PROD_NS`.

## What the scripts assume

Nothing is hard-coded: every name, image, port and namespace is a variable in
`env.sh`, and `lib.sh` provides the helpers.

| Variable | Default | What it is |
|---|---|---|
{rows}

Set any of them from the environment instead of editing the file:

```bash
NS=my-lab IMAGE=nginx:1.27 ./labs/04-deployments.sh
```

## Aliases

`lib.sh` defines the short forms people set up before a CKA exam. They are
functions rather than aliases so they work in non-interactive scripts:

| Helper | Expands to |
|---|---|
| `k` | `kubectl` |
| `kg` / `kgp` | `kubectl get` / `kubectl get pods` |
| `kd` | `kubectl describe` |
| `kaf` | `kubectl apply -f` |
| `kdel` | `kubectl delete` |
| `kl` / `kx` | `kubectl logs` / `kubectl exec -it` |
| `kns <name>` | switch the current namespace |
| `h` | `helm` |
| `wait_ready deploy/web` | `kubectl rollout status ... --timeout=$WAIT` |

For your own interactive shell:

```bash
alias k=kubectl
complete -o default -F __start_kubectl k     # bash completion
export do="--dry-run=client -o yaml"         # kubectl create deploy x $do
```

## Steps that are guarded

Three kinds of command need more than a kubeconfig, so they are switched off by
default. Turn them on in `env.sh` when you are ready:

| Guard | Covers | Turn on with |
|---|---|---|
| `ALLOW_NODE_COMMANDS` | `kubeadm`, `etcdctl` — run these on the control-plane node itself | `ALLOW_NODE_COMMANDS=yes` |
| `ALLOW_DOCKER` | `docker build/tag/push` — needs a daemon and a registry you can write to | `ALLOW_DOCKER=yes` |
| `ALLOW_DESTRUCTIVE` | `drain`, `cordon`, `delete namespace` | `ALLOW_DESTRUCTIVE=yes` |

Simulator-only commands (`sim load`, `sim chaos`, `sim tick`, ...) appear as
comments explaining how to get the same effect for real — for example, driving
the HPA with a real load generator instead of a synthetic number.

## Expected failures

Some steps are meant to be rejected (a Deployment whose selector does not match
its template labels, an etcdctl call missing its TLS flags). Those run through
`expect_fail`, which prints a green "rejected, as intended" and keeps going. If
one of them *succeeds* on your cluster you get a warning instead — worth
investigating.
"""


# --------------------------------------------------------------------------
def build_full_bundle(base_dir: Optional[str] = None,
                      flavour: str = "kubernetes") -> bytes:
    """Everything in ONE download, for one flavour of cluster.

        k8s-labs-<flavour>/
          START-HERE.md
          Lab .sh scripts/       runnable bash  (run-all.sh, labs/*.sh, env.sh)
          Lab .yaml scripts/     one labelled manifest per topic
          Lab .kubectl scripts/  the originals, for this app's terminal
    """
    if flavour not in FLAVOURS:
        flavour = "kubernetes"
    base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    labs = [lab for lab in lab_index.LABS if lab.exists()]
    buffer = io.BytesIO()
    root = f"k8s-labs-{flavour}"

    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(f"{root}/START-HERE.md", _start_here(labs, flavour))

        # --- Lab .sh scripts: runnable on a real cluster -------------------
        sh_root = f"{root}/{SH_DIR}"
        archive.writestr(f"{sh_root}/README.md", readme(None, flavour))
        archive.writestr(f"{sh_root}/env.sh", env_sh(None, flavour))
        archive.writestr(f"{sh_root}/lib.sh", LIB_SH)
        archive.writestr(f"{sh_root}/run-all.sh", run_all_sh(labs, flavour))
        archive.writestr(f"{sh_root}/{ENV_SETUP_NAME}",
                         envsetup.environment_setup(flavour))
        if flavour == "minikube":
            archive.writestr(f"{sh_root}/{CLUSTER_SETUP_NAME}", MINIKUBE_SETUP)
        for index, lab in enumerate(labs, start=1):
            archive.writestr(f"{sh_root}/labs/{_script_name(lab, index)}",
                             lab_script(lab, index, flavour))
        for folder in ("manifests", "charts", "kustomize"):
            source = os.path.join(base_dir, folder)
            if not os.path.isdir(source):
                continue
            for current, _dirs, files in os.walk(source):
                for name in files:
                    if not name.endswith((".yaml", ".yml")):
                        continue
                    full = os.path.join(current, name)
                    relative = os.path.relpath(full, base_dir)
                    with open(full, encoding="utf-8") as handle:
                        archive.writestr(f"{sh_root}/{relative}", handle.read())

        # --- Lab .yaml scripts: one labelled manifest per topic -------------
        index_lines = ["# one manifest per handbook topic", ""]
        for key in handbook.ORDER:
            topic = handbook.TOPICS[key]
            name = handbook.manifest_filename(topic)
            archive.writestr(f"{root}/{YAML_DIR}/{name}",
                             handbook.manifest_for(topic))
            index_lines.append(f"{name}\n    {topic.title} | {topic.section} | "
                               f"lab {topic.lab_number or '-'} | page {topic.pages[0]}")
        archive.writestr(f"{root}/{YAML_DIR}/INDEX.txt", "\n".join(index_lines))

        # --- Lab .kubectl scripts: the simulator originals ------------------
        for lab in labs:
            archive.writestr(f"{root}/{KUBECTL_DIR}/{lab.file}", lab.read())
        archive.writestr(f"{root}/{KUBECTL_DIR}/README.txt",
                         "These are the scripts this app's terminal runs.\n"
                         "Paste one into the YAML/Script tab and press "
                         "'Run as commands', or:\n\n"
                         "    python k8s_lab.py --cli --script "
                         "labs/04-deployments.kubectl\n")
    return buffer.getvalue()


def _start_here(labs, flavour: str = "kubernetes") -> str:
    rows = "\n".join(f"| {index:02d} | {lab.title.split(' - ', 1)[-1]} | "
                      f"`{_script_name(lab, index)}` |"
                      for index, lab in enumerate(labs, start=1))
    if flavour == "minikube":
        how = f"""## Three commands

```bash
cd "{SH_DIR}"
chmod +x *.sh labs/*.sh
./"{ENV_SETUP_NAME}"       # installs minikube, kubectl, helm, kustomize + aliases
source aliases.sh          # kubectl / k / helm now target this profile
./"{CLUSTER_SETUP_NAME}"   # starts the 3-node cluster and its addons
./run-all.sh               # or ./labs/04-deployments.sh
```

`"{CLUSTER_SETUP_NAME}"` does the cluster half for you:

* starts a **$NODES-node** profile called **$PROFILE** (the scheduling, taint and
  DaemonSet labs need more than one node)
* enables **ingress** (lab 17), **metrics-server** (`kubectl top` and the HPA
  labs), and the **storage provisioner** (labs 08-09)
* runs `minikube update-context` so kubectl points at this profile
* writes **`aliases.sh`** -- `source aliases.sh` in your own shell and then
  `kubectl`, `k`, `kgp`, `helm`, `mk`... all target this profile:

```bash
source aliases.sh
k get pods              # = minikube -p k8s-lab kubectl -- get pods
kgp -A                  # every pod, every namespace
mkdocker                # build images straight into the cluster (lab 29)
mkip                    # the ingress IP for /etc/hosts
```

Tear it down with `minikube -p $PROFILE delete`."""
    else:
        how = f"""## Three commands

```bash
cd "{SH_DIR}"
chmod +x *.sh labs/*.sh
./"{ENV_SETUP_NAME}"              # installs kubectl, helm, kustomize + aliases
source aliases.sh
kubectl cluster-info              # point this at a cluster you already have
./run-all.sh                      # or ./run-all.sh 4 5 6
```

A cluster must already be reachable (`kubectl cluster-info`). If you use
minikube, take the **minikube** zip instead -- it starts the cluster, enables the
addons and sets the aliases up for you.

Clean up with `kubectl delete namespace $NS $DEV_NS $PROD_NS`."""

    return f"""# k8s-practice-lab -- all {len(labs)} labs ({flavour})

```
{SH_DIR}/        runnable bash: run-all.sh, labs/*.sh, env.sh, lib.sh
{YAML_DIR}/      one labelled manifest per topic  (kubectl apply -f)
{KUBECTL_DIR}/   the originals, for this app's own terminal
```

{how}

## Settings

Everything is a variable in `{SH_DIR}/env.sh`, each with a comment explaining
what it is for -- namespace, app names, images, registry, storage class, ingress
class, timeouts. Override per run instead if you prefer:

```bash
NS=my-lab IMAGE=nginx:1.27 ./run-all.sh
```

Steps that need more than a kubeconfig are off by default: `kubeadm`/`etcdctl`
(`ALLOW_NODE_COMMANDS=yes`), `docker build/push` (`ALLOW_DOCKER=yes`), and
`drain`/node changes/`delete namespace` (`ALLOW_DESTRUCTIVE=yes`). Simulator-only
steps appear as comments explaining how to get the same effect for real. Steps
that are *meant* to fail report "rejected, as intended" and carry on.

## The labs

| # | Lab | Script |
|---|-----|--------|
{rows}
"""


def build_bundle(overrides: Optional[Dict[str, str]] = None,
                 base_dir: Optional[str] = None) -> bytes:
    """The whole thing as a zip."""
    base_dir = base_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    labs = [lab for lab in lab_index.LABS if lab.exists()]
    buffer = io.BytesIO()
    root = "k8s-lab-commands"

    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(f"{root}/README.md", readme(overrides))
        archive.writestr(f"{root}/env.sh", env_sh(overrides))
        archive.writestr(f"{root}/lib.sh", LIB_SH)
        archive.writestr(f"{root}/run-all.sh", run_all_sh(labs))
        for index, lab in enumerate(labs, start=1):
            archive.writestr(f"{root}/labs/{_script_name(lab, index)}",
                             lab_script(lab, index))
        for folder in ("manifests", "charts", "kustomize"):
            source = os.path.join(base_dir, folder)
            if not os.path.isdir(source):
                continue
            for current, _dirs, files in os.walk(source):
                for name in files:
                    if not name.endswith((".yaml", ".yml")):
                        continue
                    full = os.path.join(current, name)
                    relative = os.path.relpath(full, base_dir)
                    with open(full, encoding="utf-8") as handle:
                        archive.writestr(f"{root}/{relative}", handle.read())
        index_lines = ["# labs in this bundle", ""]
        for index, lab in enumerate(labs, start=1):
            index_lines.append(f"{index:>2}. labs/{_script_name(lab, index)}"
                               f"\n    {lab.title}\n    {lab.goal}")
        archive.writestr(f"{root}/INDEX.txt", "\n".join(index_lines))
    return buffer.getvalue()
