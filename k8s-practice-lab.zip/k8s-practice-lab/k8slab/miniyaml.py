"""Minimal YAML subset parser/dumper.

Uses PyYAML when available, otherwise falls back to a hand-rolled parser that
covers the subset of YAML used in Kubernetes manifests:

  * multi-document streams (``---``)
  * nested mappings and sequences by indentation
  * inline flow collections ``[a, b]`` / ``{a: b}``
  * quoted strings, ints, floats, bools, null
  * block scalars ``|`` and ``>`` (with ``-`` / ``+`` chomping)
  * ``#`` comments

This keeps the lab a zero-dependency, pure-stdlib program.
"""
from __future__ import annotations

import re
from typing import Any, List

from . import security

try:  # pragma: no cover - environment dependent
    import yaml as _pyyaml
except Exception:  # pragma: no cover
    _pyyaml = None


class YamlError(ValueError):
    """Raised when a manifest cannot be parsed."""


#: Nesting ceiling, enforced whichever backend parses (see _check_depth).
MAX_DEPTH = security.MAX_YAML_DEPTH


# --------------------------------------------------------------------------
# scalar handling
# --------------------------------------------------------------------------
_INT_RE = re.compile(r"^[-+]?\d+$")
_FLOAT_RE = re.compile(r"^[-+]?(\d+\.\d*|\.\d+|\d+[eE][-+]?\d+|\d+\.\d+[eE][-+]?\d+)$")


def _scalar(raw: str) -> Any:
    text = raw.strip()
    if not text:
        return None
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "'\"":
        body = text[1:-1]
        if text[0] == '"':
            body = (body.replace("\\n", "\n").replace("\\t", "\t")
                        .replace('\\"', '"').replace("\\\\", "\\"))
        else:
            body = body.replace("''", "'")
        return body
    low = text.lower()
    if low in ("null", "~"):
        return None
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if _INT_RE.match(text):
        return int(text)
    if _FLOAT_RE.match(text):
        return float(text)
    return text


def _split_flow(body: str) -> List[str]:
    """Split a flow collection body on top-level commas."""
    parts, depth, quote, buf = [], 0, None, []
    for ch in body:
        if quote:
            buf.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch
            buf.append(ch)
        elif ch in "[{":
            depth += 1
            buf.append(ch)
        elif ch in "]}":
            depth -= 1
            buf.append(ch)
        elif ch == "," and depth == 0:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    if "".join(buf).strip():
        parts.append("".join(buf))
    return [p.strip() for p in parts]


def _parse_flow(text: str) -> Any:
    text = text.strip()
    if text.startswith("[") and text.endswith("]"):
        return [_parse_flow(p) for p in _split_flow(text[1:-1])]
    if text.startswith("{") and text.endswith("}"):
        out = {}
        for piece in _split_flow(text[1:-1]):
            if ":" in piece:
                key, _, val = piece.partition(":")
                out[str(_scalar(key))] = _parse_flow(val)
            elif piece:
                out[str(_scalar(piece))] = None
        return out
    return _scalar(text)


def _strip_comment(line: str) -> str:
    """Remove a trailing ``#`` comment that is not inside quotes."""
    quote = None
    for i, ch in enumerate(line):
        if quote:
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch == "#" and (i == 0 or line[i - 1] in " \t"):
            return line[:i]
    return line


# --------------------------------------------------------------------------
# line model
# --------------------------------------------------------------------------
class _Line:
    __slots__ = ("indent", "text", "no", "raw")

    def __init__(self, no: int, raw: str):
        self.no = no
        self.raw = raw
        stripped = raw.lstrip(" ")
        self.indent = len(raw) - len(stripped)
        self.text = stripped.rstrip()


def _tokenize(source: str) -> List[_Line]:
    lines = []
    for no, raw in enumerate(source.replace("\t", "    ").splitlines(), start=1):
        if not raw.strip():
            continue
        cleaned = _strip_comment(raw).rstrip()
        if not cleaned.strip():
            continue
        lines.append(_Line(no, cleaned))
    return lines


class _Parser:
    def __init__(self, lines: List[_Line]):
        self.lines = lines
        self.i = 0
        self.depth = 0

    def peek(self):
        return self.lines[self.i] if self.i < len(self.lines) else None

    # -- recursion guard (CWE-674) ----------------------------------------
    #
    # parse_map and parse_seq call each other for every level of nesting, so a
    # manifest indented a few thousand levels deep would exhaust the Python
    # stack and take the process (or the web server thread) down with it. A
    # depth ceiling turns that into an ordinary parse error.
    def _enter(self) -> None:
        self.depth += 1
        if self.depth > MAX_DEPTH:
            raise YamlError(
                f"YAML is nested more than {MAX_DEPTH} levels deep; "
                "refusing to parse it.")

    def _leave(self) -> None:
        self.depth -= 1

    # -- block scalars ----------------------------------------------------
    def _block_scalar(self, header: str, parent_indent: int) -> str:
        fold = header.startswith(">")
        chomp = "clip"
        if header.endswith("-"):
            chomp = "strip"
        elif header.endswith("+"):
            chomp = "keep"
        body, base = [], None
        while (line := self.peek()) is not None and line.indent > parent_indent:
            if base is None:
                base = line.indent
            body.append(" " * max(0, line.indent - base) + line.text)
            self.i += 1
        if fold:
            out, buf = [], []
            for entry in body:
                if entry.strip() == "":
                    out.append(" ".join(buf))
                    buf = []
                    out.append("")
                elif entry.startswith(" "):
                    if buf:
                        out.append(" ".join(buf))
                        buf = []
                    out.append(entry)
                else:
                    buf.append(entry.strip())
            if buf:
                out.append(" ".join(buf))
            text = "\n".join(out)
        else:
            text = "\n".join(body)
        if chomp == "strip":
            return text.rstrip("\n")
        return text + "\n" if text else text

    # -- collections ------------------------------------------------------
    def parse_block(self, indent: int) -> Any:
        line = self.peek()
        if line is None or line.indent < indent:
            return None
        self._enter()
        try:
            return self.parse_seq(indent) \
                if line.text.startswith("- ") or line.text == "-" \
                else self.parse_map(indent)
        finally:
            self._leave()

    def parse_seq(self, indent: int) -> List[Any]:
        items: List[Any] = []
        while (line := self.peek()) is not None and line.indent == indent and \
                (line.text.startswith("- ") or line.text == "-"):
            self.i += 1
            rest = line.text[1:].strip()
            if not rest:
                items.append(self.parse_block(self._next_indent(indent)))
                continue
            if rest.startswith(("[", "{")):
                items.append(_parse_flow(rest))
                continue
            # "- key: value" starts a nested map at a virtual indent
            key_match = re.match(r"^([^:#]+?):(\s+.*|)$", rest)
            if key_match:
                virtual = indent + 2
                synthetic = _Line(line.no, " " * virtual + rest)
                self.lines.insert(self.i, synthetic)
                items.append(self.parse_map(virtual))
            else:
                items.append(_scalar(rest))
        return items

    def _next_indent(self, indent: int) -> int:
        nxt = self.peek()
        return nxt.indent if nxt and nxt.indent > indent else indent + 2

    def parse_map(self, indent: int) -> Any:
        self._enter()
        try:
            return self._parse_map(indent)
        finally:
            self._leave()

    def _parse_map(self, indent: int) -> Any:
        out: dict = {}
        while (line := self.peek()) is not None and line.indent == indent:
            if line.text.startswith("- "):
                break
            match = re.match(r"^(\??\s*[^:]+?)\s*:(\s.*|)$", line.text)
            if not match:
                if line.text.endswith(":"):
                    match = re.match(r"^([^:]+):$", line.text)
                    if match:
                        key, rest = match.group(1).strip(), ""
                    else:
                        raise YamlError(f"line {line.no}: cannot parse {line.text!r}")
                else:
                    raise YamlError(f"line {line.no}: cannot parse {line.text!r}")
            else:
                key, rest = match.group(1).strip(), match.group(2).strip()
            key = str(_scalar(key))
            self.i += 1
            if rest.startswith(("|", ">")):
                out[key] = self._block_scalar(rest, indent)
            elif rest.startswith(("[", "{")):
                out[key] = _parse_flow(rest)
            elif rest:
                out[key] = _scalar(rest)
            else:
                nxt = self.peek()
                if nxt is not None and nxt.indent > indent:
                    out[key] = self.parse_block(nxt.indent)
                elif nxt is not None and nxt.indent == indent and nxt.text.startswith("- "):
                    out[key] = self.parse_seq(indent)
                else:
                    out[key] = None
        return out


def _check_size(source: str) -> None:
    """Refuse absurd input before we start allocating for it (CWE-400/CWE-776).

    A YAML document is untrusted input here: it arrives from the editor pane in
    the browser, from `kubectl apply -f`, and from Helm/Kustomize rendering.
    Bounding length and line count first means the expensive parse only ever
    runs on something plausible.
    """
    if not isinstance(source, str):
        raise YamlError("YAML input must be text")
    if len(source) > security.MAX_YAML_BYTES:
        raise YamlError(f"YAML document is larger than "
                        f"{security.MAX_YAML_BYTES // 1024} KiB")
    if source.count("\n") > security.MAX_YAML_LINES:
        raise YamlError(f"YAML document has more than "
                        f"{security.MAX_YAML_LINES} lines")


def _check_depth(value: Any, depth: int = 0) -> None:
    """Reject absurdly nested results, whichever parser produced them.

    The hand-rolled parser guards its own recursion, but PyYAML happily builds
    a structure thousands of levels deep -- and then *our* code (the renderer,
    the dumper, the topology walker) is what blows the stack. Checking the
    result means the ceiling holds no matter which backend ran (CWE-674).
    """
    if depth > MAX_DEPTH:
        raise YamlError(f"YAML is nested more than {MAX_DEPTH} levels deep; "
                        "refusing to parse it.")
    if isinstance(value, dict):
        for item in value.values():
            _check_depth(item, depth + 1)
    elif isinstance(value, list):
        for item in value:
            _check_depth(item, depth + 1)


def load_all(source: str) -> List[Any]:
    """Parse a (possibly multi-document) YAML string into python objects."""
    _check_size(source)
    if _pyyaml is not None:
        try:
            # safe_load_all never constructs arbitrary Python objects, so a
            # manifest cannot reach `!!python/object/apply` (CWE-502).
            docs = [d for d in _pyyaml.safe_load_all(source) if d is not None]
        except YamlError:
            raise
        except RecursionError as exc:
            raise YamlError("YAML is nested too deeply to parse") from exc
        except Exception as exc:  # pragma: no cover
            raise YamlError(str(exc)) from exc
        for doc in docs:
            _check_depth(doc)
        return docs
    docs, current = [], []
    for raw in source.splitlines():
        if raw.strip() in ("---", "--- "):
            docs.append("\n".join(current))
            current = []
        elif raw.strip() == "...":
            continue
        else:
            current.append(raw)
    docs.append("\n".join(current))
    parsed = []
    for doc in docs:
        lines = _tokenize(doc)
        if not lines:
            continue
        parser = _Parser(lines)
        value = parser.parse_block(lines[0].indent)
        if value is not None:
            parsed.append(value)
    return parsed


def load(source: str) -> Any:
    docs = load_all(source)
    return docs[0] if docs else None


# --------------------------------------------------------------------------
# dumper (always hand rolled so output formatting is stable/pretty)
# --------------------------------------------------------------------------
_PLAIN_RE = re.compile(r"^[A-Za-z0-9_./+=@-]+$")


def _fmt_scalar(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    if text == "":
        return '""'
    if "\n" in text:
        return None  # handled by caller as block scalar
    if _PLAIN_RE.match(text) and text.lower() not in (
            "true", "false", "null", "yes", "no", "on", "off"):
        return text
    return '"%s"' % text.replace("\\", "\\\\").replace('"', '\\"')


def dump(obj: Any, indent: int = 0) -> str:
    """Serialise ``obj`` to a readable YAML string."""
    pad = " " * indent
    if isinstance(obj, dict):
        if not obj:
            return pad + "{}\n"
        out = []
        for key, val in obj.items():
            if isinstance(val, dict) and val:
                out.append(f"{pad}{key}:\n{dump(val, indent + 2)}")
            elif isinstance(val, list) and val:
                out.append(f"{pad}{key}:\n{dump(val, indent + 2)}")
            elif isinstance(val, (dict, list)):
                out.append(f"{pad}{key}: {'{}' if isinstance(val, dict) else '[]'}\n")
            else:
                scalar = _fmt_scalar(val)
                if scalar is None:
                    body = "\n".join(f"{pad}  {ln}" for ln in str(val).splitlines())
                    out.append(f"{pad}{key}: |\n{body}\n")
                else:
                    out.append(f"{pad}{key}: {scalar}\n")
        return "".join(out)
    if isinstance(obj, list):
        if not obj:
            return pad + "[]\n"
        out = []
        for item in obj:
            if isinstance(item, (dict, list)) and item:
                body = dump(item, indent + 2)
                first, _, rest = body.partition("\n")
                out.append(f"{pad}- {first.strip()}\n")
                if rest.strip():
                    out.append(rest if rest.endswith("\n") else rest + "\n")
            else:
                out.append(f"{pad}- {_fmt_scalar(item)}\n")
        return "".join(out)
    scalar = _fmt_scalar(obj)
    return f"{pad}{scalar}\n"


def dump_all(objs: List[Any]) -> str:
    return "---\n".join(dump(o) for o in objs)
