"""NetworkPolicy evaluation -- the lab's own data plane.

A real cluster needs a CNI that enforces policy (Calico, Cilium, Antrea). This
module is that enforcement point for the simulator: every simulated connection
(`kubectl exec A -- curl B`, and the connectivity matrix) is checked against the
NetworkPolicies that actually exist, using the same rules the spec defines:

  * a pod with NO policy selecting it is allowed everything
  * as soon as ANY policy selects a pod for a direction, that direction becomes
    default-deny for it
  * policies are additive: traffic is allowed if ANY rule allows it
  * a peer entry combining podSelector + namespaceSelector is an AND;
    separate list entries are ORs
  * ports narrow a rule; no ports means every port

It also explains *which* policy made the decision, which is the part a real CNI
never tells you.
"""
from __future__ import annotations

import ipaddress
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .model import Cluster, deep_get, match_labels


@dataclass
class Verdict:
    allowed: bool
    reason: str
    direction: str = ""                       # egress | ingress
    policies: List[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        return self.allowed


def _ns_labels(cluster: Cluster, namespace: str) -> Dict[str, str]:
    obj = cluster.get("Namespace", "", namespace)
    labels = dict(deep_get(obj, "metadata.labels", {}) or {}) if obj else {}
    labels.setdefault("kubernetes.io/metadata.name", namespace)
    return labels


def _selects(policy: dict, pod: dict) -> bool:
    """Does this policy's podSelector cover this pod? ({} means every pod.)"""
    if deep_get(policy, "metadata.namespace") != deep_get(pod, "metadata.namespace"):
        return False
    selector = deep_get(policy, "spec.podSelector", {})
    if selector in (None, {}, {"matchLabels": {}}):
        return True
    return match_labels(deep_get(pod, "metadata.labels", {}) or {}, selector)


def _policy_types(policy: dict) -> List[str]:
    declared = deep_get(policy, "spec.policyTypes", None)
    if declared:
        return [str(t) for t in declared]
    types = ["Ingress"]
    if deep_get(policy, "spec.egress") is not None:
        types.append("Egress")
    return types


def _peer_matches(cluster: Cluster, peer: dict, pod: dict, policy_ns: str) -> bool:
    pod_ns = deep_get(pod, "metadata.namespace", "default")
    pod_labels = deep_get(pod, "metadata.labels", {}) or {}

    if "ipBlock" in peer:
        cidr = deep_get(peer, "ipBlock.cidr", "")
        address = deep_get(pod, "status.podIP", "")
        if not cidr or not address:
            return False
        try:
            network = ipaddress.ip_network(cidr, strict=False)
            ip = ipaddress.ip_address(address)
        except ValueError:
            return False
        if ip not in network:
            return False
        for excluded in deep_get(peer, "ipBlock.except", []) or []:
            try:
                if ip in ipaddress.ip_network(excluded, strict=False):
                    return False
            except ValueError:
                pass
        return True

    namespace_selector = peer.get("namespaceSelector")
    pod_selector = peer.get("podSelector")

    if namespace_selector is not None:
        if not match_labels(_ns_labels(cluster, pod_ns), namespace_selector) and \
                namespace_selector not in ({}, {"matchLabels": {}}):
            return False
    elif pod_ns != policy_ns:
        # no namespaceSelector -> the peer means "in this policy's namespace"
        return False

    if pod_selector is not None and pod_selector not in ({}, {"matchLabels": {}}):
        if not match_labels(pod_labels, pod_selector):
            return False
    return True


def _port_matches(rule: dict, port: Optional[int], protocol: str) -> bool:
    ports = rule.get("ports")
    if not ports:
        return True
    for entry in ports:
        if str(entry.get("protocol", "TCP")).upper() != protocol.upper():
            continue
        wanted = entry.get("port")
        end = entry.get("endPort")
        if wanted is None:
            return True
        try:
            wanted = int(wanted)
        except (TypeError, ValueError):
            return True                       # named port: accept in the lab
        if port is None:
            return True
        if end is not None and wanted <= port <= int(end):
            return True
        if port == wanted:
            return True
    return False


def _direction(cluster: Cluster, subject: dict, other: dict, direction: str,
               port: Optional[int], protocol: str) -> Verdict:
    """Evaluate one half of the connection (egress from src, ingress to dst)."""
    namespace = deep_get(subject, "metadata.namespace", "default")
    key = "egress" if direction == "Egress" else "ingress"
    peer_key = "to" if direction == "Egress" else "from"

    applicable = [p for p in cluster.list("NetworkPolicy", namespace)
                  if _selects(p, subject) and direction in _policy_types(p)]
    if not applicable:
        return Verdict(True, f"no {direction.lower()} policy selects "
                             f"{deep_get(subject, 'metadata.name')}", direction)

    names = [deep_get(p, "metadata.name") for p in applicable]
    for policy in applicable:
        rules = deep_get(policy, f"spec.{key}", []) or []
        for rule in rules:
            peers = rule.get(peer_key)
            if peers is None:                 # rule with no peers = allow all peers
                if _port_matches(rule, port, protocol):
                    return Verdict(True, f"allowed by {deep_get(policy, 'metadata.name')}"
                                         f" (any peer)", direction, names)
                continue
            for peer in peers:
                if _peer_matches(cluster, peer, other, namespace) and \
                        _port_matches(rule, port, protocol):
                    return Verdict(
                        True,
                        f"allowed by {deep_get(policy, 'metadata.name')}",
                        direction, names)
    return Verdict(False,
                   f"{direction.lower()} denied: {', '.join(names)} select "
                   f"{deep_get(subject, 'metadata.name')} and no rule matches "
                   f"{deep_get(other, 'metadata.name')}"
                   + (f":{port}" if port else ""),
                   direction, names)


def evaluate(cluster: Cluster, source: dict, target: dict,
             port: Optional[int] = None, protocol: str = "TCP") -> Verdict:
    """Can `source` reach `target` on this port? Explains which policy decided."""
    if source is None or target is None:
        return Verdict(False, "unknown pod")
    if deep_get(source, "metadata.name") == deep_get(target, "metadata.name"):
        return Verdict(True, "same pod")

    egress = _direction(cluster, source, target, "Egress", port, protocol)
    if not egress.allowed:
        return egress
    ingress = _direction(cluster, target, source, "Ingress", port, protocol)
    if not ingress.allowed:
        return ingress
    return Verdict(True, f"{egress.reason}; {ingress.reason}", "both",
                   sorted(set(egress.policies + ingress.policies)))


def matrix(cluster: Cluster, namespace: Optional[str] = None,
           port: Optional[int] = None) -> Tuple[List[str], List[List[Verdict]]]:
    """Full allowed/denied grid between the running pods of a namespace."""
    pods = [p for p in cluster.list("Pod", namespace)
            if deep_get(p, "status.phase") == "Running"]
    names = [deep_get(p, "metadata.name") for p in pods]
    grid = [[evaluate(cluster, source, target, port) for target in pods]
            for source in pods]
    return names, grid


def isolated(cluster: Cluster, pod: dict) -> Dict[str, List[str]]:
    """Which policies make this pod default-deny, per direction."""
    namespace = deep_get(pod, "metadata.namespace", "default")
    out: Dict[str, List[str]] = {"Ingress": [], "Egress": []}
    for policy in cluster.list("NetworkPolicy", namespace):
        if not _selects(policy, pod):
            continue
        for direction in _policy_types(policy):
            out.setdefault(direction, []).append(deep_get(policy, "metadata.name"))
    return out
