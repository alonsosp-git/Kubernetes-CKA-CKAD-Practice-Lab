"""k8s-practice-lab -- a Kubernetes simulator, CLI and topology visualiser.

Practise every concept in the Kubernetes Handbook without a real cluster:
type kubectl commands (or preload a script), watch the topology build itself,
and read the matching handbook page beside your work.
"""

__version__ = "1.0.0"
__all__ = ["model", "apiserver", "scheduler", "controllers", "kubectl", "printers",
           "topology", "handbook", "cluster_factory", "miniyaml", "labs"]
