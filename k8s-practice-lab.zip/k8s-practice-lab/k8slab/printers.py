"""kubectl-style table printers and `describe` output."""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from . import miniyaml
from .model import (Cluster, annotation, deep_get, fmt_age, fmt_cpu, fmt_mem,
                    parse_cpu, parse_mem)


def table(headers: List[str], rows: List[List[Any]]) -> str:
    if not rows:
        return ""
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))
    out = ["   ".join(h.ljust(widths[i]) for i, h in enumerate(headers)).rstrip()]
    for row in rows:
        out.append("   ".join(str(c).ljust(widths[i]) for i, c in enumerate(row)).rstrip())
    return "\n".join(out)


def _ready_str(pod: dict) -> str:
    containers = deep_get(pod, "spec.containers", []) or []
    ready = len(containers) if deep_get(pod, "status.ready") else 0
    return f"{ready}/{len(containers)}"


def pod_status(pod: dict) -> str:
    phase = deep_get(pod, "status.phase", "Pending")
    reason = deep_get(pod, "status.reason")
    if reason and reason not in ("Running",):
        return reason
    return phase


def print_pods(cluster: Cluster, pods: List[dict], wide: bool = False,
               all_ns: bool = False) -> str:
    headers = (["NAMESPACE"] if all_ns else []) + \
        ["NAME", "READY", "STATUS", "RESTARTS", "AGE"]
    if wide:
        headers += ["IP", "NODE", "NOMINATED NODE", "READINESS GATES"]
    rows = []
    for pod in pods:
        row = ([deep_get(pod, "metadata.namespace", "default")] if all_ns else []) + [
            deep_get(pod, "metadata.name"),
            _ready_str(pod),
            pod_status(pod),
            deep_get(pod, "status.restartCount", 0),
            cluster.age_of(pod)]
        if wide:
            row += [deep_get(pod, "status.podIP", "<none>"),
                    deep_get(pod, "spec.nodeName", "<none>"), "<none>", "<none>"]
        rows.append(row)
    return table(headers, rows)


def print_generic(cluster: Cluster, kind: str, objs: List[dict], wide: bool,
                  all_ns: bool) -> str:
    ns_col = ["NAMESPACE"] if all_ns else []

    def ns(obj):
        return [deep_get(obj, "metadata.namespace", "default")] if all_ns else []

    if kind == "Deployment":
        rows = [ns(o) + [deep_get(o, "metadata.name"),
                         f"{deep_get(o, 'status.readyReplicas', 0)}/"
                         f"{deep_get(o, 'spec.replicas', 0)}",
                         deep_get(o, "status.updatedReplicas", 0),
                         deep_get(o, "status.availableReplicas", 0),
                         cluster.age_of(o)] +
                ([",".join(c.get("image", "") for c in
                           deep_get(o, "spec.template.spec.containers", []) or []),
                  _selector_str(deep_get(o, "spec.selector"))] if wide else [])
                for o in objs]
        return table(ns_col + ["NAME", "READY", "UP-TO-DATE", "AVAILABLE", "AGE"] +
                     (["IMAGES", "SELECTOR"] if wide else []), rows)

    if kind == "ReplicaSet":
        rows = [ns(o) + [deep_get(o, "metadata.name"), deep_get(o, "spec.replicas", 0),
                         deep_get(o, "status.replicas", 0),
                         deep_get(o, "status.readyReplicas", 0), cluster.age_of(o)]
                for o in objs]
        return table(ns_col + ["NAME", "DESIRED", "CURRENT", "READY", "AGE"], rows)

    if kind == "StatefulSet":
        rows = [ns(o) + [deep_get(o, "metadata.name"),
                         f"{deep_get(o, 'status.readyReplicas', 0)}/"
                         f"{deep_get(o, 'spec.replicas', 0)}", cluster.age_of(o)]
                for o in objs]
        return table(ns_col + ["NAME", "READY", "AGE"], rows)

    if kind == "DaemonSet":
        rows = [ns(o) + [deep_get(o, "metadata.name"),
                         deep_get(o, "status.desiredNumberScheduled", 0),
                         deep_get(o, "status.currentNumberScheduled", 0),
                         deep_get(o, "status.numberReady", 0),
                         deep_get(o, "status.updatedNumberScheduled", 0),
                         deep_get(o, "status.numberAvailable", 0),
                         _selector_str(deep_get(o, "spec.template.spec.nodeSelector")),
                         cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "DESIRED", "CURRENT", "READY", "UP-TO-DATE",
                               "AVAILABLE", "NODE SELECTOR", "AGE"], rows)

    if kind == "Service":
        rows = []
        for o in objs:
            ports = deep_get(o, "spec.ports", []) or []
            stype = deep_get(o, "spec.type", "ClusterIP")
            port_str = ",".join(
                (f"{p.get('port')}:{p.get('nodePort')}/{p.get('protocol', 'TCP')}"
                 if p.get("nodePort") else f"{p.get('port')}/{p.get('protocol', 'TCP')}")
                for p in ports) or "<none>"
            external = "<none>"
            if stype == "LoadBalancer":
                external = deep_get(o, "status.loadBalancer.ingress.0.ip", "<pending>")
            elif stype == "ExternalName":
                external = deep_get(o, "spec.externalName", "<none>")
            row = ns(o) + [deep_get(o, "metadata.name"), stype,
                           deep_get(o, "spec.clusterIP", "None"), external, port_str,
                           cluster.age_of(o)]
            if wide:
                row.append(_selector_str(deep_get(o, "spec.selector")))
            rows.append(row)
        return table(ns_col + ["NAME", "TYPE", "CLUSTER-IP", "EXTERNAL-IP", "PORT(S)",
                               "AGE"] + (["SELECTOR"] if wide else []), rows)

    if kind == "Node":
        rows = []
        for o in objs:
            status = "Ready" if deep_get(o, "status.ready", True) else "NotReady"
            if deep_get(o, "spec.unschedulable"):
                status += ",SchedulingDisabled"
            row = [deep_get(o, "metadata.name"), status,
                   deep_get(o, "status.role", "worker"), cluster.age_of(o),
                   deep_get(o, "status.nodeInfo.kubeletVersion", "v1.30.2")]
            if wide:
                row += [deep_get(o, "status.addresses.0.address", ""),
                        deep_get(o, "status.nodeInfo.osImage", ""),
                        deep_get(o, "status.nodeInfo.containerRuntimeVersion", "")]
            rows.append(row)
        return table(["NAME", "STATUS", "ROLES", "AGE", "VERSION"] +
                     (["INTERNAL-IP", "OS-IMAGE", "CONTAINER-RUNTIME"] if wide else []),
                     rows)

    if kind == "Namespace":
        rows = [[deep_get(o, "metadata.name"), deep_get(o, "status.phase", "Active"),
                 cluster.age_of(o)] for o in objs]
        return table(["NAME", "STATUS", "AGE"], rows)

    if kind == "Ingress":
        rows = []
        for o in objs:
            hosts = ",".join(r.get("host", "*") for r in
                             deep_get(o, "spec.rules", []) or []) or "*"
            address = deep_get(o, "status.loadBalancer.ingress.0.ip", "")
            rows.append(ns(o) + [deep_get(o, "metadata.name"),
                                 deep_get(o, "spec.ingressClassName", "<none>"),
                                 hosts, address, "80", cluster.age_of(o)])
        return table(ns_col + ["NAME", "CLASS", "HOSTS", "ADDRESS", "PORTS", "AGE"], rows)

    if kind == "ConfigMap":
        rows = [ns(o) + [deep_get(o, "metadata.name"), len(o.get("data") or {}),
                         cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "DATA", "AGE"], rows)

    if kind == "Secret":
        rows = [ns(o) + [deep_get(o, "metadata.name"),
                         o.get("type", "Opaque"),
                         len((o.get("data") or {}) or (o.get("stringData") or {})),
                         cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "TYPE", "DATA", "AGE"], rows)

    if kind == "PersistentVolume":
        rows = [[deep_get(o, "metadata.name"),
                 deep_get(o, "spec.capacity.storage", ""),
                 ",".join(_short_modes(deep_get(o, "spec.accessModes", []) or [])),
                 deep_get(o, "spec.persistentVolumeReclaimPolicy", "Retain"),
                 deep_get(o, "status.phase", "Available"),
                 (f'{deep_get(o, "spec.claimRef.namespace", "")}/'
                  f'{deep_get(o, "spec.claimRef.name", "")}'
                  if deep_get(o, "spec.claimRef") else ""),
                 deep_get(o, "spec.storageClassName", ""), cluster.age_of(o)]
                for o in objs]
        return table(["NAME", "CAPACITY", "ACCESS MODES", "RECLAIM POLICY", "STATUS",
                      "CLAIM", "STORAGECLASS", "AGE"], rows)

    if kind == "PersistentVolumeClaim":
        rows = [ns(o) + [deep_get(o, "metadata.name"),
                         deep_get(o, "status.phase", "Pending"),
                         deep_get(o, "status.volumeName", ""),
                         deep_get(o, "status.capacity.storage",
                                  deep_get(o, "spec.resources.requests.storage", "")),
                         ",".join(_short_modes(deep_get(o, "spec.accessModes", []) or [])),
                         deep_get(o, "spec.storageClassName", "standard"),
                         cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "STATUS", "VOLUME", "CAPACITY", "ACCESS MODES",
                               "STORAGECLASS", "AGE"], rows)

    if kind == "StorageClass":
        rows = [[deep_get(o, "metadata.name") +
                 (" (default)" if str(annotation(
                     o, "storageclass.kubernetes.io/is-default-class", "")
                     ).lower() == "true" else ""),
                 o.get("provisioner", ""), o.get("reclaimPolicy", "Delete"),
                 o.get("volumeBindingMode", "Immediate"),
                 o.get("allowVolumeExpansion", False), cluster.age_of(o)] for o in objs]
        return table(["NAME", "PROVISIONER", "RECLAIMPOLICY", "VOLUMEBINDINGMODE",
                      "ALLOWVOLUMEEXPANSION", "AGE"], rows)

    if kind == "Job":
        rows = [ns(o) + [deep_get(o, "metadata.name"),
                         f"{deep_get(o, 'status.succeeded', 0)}/"
                         f"{deep_get(o, 'spec.completions', 1)}",
                         f"{max(0, cluster.tick - deep_get(o, 'metadata.creationTick', 0))}s",
                         cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "COMPLETIONS", "DURATION", "AGE"], rows)

    if kind == "CronJob":
        rows = [ns(o) + [deep_get(o, "metadata.name"), deep_get(o, "spec.schedule", ""),
                         deep_get(o, "spec.suspend", False),
                         deep_get(o, "status.active", 0),
                         (f"{cluster.tick - deep_get(o, 'status.lastScheduleTick', 0)}s"
                          if deep_get(o, "status.lastScheduleTick") is not None else
                          "<none>"),
                         cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "SCHEDULE", "SUSPEND", "ACTIVE", "LAST SCHEDULE",
                               "AGE"], rows)

    if kind == "HorizontalPodAutoscaler":
        rows = []
        for o in objs:
            ref = deep_get(o, "spec.scaleTargetRef", {}) or {}
            current = deep_get(o, "status.currentCPUUtilizationPercentage", 0)
            target = deep_get(o, "status.targetCPUUtilizationPercentage", 80)
            rows.append(ns(o) + [deep_get(o, "metadata.name"),
                                 f'{ref.get("kind", "Deployment")}/{ref.get("name")}',
                                 f"cpu: {current}%/{target}%",
                                 deep_get(o, "spec.minReplicas", 1),
                                 deep_get(o, "spec.maxReplicas", 10),
                                 deep_get(o, "status.currentReplicas", 0),
                                 cluster.age_of(o)])
        return table(ns_col + ["NAME", "REFERENCE", "TARGETS", "MINPODS", "MAXPODS",
                               "REPLICAS", "AGE"], rows)

    if kind == "VerticalPodAutoscaler":
        rows = []
        for o in objs:
            recs = deep_get(o, "status.recommendation.containerRecommendations", []) or []
            summary = ", ".join(f'{r.get("containerName")}: '
                                f'{deep_get(r, "target.cpu")}/'
                                f'{deep_get(r, "target.memory")}' for r in recs)
            rows.append(ns(o) + [deep_get(o, "metadata.name"),
                                 deep_get(o, "spec.updatePolicy.updateMode", "Off"),
                                 summary or "<computing>", cluster.age_of(o)])
        return table(ns_col + ["NAME", "MODE", "RECOMMENDATION (cpu/mem)", "AGE"], rows)

    if kind in ("Role", "ClusterRole"):
        rows = [ns(o) + [deep_get(o, "metadata.name"), cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "AGE"], rows)

    if kind in ("RoleBinding", "ClusterRoleBinding"):
        rows = [ns(o) + [deep_get(o, "metadata.name"),
                         f'{deep_get(o, "roleRef.kind", "Role")}/'
                         f'{deep_get(o, "roleRef.name", "")}',
                         ",".join(f'{s.get("kind")}:{s.get("name")}'
                                  for s in o.get("subjects", []) or []),
                         cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "ROLE", "SUBJECTS", "AGE"], rows)

    if kind == "ServiceAccount":
        rows = [ns(o) + [deep_get(o, "metadata.name"), 0, cluster.age_of(o)]
                for o in objs]
        return table(ns_col + ["NAME", "SECRETS", "AGE"], rows)

    if kind == "NetworkPolicy":
        rows = [ns(o) + [deep_get(o, "metadata.name"),
                         _selector_str(deep_get(o, "spec.podSelector")) or "<none>",
                         cluster.age_of(o)] for o in objs]
        return table(ns_col + ["NAME", "POD-SELECTOR", "AGE"], rows)

    if kind == "ResourceQuota":
        rows = []
        for o in objs:
            hard = deep_get(o, "spec.hard", {}) or {}
            rows.append(ns(o) + [deep_get(o, "metadata.name"), cluster.age_of(o),
                                 ", ".join(f"{k}={v}" for k, v in hard.items())])
        return table(ns_col + ["NAME", "AGE", "REQUEST"], rows)

    if kind == "CertificateSigningRequest":
        rows = []
        for o in objs:
            conditions = deep_get(o, "status.conditions", []) or []
            condition = ",".join(c.get("type", "") for c in conditions) or "Pending"
            rows.append([deep_get(o, "metadata.name"), cluster.age_of(o),
                         deep_get(o, "spec.signerName", ""),
                         deep_get(o, "spec.username", ""),
                         ",".join(deep_get(o, "spec.groups", []) or []),
                         condition])
        return table(["NAME", "AGE", "SIGNERNAME", "REQUESTOR", "REQUESTEDDURATION",
                      "CONDITION"], rows)

    if kind == "CustomResourceDefinition":
        rows = [[deep_get(o, "metadata.name"), cluster.age_of(o)] for o in objs]
        return table(["NAME", "CREATED AT"], rows)

    rows = [ns(o) + [deep_get(o, "metadata.name"), cluster.age_of(o)] for o in objs]
    return table(ns_col + ["NAME", "AGE"], rows)


def _short_modes(modes: List[str]) -> List[str]:
    mapping = {"ReadWriteOnce": "RWO", "ReadOnlyMany": "ROX", "ReadWriteMany": "RWX",
               "ReadWriteOncePod": "RWOP"}
    return [mapping.get(m, m) for m in modes]


def _selector_str(selector: Any) -> str:
    if not selector:
        return ""
    if isinstance(selector, dict) and "matchLabels" in selector:
        selector = selector["matchLabels"]
    if isinstance(selector, dict):
        return ",".join(f"{k}={v}" for k, v in selector.items())
    return str(selector)


# --------------------------------------------------------------------------
# describe
# --------------------------------------------------------------------------
def describe(cluster: Cluster, obj: dict) -> str:
    kind = obj.get("kind")
    name = deep_get(obj, "metadata.name")
    ns = deep_get(obj, "metadata.namespace", "")
    lines = [f"Name:         {name}"]
    if ns:
        lines.append(f"Namespace:    {ns}")
    labels = deep_get(obj, "metadata.labels", {}) or {}
    annotations = deep_get(obj, "metadata.annotations", {}) or {}
    lines.append("Labels:       " + (
        "\n              ".join(f"{k}={v}" for k, v in labels.items()) or "<none>"))
    lines.append("Annotations:  " + (
        "\n              ".join(f"{k}: {v}" for k, v in annotations.items()) or "<none>"))

    if kind == "Pod":
        lines += [
            f"Node:         {deep_get(obj, 'spec.nodeName', '<none>')}",
            f"Status:       {pod_status(obj)}",
            f"IP:           {deep_get(obj, 'status.podIP', '<none>')}",
            f"Service Account: {deep_get(obj, 'spec.serviceAccountName', 'default')}",
            f"Restart Count: {deep_get(obj, 'status.restartCount', 0)}",
        ]
        message = deep_get(obj, "status.message")
        if message:
            lines.append(f"Message:      {message}")
        for section, key in (("Init Containers", "initContainers"),
                             ("Containers", "containers")):
            containers = deep_get(obj, f"spec.{key}", []) or []
            if not containers:
                continue
            lines.append(f"{section}:")
            for container in containers:
                lines.append(f"  {container.get('name')}:")
                lines.append(f"    Image:      {container.get('image')}")
                ports = ",".join(str(p.get("containerPort"))
                                 for p in container.get("ports", []) or [])
                lines.append(f"    Port:       {ports or '<none>'}")
                for kind_res in ("requests", "limits"):
                    res = deep_get(container, f"resources.{kind_res}", {}) or {}
                    if res:
                        lines.append(f"    {kind_res.title()}:   " +
                                     ", ".join(f"{k}={v}" for k, v in res.items()))
                for probe in ("livenessProbe", "readinessProbe", "startupProbe"):
                    if container.get(probe):
                        lines.append(f"    {probe}: {json.dumps(container[probe])}")
                env = container.get("env") or []
                if env:
                    lines.append("    Environment:")
                    for entry in env:
                        source = entry.get("value")
                        if source is None:
                            ref = entry.get("valueFrom", {})
                            source = ("<from " +
                                      ",".join(f"{k}:{deep_get(v, 'name', '')}"
                                               for k, v in ref.items()) + ">")
                        lines.append(f"      {entry.get('name')}: {source}")
                if container.get("envFrom"):
                    lines.append("    EnvFrom:      " + json.dumps(container["envFrom"]))
        volumes = deep_get(obj, "spec.volumes", []) or []
        if volumes:
            lines.append("Volumes:")
            for volume in volumes:
                kind_hint = [k for k in volume if k != "name"]
                lines.append(f"  {volume.get('name')}: "
                             f"{kind_hint[0] if kind_hint else 'emptyDir'} "
                             f"{json.dumps(volume.get(kind_hint[0], {})) if kind_hint else ''}")
        tolerations = deep_get(obj, "spec.tolerations", []) or []
        lines.append("Tolerations:  " + (", ".join(
            f"{t.get('key', '*')}{'=' + str(t.get('value')) if t.get('value') else ''}:"
            f"{t.get('effect', 'NoSchedule')}" for t in tolerations) or "<none>"))
        node_selector = deep_get(obj, "spec.nodeSelector", {}) or {}
        lines.append("Node-Selectors: " + (", ".join(
            f"{k}={v}" for k, v in node_selector.items()) or "<none>"))

    elif kind in ("Deployment", "ReplicaSet", "StatefulSet", "DaemonSet"):
        lines += [
            f"Selector:     {_selector_str(deep_get(obj, 'spec.selector'))}",
            f"Replicas:     {deep_get(obj, 'spec.replicas', 'n/a')} desired | "
            f"{deep_get(obj, 'status.replicas', 0)} current | "
            f"{deep_get(obj, 'status.readyReplicas', 0)} ready",
            f"StrategyType: {deep_get(obj, 'spec.strategy.type', 'RollingUpdate')}",
            "Pod Template:",
            "  Labels:  " + _selector_str(
                deep_get(obj, "spec.template.metadata.labels", {})),
            "  Containers:"]
        for container in deep_get(obj, "spec.template.spec.containers", []) or []:
            lines.append(f"   {container.get('name')}:")
            lines.append(f"    Image: {container.get('image')}")

    elif kind == "Service":
        lines += [
            f"Type:         {deep_get(obj, 'spec.type', 'ClusterIP')}",
            f"IP:           {deep_get(obj, 'spec.clusterIP', 'None')}",
            f"Selector:     {_selector_str(deep_get(obj, 'spec.selector')) or '<none>'}",
        ]
        for port in deep_get(obj, "spec.ports", []) or []:
            lines.append(f"Port:         {port.get('name', '<unset>')} "
                         f"{port.get('port')}/{port.get('protocol', 'TCP')}")
            lines.append(f"TargetPort:   {port.get('targetPort')}")
            if port.get("nodePort"):
                lines.append(f"NodePort:     {port.get('name', '<unset>')} "
                             f"{port['nodePort']}/{port.get('protocol', 'TCP')}")
        endpoints = deep_get(obj, "status.endpoints", []) or []
        lines.append("Endpoints:    " + (
            ", ".join(f"{e.get('ip')}" for e in endpoints) or "<none>"))

    elif kind == "Node":
        usage = deep_get(obj, "status.usage", {}) or {}
        alloc = deep_get(obj, "status.allocatable", {}) or {}
        lines += [
            f"Roles:        {deep_get(obj, 'status.role', 'worker')}",
            f"Ready:        {deep_get(obj, 'status.ready', True)}",
            f"Unschedulable:{deep_get(obj, 'spec.unschedulable', False)}",
            "Taints:       " + (", ".join(
                f"{t.get('key')}={t.get('value', '')}:{t.get('effect')}"
                for t in deep_get(obj, "spec.taints", []) or []) or "<none>"),
            "Capacity:     cpu=%s memory=%s pods=%s" % (
                alloc.get("cpu"), alloc.get("memory"), alloc.get("pods")),
            "Allocated:    cpu=%s (%s%%)  memory=%s (%s%%)  pods=%s" % (
                fmt_cpu(usage.get("cpu", 0)), usage.get("cpuPct", 0),
                fmt_mem(usage.get("memory", 0)), usage.get("memPct", 0),
                usage.get("pods", 0)),
        ]
        pods_here = [p for p in cluster.list("Pod")
                     if deep_get(p, "spec.nodeName") == name]
        lines.append(f"Non-terminated Pods: ({len(pods_here)} in total)")
        for pod in pods_here:
            lines.append(f"  {deep_get(pod, 'metadata.namespace')}/"
                         f"{deep_get(pod, 'metadata.name')}  {pod_status(pod)}")

    elif kind == "PersistentVolumeClaim":
        lines += [f"Status:       {deep_get(obj, 'status.phase', 'Pending')}",
                  f"Volume:       {deep_get(obj, 'status.volumeName', '')}",
                  f"StorageClass: {deep_get(obj, 'spec.storageClassName', 'standard')}",
                  "Access Modes: " + ",".join(
                      _short_modes(deep_get(obj, "spec.accessModes", []) or [])),
                  f"Capacity:     {deep_get(obj, 'status.capacity.storage', '')}"]
        used_by = [deep_get(p, "metadata.name") for p in cluster.list("Pod", ns)
                   for v in deep_get(p, "spec.volumes", []) or []
                   if deep_get(v, "persistentVolumeClaim.claimName") == name]
        lines.append("Used By:      " + (", ".join(used_by) or "<none>"))

    elif kind == "HorizontalPodAutoscaler":
        ref = deep_get(obj, "spec.scaleTargetRef", {}) or {}
        lines += [f"Reference:    {ref.get('kind')}/{ref.get('name')}",
                  f"Metrics:      resource cpu on pods "
                  f"({deep_get(obj, 'status.currentCPUUtilizationPercentage', 0)}% / "
                  f"{deep_get(obj, 'status.targetCPUUtilizationPercentage', 80)}%)",
                  f"Min replicas: {deep_get(obj, 'spec.minReplicas', 1)}",
                  f"Max replicas: {deep_get(obj, 'spec.maxReplicas', 10)}",
                  f"Current replicas: {deep_get(obj, 'status.currentReplicas', 0)}"]

    elif kind == "Ingress":
        lines.append(f"IngressClass: {deep_get(obj, 'spec.ingressClassName', '<none>')}")
        lines.append("Rules:")
        for rule in deep_get(obj, "spec.rules", []) or []:
            lines.append(f"  Host: {rule.get('host', '*')}")
            for path in deep_get(rule, "http.paths", []) or []:
                backend = deep_get(path, "backend.service", {}) or {}
                lines.append(f"    {path.get('path', '/')}  -> "
                             f"{backend.get('name')}:"
                             f"{deep_get(backend, 'port.number', '')}")

    elif kind in ("Role", "ClusterRole"):
        lines.append("PolicyRule:")
        lines.append("  " + table(["Resources", "Verbs"],
                                  [[",".join(r.get("resources", [])),
                                    ",".join(r.get("verbs", []))]
                                   for r in obj.get("rules", []) or []]
                                  ).replace("\n", "\n  "))

    elif kind == "ConfigMap":
        lines.append("Data")
        lines.append("====")
        for key, value in (obj.get("data") or {}).items():
            lines.append(f"{key}:")
            lines.append("----")
            lines.append(str(value))
            lines.append("")

    elif kind == "Secret":
        lines.append(f"Type:  {obj.get('type', 'Opaque')}")
        lines.append("Data")
        lines.append("====")
        for key, value in {**(obj.get("data") or {}),
                           **(obj.get("stringData") or {})}.items():
            lines.append(f"{key}:  {len(str(value))} bytes")

    involved = f"{str(kind).lower()}/{name}"
    events = [e for e in cluster.events if e.involved == involved][-12:]
    lines.append("")
    lines.append("Events:")
    if not events:
        lines.append("  <none>")
    else:
        rows = [[e.type, e.reason, f"{fmt_age(cluster.tick - e.tick)} ago",
                 f"x{e.count}" if e.count > 1 else "", e.message] for e in events]
        lines.append("  " + table(["TYPE", "REASON", "AGE", "COUNT", "MESSAGE"], rows)
                     .replace("\n", "\n  "))
    return "\n".join(lines)


def to_output(obj_or_list: Any, fmt: str) -> str:
    def clean(obj):
        if isinstance(obj, dict):
            return {k: clean(v) for k, v in obj.items()
                    if k not in ("creationTick", "scheduledTick", "jobPod")}
        if isinstance(obj, list):
            return [clean(v) for v in obj]
        return obj

    data = clean(obj_or_list)
    if fmt == "json":
        return json.dumps(data, indent=2, default=str)
    if isinstance(data, list):
        return miniyaml.dump_all(data)
    return miniyaml.dump(data)
