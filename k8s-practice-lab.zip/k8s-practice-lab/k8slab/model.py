"""Core object model for the simulated cluster.

Everything in the lab is a plain dict shaped like a real Kubernetes object
(``apiVersion`` / ``kind`` / ``metadata`` / ``spec`` / ``status``) so that the
YAML you write here is the YAML you would write against a real cluster.
"""
from __future__ import annotations

import copy
import hashlib
import random
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# --------------------------------------------------------------------------
# resource registry -- kind, plural, short names, namespaced?, apiVersion
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class ResourceKind:
    kind: str
    plural: str
    short: Tuple[str, ...]
    namespaced: bool
    api_version: str
    topic: str = ""          # handbook topic key this resource belongs to


REGISTRY: Tuple[ResourceKind, ...] = (
    ResourceKind("Namespace", "namespaces", ("ns",), False, "v1", "namespaces"),
    ResourceKind("Node", "nodes", ("no",), False, "v1", "architecture"),
    ResourceKind("Pod", "pods", ("po",), True, "v1", "pods"),
    ResourceKind("ReplicaSet", "replicasets", ("rs",), True, "apps/v1", "replicasets"),
    ResourceKind("Deployment", "deployments", ("deploy",), True, "apps/v1", "deployments"),
    ResourceKind("StatefulSet", "statefulsets", ("sts",), True, "apps/v1", "statefulsets"),
    ResourceKind("DaemonSet", "daemonsets", ("ds",), True, "apps/v1", "daemonsets"),
    ResourceKind("Job", "jobs", (), True, "batch/v1", "jobs"),
    ResourceKind("CronJob", "cronjobs", ("cj",), True, "batch/v1", "cronjobs"),
    ResourceKind("Service", "services", ("svc",), True, "v1", "services"),
    ResourceKind("Ingress", "ingresses", ("ing",), True, "networking.k8s.io/v1", "ingress"),
    ResourceKind("IngressClass", "ingressclasses", (), False,
                 "networking.k8s.io/v1", "ingress-controller"),
    ResourceKind("NetworkPolicy", "networkpolicies", ("netpol",), True,
                 "networking.k8s.io/v1", "network-policies"),
    ResourceKind("ConfigMap", "configmaps", ("cm",), True, "v1", "configmaps"),
    ResourceKind("Secret", "secrets", (), True, "v1", "configmaps"),
    ResourceKind("PersistentVolume", "persistentvolumes", ("pv",), False, "v1", "pv"),
    ResourceKind("PersistentVolumeClaim", "persistentvolumeclaims", ("pvc",),
                 True, "v1", "pvc"),
    ResourceKind("StorageClass", "storageclasses", ("sc",), False,
                 "storage.k8s.io/v1", "storage-classes"),
    ResourceKind("ResourceQuota", "resourcequotas", ("quota",), True, "v1", "namespaces"),
    ResourceKind("LimitRange", "limitranges", ("limits",), True, "v1", "resources"),
    ResourceKind("ServiceAccount", "serviceaccounts", ("sa",), True, "v1",
                 "service-accounts"),
    ResourceKind("Role", "roles", (), True, "rbac.authorization.k8s.io/v1", "rbac"),
    ResourceKind("RoleBinding", "rolebindings", (), True,
                 "rbac.authorization.k8s.io/v1", "rbac"),
    ResourceKind("ClusterRole", "clusterroles", (), False,
                 "rbac.authorization.k8s.io/v1", "rbac"),
    ResourceKind("ClusterRoleBinding", "clusterrolebindings", (), False,
                 "rbac.authorization.k8s.io/v1", "rbac"),
    ResourceKind("HorizontalPodAutoscaler", "horizontalpodautoscalers", ("hpa",),
                 True, "autoscaling/v2", "hpa"),
    ResourceKind("VerticalPodAutoscaler", "verticalpodautoscalers", ("vpa",),
                 True, "autoscaling.k8s.io/v1", "vpa"),
    ResourceKind("PodDisruptionBudget", "poddisruptionbudgets", ("pdb",), True,
                 "policy/v1", "best-practices"),
    ResourceKind("CustomResourceDefinition", "customresourcedefinitions", ("crd",),
                 False, "apiextensions.k8s.io/v1", "crds"),
    ResourceKind("Event", "events", ("ev",), True, "v1", "troubleshooting"),
    ResourceKind("CertificateSigningRequest", "certificatesigningrequests", ("csr",),
                 False, "certificates.k8s.io/v1", "certificates"),
)

_BY_KIND = {rk.kind.lower(): rk for rk in REGISTRY}
_BY_PLURAL = {rk.plural: rk for rk in REGISTRY}
_BY_SHORT: Dict[str, ResourceKind] = {}
for _rk in REGISTRY:
    for _s in _rk.short:
        _BY_SHORT[_s] = _rk


def resolve_kind(name: str) -> Optional[ResourceKind]:
    """Resolve ``po`` / ``pods`` / ``Pod`` / ``pod`` to a ResourceKind."""
    if not name:
        return None
    key = name.strip().lower()
    if key in _BY_SHORT:
        return _BY_SHORT[key]
    if key in _BY_PLURAL:
        return _BY_PLURAL[key]
    if key in _BY_KIND:
        return _BY_KIND[key]
    if key.endswith("s") and key[:-1] in _BY_KIND:
        return _BY_KIND[key[:-1]]
    if key.endswith("es") and key[:-2] in _BY_KIND:
        return _BY_KIND[key[:-2]]
    return None


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
NAME_RE = re.compile(r"^[a-z0-9]([-a-z0-9.]*[a-z0-9])?$")

_CPU_RE = re.compile(r"^(\d+(?:\.\d+)?)(m?)$")
_MEM_RE = re.compile(r"^(\d+(?:\.\d+)?)(Ki|Mi|Gi|Ti|K|M|G|T)?$")


def parse_cpu(value: Any) -> float:
    """Return CPU quantity in millicores."""
    if value in (None, ""):
        return 0.0
    text = str(value).strip()
    match = _CPU_RE.match(text)
    if not match:
        raise ValueError(f"invalid cpu quantity: {value}")
    amount, unit = float(match.group(1)), match.group(2)
    return amount if unit == "m" else amount * 1000.0


def parse_mem(value: Any) -> float:
    """Return memory quantity in mebibytes."""
    if value in (None, ""):
        return 0.0
    text = str(value).strip()
    match = _MEM_RE.match(text)
    if not match:
        raise ValueError(f"invalid memory quantity: {value}")
    amount, unit = float(match.group(1)), match.group(2) or ""
    factor = {"": 1 / (1024 * 1024), "Ki": 1 / 1024, "Mi": 1, "Gi": 1024,
              "Ti": 1024 * 1024, "K": 1000 / (1024 * 1024),
              "M": 1_000_000 / (1024 * 1024), "G": 1_000_000_000 / (1024 * 1024),
              "T": 1e12 / (1024 * 1024)}[unit]
    return amount * factor


def fmt_cpu(millicores: float) -> str:
    if millicores >= 1000 and millicores % 1000 == 0:
        return str(int(millicores // 1000))
    return f"{int(round(millicores))}m"


def fmt_mem(mib: float) -> str:
    if mib >= 1024 and mib % 1024 == 0:
        return f"{int(mib // 1024)}Gi"
    return f"{int(round(mib))}Mi"


def short_hash(text: str, size: int = 10) -> str:
    """Deterministic pod-template-hash style suffix (bcdf charset like k8s).

    Cosmetic: it makes generated pod names look like real ones. It is not a
    security primitive -- nothing is authenticated, signed or compared against
    it -- which is what `usedforsecurity=False` records for the scanners.
    """
    digest = hashlib.sha1(text.encode(), usedforsecurity=False).hexdigest()
    alphabet = "bcdfghjklmnpqrstvwxz2456789"
    number = int(digest[:16], 16)
    out = []
    for _ in range(size):
        number, rem = divmod(number, len(alphabet))
        out.append(alphabet[rem])
    return "".join(out)


def rand_suffix(seed: str, size: int = 5) -> str:
    # Seeded on purpose: the simulation must replay identically for a given
    # lab. Not a source of randomness for anything security-relevant -- tokens
    # come from `secrets` in k8slab/security.py (CWE-338 does not apply here).
    rng = random.Random(seed)
    alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    return "".join(rng.choice(alphabet) for _ in range(size))


def deep_get(obj: Any, path: str, default: Any = None) -> Any:
    """``deep_get(pod, 'spec.containers.0.image')``"""
    cur = obj
    for part in path.split("."):
        if isinstance(cur, dict):
            if part not in cur:
                return default
            cur = cur[part]
        elif isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return default
        else:
            return default
    return default if cur is None else cur


def annotation(obj: dict, key: str, default: Any = None) -> Any:
    """Read metadata.annotations[key] -- keys contain dots, so deep_get can't."""
    return (deep_get(obj, "metadata.annotations", {}) or {}).get(key, default)


def label(obj: dict, key: str, default: Any = None) -> Any:
    """Read metadata.labels[key] safely (label keys may contain dots and slashes)."""
    return (deep_get(obj, "metadata.labels", {}) or {}).get(key, default)


def deep_set(obj: dict, path: str, value: Any) -> None:
    parts = path.split(".")
    cur = obj
    for part in parts[:-1]:
        if isinstance(cur, list):
            cur = cur[int(part)]
        else:
            cur = cur.setdefault(part, {})
    if isinstance(cur, list):
        cur[int(parts[-1])] = value
    else:
        cur[parts[-1]] = value


def match_labels(labels: Dict[str, str], selector: Any) -> bool:
    """Match a label set against a Kubernetes selector (map or matchLabels/Expressions)."""
    if not selector:
        return False
    labels = labels or {}
    if isinstance(selector, dict) and (
            "matchLabels" in selector or "matchExpressions" in selector):
        for key, val in (selector.get("matchLabels") or {}).items():
            if str(labels.get(key)) != str(val):
                return False
        for expr in selector.get("matchExpressions") or []:
            key = expr.get("key")
            op = (expr.get("operator") or "In")
            values = [str(v) for v in (expr.get("values") or [])]
            have = labels.get(key)
            if op == "In" and str(have) not in values:
                return False
            if op == "NotIn" and str(have) in values:
                return False
            if op == "Exists" and key not in labels:
                return False
            if op == "DoesNotExist" and key in labels:
                return False
        return True
    if isinstance(selector, dict):
        return all(str(labels.get(k)) == str(v) for k, v in selector.items())
    return False


def parse_selector_string(text: str) -> Dict[str, Any]:
    """Parse ``-l app=web,tier!=db,env`` into a matchExpressions selector."""
    match_labels_map: Dict[str, str] = {}
    expressions: List[dict] = []
    for chunk in [c.strip() for c in (text or "").split(",") if c.strip()]:
        if "!=" in chunk:
            key, _, val = chunk.partition("!=")
            expressions.append({"key": key.strip(), "operator": "NotIn",
                                "values": [val.strip()]})
        elif "=" in chunk:
            key, _, val = chunk.partition("=")
            match_labels_map[key.strip().rstrip("=")] = val.strip()
        elif chunk.startswith("!"):
            expressions.append({"key": chunk[1:].strip(), "operator": "DoesNotExist"})
        else:
            expressions.append({"key": chunk, "operator": "Exists"})
    out: Dict[str, Any] = {}
    if match_labels_map:
        out["matchLabels"] = match_labels_map
    if expressions:
        out["matchExpressions"] = expressions
    return out


# --------------------------------------------------------------------------
# object key + cluster state
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Key:
    kind: str
    namespace: str
    name: str

    def __str__(self) -> str:
        return f"{self.kind}/{self.namespace}/{self.name}" if self.namespace \
            else f"{self.kind}/{self.name}"


@dataclass
class Event:
    type: str            # Normal | Warning
    reason: str
    message: str
    involved: str
    namespace: str = "default"
    count: int = 1
    tick: int = 0
    at: float = field(default_factory=time.time)


class Cluster:
    """In-memory cluster state: objects, events and the simulation clock."""

    def __init__(self, name: str = "lab-cluster"):
        self.name = name
        self.objects: Dict[Key, dict] = {}
        self.events: List[Event] = []
        self.tick: int = 0
        self.started: float = time.time()
        self.uid_counter: int = 0
        self.listeners: List[Any] = []       # called after each reconcile
        self.load: Dict[str, float] = {}     # workload key -> synthetic cpu % load
        self.chaos: Dict[str, str] = {}      # object key -> injected failure mode
        self.current_namespace: str = "default"
        self.current_user: str = "admin"
        self.rbac_enforced: bool = False
        self.audit: List[str] = []
        self.current_command: str = ""
        # --- cluster administration state (kubeadm / etcd / PKI / registry) ---
        self.version: str = "1.30.2"          # control-plane version
        self.etcd_snapshots: Dict[str, dict] = {}
        self.registry: Dict[str, dict] = {}   # image -> {private, digest, built}
        self.kubeconfig: Dict[str, Any] = {
            "clusters": {"lab-cluster": {"server": "https://127.0.0.1:6443"}},
            "users": {"admin": {"client-certificate": "admin.crt",
                                "groups": ["system:masters"], "expires_in_days": 364}},
            "contexts": {"lab": {"cluster": "lab-cluster", "user": "admin",
                                 "namespace": "default"}},
            "current-context": "lab",
        }
        self.pki: Dict[str, int] = {          # component -> days until expiry
            "apiserver": 364, "apiserver-kubelet-client": 364,
            "front-proxy-client": 364, "etcd-server": 364, "etcd-peer": 364,
            "ca": 3650,
        }

    # -- basic CRUD -------------------------------------------------------
    def next_uid(self) -> str:
        self.uid_counter += 1
        return f"{self.uid_counter:08x}-lab0-4000-8000-{self.uid_counter:012x}"

    def key_of(self, obj: dict) -> Key:
        kind = obj.get("kind", "")
        rk = resolve_kind(kind)
        ns = ""
        if rk is None or rk.namespaced:
            ns = deep_get(obj, "metadata.namespace") or "default"
        return Key(kind, ns, deep_get(obj, "metadata.name") or "")

    def put(self, obj: dict) -> dict:
        key = self.key_of(obj)
        self.objects[key] = obj
        return obj

    def get(self, kind: str, namespace: str, name: str) -> Optional[dict]:
        rk = resolve_kind(kind)
        kind_name = rk.kind if rk else kind
        ns = namespace if (rk is None or rk.namespaced) else ""
        return self.objects.get(Key(kind_name, ns, name))

    def delete(self, kind: str, namespace: str, name: str) -> Optional[dict]:
        rk = resolve_kind(kind)
        kind_name = rk.kind if rk else kind
        ns = namespace if (rk is None or rk.namespaced) else ""
        return self.objects.pop(Key(kind_name, ns, name), None)

    def list(self, kind: str, namespace: Optional[str] = None,
             selector: Any = None) -> List[dict]:
        rk = resolve_kind(kind)
        kind_name = rk.kind if rk else kind
        out = []
        for key, obj in self.objects.items():
            if key.kind != kind_name:
                continue
            if namespace not in (None, "", "*") and key.namespace != namespace:
                continue
            if selector and not match_labels(deep_get(obj, "metadata.labels", {}) or {},
                                             selector):
                continue
            out.append(obj)
        return sorted(out, key=lambda o: (deep_get(o, "metadata.namespace") or "",
                                          deep_get(o, "metadata.name") or ""))

    def all_objects(self) -> List[dict]:
        return list(self.objects.values())

    # -- events -----------------------------------------------------------
    def record(self, etype: str, reason: str, message: str, involved: str,
               namespace: str = "default") -> None:
        for ev in reversed(self.events[-40:]):
            if (ev.reason, ev.message, ev.involved) == (reason, message, involved):
                ev.count += 1
                ev.tick = self.tick
                ev.at = time.time()
                return
        self.events.append(Event(etype, reason, message, involved, namespace,
                                 tick=self.tick))
        if len(self.events) > 600:
            del self.events[:200]

    # -- misc -------------------------------------------------------------
    def namespaces(self) -> List[str]:
        return [deep_get(n, "metadata.name") for n in self.list("Namespace")]

    def age_of(self, obj: dict) -> str:
        created = deep_get(obj, "metadata.creationTick", 0)
        return fmt_age(self.tick - created)

    def snapshot(self) -> dict:
        return {
            "tick": self.tick,
            "objects": [copy.deepcopy(o) for o in self.objects.values()],
            "load": dict(self.load),
            "chaos": dict(self.chaos),
        }


def fmt_age(ticks: int) -> str:
    """One simulation tick == 1 simulated second."""
    seconds = max(0, int(ticks))
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m{seconds % 60 // 1 % 60}s" if seconds % 60 else \
            f"{seconds // 60}m"
    if seconds < 86400:
        return f"{seconds // 3600}h{(seconds % 3600) // 60}m" if seconds % 3600 >= 60 \
            else f"{seconds // 3600}h"
    return f"{seconds // 86400}d{(seconds % 86400) // 3600}h"
