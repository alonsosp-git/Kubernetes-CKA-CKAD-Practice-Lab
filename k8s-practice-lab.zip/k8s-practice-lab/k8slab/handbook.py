"""The handbook index.

Every topic links the concept notes, the kubectl commands, a starter YAML
snippet and the *page image* extracted from the Kubernetes Handbook PDF, so the
GUI can show the original diagram next to whatever you are practising.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

PAGES_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         "handbook", "pages")


@dataclass
class Topic:
    key: str
    title: str
    pages: List[int]                     # PDF page numbers (1-based)
    summary: str
    bullets: List[str] = field(default_factory=list)
    commands: List[str] = field(default_factory=list)
    yaml: str = ""
    gotchas: List[str] = field(default_factory=list)
    interview: List[str] = field(default_factory=list)
    lab: str = ""                        # matching script in labs/

    @property
    def lab_number(self) -> Optional[int]:
        """The numeric prefix of this topic's lab script, e.g. 4 for lab 04."""
        if not self.lab:
            return None
        head = self.lab.split("-", 1)[0]
        return int(head) if head.isdigit() else None

    @property
    def section(self) -> str:
        for name, keys in SECTIONS:
            if self.key in keys:
                return name
        return ""

    def page_files(self) -> List[str]:
        out = []
        for page in self.pages:
            path = os.path.join(PAGES_DIR, f"page_{page:02d}.png")
            if os.path.isfile(path):
                out.append(path)
        return out


def _t(*args, **kwargs) -> Topic:
    return Topic(*args, **kwargs)


TOPICS: Dict[str, Topic] = {}


def add(topic: Topic) -> None:
    TOPICS[topic.key] = topic


# --------------------------------------------------------------------------
add(_t("introduction", "Introduction to Kubernetes", [3],
       "Kubernetes (K8s) is an open-source container orchestration platform that "
       "automates the deployment, scaling and management of containerized "
       "applications.",
       bullets=[
           "Automates deployment, scaling and operations",
           "Self-healing: restarts, reschedules and replaces failed containers",
           "Built-in load balancing and service discovery",
           "Efficient resource utilisation through bin-packing",
           "Declarative configuration -- you describe desired state, not steps",
           "Portable: cloud, on-prem or hybrid",
       ],
       commands=["kubectl cluster-info", "kubectl get nodes -o wide",
                 "kubectl api-resources", "kubectl version"],
       interview=["What problem does Kubernetes solve that Docker alone does not?",
                  "Explain declarative vs imperative configuration.",
                  "What does 'self-healing' actually mean in Kubernetes?"],
       lab="01-fundamentals.kubectl"))

add(_t("architecture", "Kubernetes Architecture", [4, 39, 40, 41, 42, 43, 44, 49],
       "A cluster is a control plane plus worker nodes. The control plane decides "
       "what should run; the nodes actually run it.",
       bullets=[
           "kube-apiserver -- the front door; every request goes through it",
           "etcd -- consistent key/value store holding all cluster state",
           "kube-scheduler -- assigns Pending pods to nodes",
           "kube-controller-manager -- runs the reconcile loops",
           "kubelet -- node agent that makes pods actually run",
           "kube-proxy -- programs iptables/IPVS rules for Service traffic",
           "container runtime -- containerd / CRI-O actually starts containers",
       ],
       commands=["kubectl get nodes -o wide", "kubectl describe node lab-worker-1",
                 "kubectl cluster-info", "kubectl top nodes"],
       interview=["Walk a request through the control plane from kubectl to a running pod.",
                  "What happens if etcd is lost?",
                  "Which component would you check first if pods stay Pending?"],
       lab="02-architecture.kubectl"))

add(_t("pods", "Pods", [5],
       "A Pod is the smallest deployable unit: one or more containers that share a "
       "network namespace, storage volumes and a lifecycle.",
       bullets=[
           "Containers in a Pod share the same IP and can talk over localhost",
           "Pods are ephemeral -- never rely on a pod's identity or IP",
           "You almost never create bare Pods in production; use a controller",
           "A Pod is scheduled to exactly one node",
       ],
       commands=["kubectl run web --image=nginx:1.25 --port=80",
                 "kubectl get pods -o wide", "kubectl describe pod web",
                 "kubectl logs web", "kubectl exec web -- env",
                 "kubectl delete pod web"],
       yaml="""apiVersion: v1
kind: Pod
metadata:
  name: nginx-pod
  labels:
    app: nginx
spec:
  containers:
    - name: nginx
      image: nginx:1.25
      ports:
        - containerPort: 80
      resources:
        requests:
          cpu: 100m
          memory: 128Mi
        limits:
          cpu: 500m
          memory: 256Mi
""",
       gotchas=["A bare pod is not rescheduled if its node dies -- nothing owns it.",
                "`kubectl delete pod` on a Deployment-managed pod just creates a new one."],
       interview=["Why is the Pod, not the container, the smallest unit?",
                  "What do containers in the same Pod share?",
                  "How do you get a shell inside a running pod?"],
       lab="03-pods.kubectl"))

add(_t("deployments", "Deployments", [6],
       "A Deployment manages ReplicaSets, which manage Pods. It keeps the desired "
       "number of pods running and handles rolling updates and rollbacks.",
       bullets=[
           "Deployment -> ReplicaSet -> Pod is the ownership chain",
           "Each template change creates a new ReplicaSet (a new revision)",
           "RollingUpdate (default) replaces pods gradually; Recreate kills first",
           "maxSurge / maxUnavailable control the rollout speed",
       ],
       commands=["kubectl create deployment web --image=nginx:1.25 --replicas=3",
                 "kubectl get deploy,rs,pods", "kubectl scale deploy/web --replicas=5",
                 "kubectl set image deploy/web web=nginx:1.27",
                 "kubectl rollout status deploy/web",
                 "kubectl rollout history deploy/web",
                 "kubectl rollout undo deploy/web"],
       yaml="""apiVersion: apps/v1
kind: Deployment
metadata:
  name: web
  labels:
    app: web
spec:
  replicas: 3
  selector:
    matchLabels:
      app: web
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: web
    spec:
      containers:
        - name: web
          image: nginx:1.25
          ports:
            - containerPort: 80
          resources:
            requests:
              cpu: 100m
              memory: 128Mi
            limits:
              cpu: 500m
              memory: 256Mi
""",
       gotchas=["spec.selector.matchLabels MUST match spec.template.metadata.labels.",
                "selector is immutable on a real cluster -- you cannot edit it later."],
       interview=["What is the difference between a Deployment and a ReplicaSet?",
                  "How does a rolling update actually work?",
                  "How do you roll back to a specific revision?"],
       lab="04-deployments.kubectl"))

add(_t("replicasets", "ReplicaSets", [8],
       "A ReplicaSet ensures a specified number of pod replicas are running at any "
       "time. Deployments create and manage them for you.",
       bullets=["Uses a label selector to adopt matching pods",
                "Recreates pods that are deleted or whose node dies",
                "You rarely create one directly -- use a Deployment"],
       commands=["kubectl get rs", "kubectl describe rs <name>",
                 "kubectl get pods --show-labels", "kubectl scale rs/<name> --replicas=4"],
       interview=["What happens if you manually label a pod so it matches a "
                  "ReplicaSet selector?",
                  "Why does deleting a ReplicaSet's pod not reduce the replica count?"],
       lab="04-deployments.kubectl"))

add(_t("services", "Services", [7],
       "A Service is a stable abstraction over a changing set of Pods, selected by "
       "labels, with a stable virtual IP and DNS name.",
       bullets=[
           "ClusterIP  -- internal only (default)",
           "NodePort   -- exposes on every node at port 30000-32767",
           "LoadBalancer -- asks the cloud for an external IP",
           "ExternalName -- CNAME to an external DNS name",
           "Headless (clusterIP: None) -- DNS returns pod IPs directly",
           "DNS name: <service>.<namespace>.svc.cluster.local",
       ],
       commands=["kubectl expose deploy/web --port=80 --target-port=80",
                 "kubectl get svc -o wide", "kubectl describe svc web",
                 "kubectl exec <pod> -- curl web", "kubectl exec <pod> -- nslookup web"],
       yaml="""apiVersion: v1
kind: Service
metadata:
  name: web
spec:
  type: ClusterIP
  selector:
    app: web
  ports:
    - name: http
      port: 80
      targetPort: 80
      protocol: TCP
""",
       gotchas=["No endpoints? The Service selector does not match your pod labels.",
                "Endpoints only include pods that are Ready -- check readiness probes."],
       interview=["Explain the four Service types.",
                  "How does a Service find its pods?",
                  "What is a headless Service used for?"],
       lab="05-services.kubectl"))

add(_t("configmaps", "ConfigMaps & Secrets", [9],
       "ConfigMaps hold non-sensitive configuration; Secrets hold sensitive data "
       "(base64-encoded, not encrypted by default). Both decouple config from images.",
       bullets=["Consume as environment variables (env / envFrom) or mounted files",
                "Mounted ConfigMap keys become files in the mount directory",
                "Secrets are base64 -- enable encryption at rest for real secrecy",
                "Changing a mounted ConfigMap updates the file; env vars need a restart"],
       commands=["kubectl create configmap app-config --from-literal=APP_PORT=8080",
                 "kubectl get cm app-config -o yaml",
                 "kubectl create secret generic db-secret --from-literal=password=s3cr3t",
                 "kubectl exec <pod> -- env",
                 "kubectl exec <pod> -- cat /etc/config/app.properties"],
       yaml="""apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  APP_PORT: "8080"
  LOG_LEVEL: debug
  app.properties: |
    feature.flags=beta
    cache.ttl=300
""",
       gotchas=["A pod referencing a missing ConfigMap stays in "
                "CreateContainerConfigError.",
                "Secrets are only base64 -- anyone with get access can decode them."],
       interview=["ConfigMap vs Secret -- what is actually different?",
                  "How do you roll pods when a ConfigMap changes?",
                  "Two ways to consume a ConfigMap in a pod?"],
       lab="06-config.kubectl"))

add(_t("namespaces", "Namespaces & ResourceQuotas", [10],
       "Namespaces partition one cluster into virtual clusters. ResourceQuotas and "
       "LimitRanges cap what a namespace may consume.",
       bullets=["Names must be unique within a namespace, not across the cluster",
                "Not all objects are namespaced (Node, PV, StorageClass, ClusterRole)",
                "ResourceQuota limits totals: pods, cpu, memory, object counts",
                "LimitRange sets per-container defaults and min/max"],
       commands=["kubectl create namespace dev",
                 "kubectl config set-context --current --namespace=dev",
                 "kubectl get all -n dev", "kubectl get ns",
                 "kubectl describe quota -n dev",
                 "kubectl delete namespace dev"],
       yaml="""apiVersion: v1
kind: ResourceQuota
metadata:
  name: dev-quota
  namespace: dev
spec:
  hard:
    pods: "10"
    requests.cpu: "2"
    requests.memory: 4Gi
    limits.cpu: "4"
    limits.memory: 8Gi
""",
       interview=["Which resources are cluster-scoped rather than namespaced?",
                  "How do you stop one team exhausting the cluster?",
                  "What happens to objects when you delete a namespace?"],
       lab="07-namespaces.kubectl"))

add(_t("pv", "Persistent Volumes", [11],
       "A PersistentVolume is a piece of storage in the cluster, provisioned by an "
       "administrator or dynamically by a StorageClass. Its lifecycle is independent "
       "of any pod.",
       bullets=["Access modes: RWO (one node), ROX (many read), RWX (many write)",
                "Reclaim policy: Retain, Delete, (Recycle is deprecated)",
                "Phases: Available -> Bound -> Released -> Failed"],
       commands=["kubectl get pv", "kubectl describe pv <name>",
                 "kubectl get pv,pvc"],
       yaml="""apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-manual
spec:
  capacity:
    storage: 5Gi
  accessModes:
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Retain
  storageClassName: manual
  hostPath:
    path: /mnt/data
""",
       interview=["Explain the PV/PVC binding process.",
                  "What is the difference between Retain and Delete reclaim policies?",
                  "What do RWO/ROX/RWX actually restrict?"],
       lab="08-storage.kubectl"))

add(_t("pvc", "PersistentVolumeClaims", [12],
       "A PVC is a request for storage by a user. Kubernetes binds it to a matching "
       "PV, or dynamically provisions one via a StorageClass.",
       bullets=["The pod references the PVC, never the PV directly",
                "Binding matches on capacity, access modes and storageClassName",
                "A PVC stuck Pending means nothing matched, or WaitForFirstConsumer"],
       commands=["kubectl get pvc", "kubectl describe pvc <name>",
                 "kubectl get pods -o wide"],
       yaml="""apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: data-claim
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: standard
  resources:
    requests:
      storage: 2Gi
""",
       gotchas=["A pod mounting an unbound PVC stays Pending forever -- describe the PVC."],
       interview=["Why does a pod use a PVC instead of a PV?",
                  "What does a Pending PVC usually mean?"],
       lab="08-storage.kubectl"))

add(_t("storage-classes", "Storage Classes", [13],
       "A StorageClass describes a 'class' of storage and tells Kubernetes how to "
       "provision PersistentVolumes dynamically.",
       bullets=["provisioner -- which CSI driver creates the volume",
                "parameters -- driver-specific (disk type, fsType, IOPS)",
                "reclaimPolicy -- what happens to the PV when the PVC is deleted",
                "volumeBindingMode: Immediate vs WaitForFirstConsumer"],
       commands=["kubectl get sc", "kubectl describe sc standard"],
       yaml="""apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: fast-ssd
provisioner: kubernetes.io/aws-ebs
parameters:
  type: gp3
  fsType: ext4
reclaimPolicy: Delete
volumeBindingMode: WaitForFirstConsumer
allowVolumeExpansion: true
""",
       interview=["Why use WaitForFirstConsumer?",
                  "What makes a StorageClass the default?"],
       lab="08-storage.kubectl"))

add(_t("dynamic-provisioning", "Dynamic Provisioning", [14],
       "With a StorageClass in place, creating a PVC automatically creates the "
       "backing PV -- no administrator required.",
       bullets=["No pre-created PVs needed",
                "The provisioner (CSI driver) does the real work",
                "Delete reclaim policy removes the disk when the PVC goes away"],
       commands=["kubectl apply -f manifests/pvc-dynamic.yaml",
                 "kubectl get pvc,pv"],
       lab="08-storage.kubectl"))

add(_t("statefulsets", "StatefulSets", [15],
       "A StatefulSet is for stateful applications: stable network identity, stable "
       "storage and ordered, graceful deployment and scaling.",
       bullets=["Pods are named <sts>-0, <sts>-1 ... and created in order",
                "Each pod gets its own PVC from volumeClaimTemplates",
                "Requires a headless Service for stable DNS",
                "Deleting a StatefulSet does NOT delete its PVCs"],
       commands=["kubectl get sts", "kubectl get pods -l app=db",
                 "kubectl get pvc", "kubectl scale sts/db --replicas=3"],
       yaml="""apiVersion: v1
kind: Service
metadata:
  name: db
spec:
  clusterIP: None
  selector:
    app: db
  ports:
    - port: 5432
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: db
spec:
  serviceName: db
  replicas: 3
  selector:
    matchLabels:
      app: db
  template:
    metadata:
      labels:
        app: db
    spec:
      containers:
        - name: postgres
          image: postgres:16
          ports:
            - containerPort: 5432
          volumeMounts:
            - name: data
              mountPath: /var/lib/postgresql/data
  volumeClaimTemplates:
    - metadata:
        name: data
      spec:
        accessModes: [ReadWriteOnce]
        resources:
          requests:
            storage: 1Gi
""",
       interview=["Deployment vs StatefulSet -- when do you need which?",
                  "Why does a StatefulSet need a headless Service?",
                  "What happens to PVCs when you scale a StatefulSet down?"],
       lab="09-statefulsets.kubectl"))

add(_t("daemonsets", "DaemonSets", [16],
       "A DaemonSet ensures a copy of a Pod runs on all (or selected) nodes -- "
       "log collectors, node exporters, CNI agents.",
       bullets=["One pod per node by default; new nodes get one automatically",
                "Use nodeSelector or affinity to target a subset of nodes",
                "Needs tolerations to run on tainted nodes (e.g. control-plane)"],
       commands=["kubectl get ds -A", "kubectl get pods -o wide -l app=node-exporter",
                 "kubectl describe ds <name>"],
       yaml="""apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: node-exporter
spec:
  selector:
    matchLabels:
      app: node-exporter
  template:
    metadata:
      labels:
        app: node-exporter
    spec:
      tolerations:
        - operator: Exists
      containers:
        - name: node-exporter
          image: prom/node-exporter:v1.8.1
          ports:
            - containerPort: 9100
""",
       interview=["Give three real use cases for a DaemonSet.",
                  "How do you run a DaemonSet pod on control-plane nodes?"],
       lab="10-daemonsets.kubectl"))

add(_t("jobs", "Jobs", [17],
       "A Job creates one or more Pods that run to completion and then stop -- "
       "batch work, migrations, one-off tasks.",
       bullets=["completions -- how many successful pods are required",
                "parallelism -- how many run at once",
                "backoffLimit -- retries before the Job is marked Failed",
                "restartPolicy must be OnFailure or Never"],
       commands=["kubectl create job pi --image=busybox:1.36",
                 "kubectl get jobs", "kubectl get pods -l job-name=pi",
                 "kubectl logs job/pi"],
       yaml="""apiVersion: batch/v1
kind: Job
metadata:
  name: data-import
spec:
  completions: 3
  parallelism: 2
  backoffLimit: 4
  template:
    metadata:
      labels:
        job-name: data-import
    spec:
      restartPolicy: Never
      containers:
        - name: importer
          image: busybox:1.36
          command: ["sh", "-c", "echo importing; sleep 3"]
""",
       interview=["completions vs parallelism?",
                  "Why can't a Job pod use restartPolicy: Always?"],
       lab="11-jobs.kubectl"))

add(_t("cronjobs", "CronJobs", [18],
       "A CronJob creates Jobs on a repeating schedule using standard cron syntax.",
       bullets=["schedule uses 5-field cron: minute hour day month weekday",
                "concurrencyPolicy: Allow | Forbid | Replace",
                "successfulJobsHistoryLimit / failedJobsHistoryLimit prune old Jobs",
                "suspend: true pauses it without deleting"],
       commands=["kubectl create cronjob report --image=busybox:1.36 "
                 "--schedule='*/1 * * * *'",
                 "kubectl get cj", "kubectl get jobs --watch",
                 "kubectl patch cj report -p '{\"spec\":{\"suspend\":true}}'"],
       yaml="""apiVersion: batch/v1
kind: CronJob
metadata:
  name: nightly-report
spec:
  schedule: "0 0 * * *"
  concurrencyPolicy: Forbid
  successfulJobsHistoryLimit: 3
  jobTemplate:
    spec:
      template:
        metadata:
          labels:
            cronjob: nightly-report
        spec:
          restartPolicy: OnFailure
          containers:
            - name: report
              image: busybox:1.36
              command: ["sh", "-c", "echo building report"]
""",
       interview=["What does concurrencyPolicy: Forbid do?",
                  "How do you pause a CronJob without deleting it?"],
       lab="11-jobs.kubectl"))

add(_t("init-containers", "Init Containers", [19],
       "Init containers run to completion, in order, before the app containers "
       "start. Use them for setup, waiting on dependencies and pre-flight checks.",
       bullets=["Run sequentially; each must succeed before the next starts",
                "If one fails, the kubelet restarts the pod (per restartPolicy)",
                "Can hold tools/credentials you do not want in the app image",
                "Pod status shows Init:0/2 while they run"],
       commands=["kubectl get pods", "kubectl describe pod <name>",
                 "kubectl logs <pod> -c <init-container>"],
       yaml="""apiVersion: v1
kind: Pod
metadata:
  name: app-with-init
  labels:
    app: app-with-init
spec:
  initContainers:
    - name: wait-for-db
      image: busybox:1.36
      command: ["sh", "-c", "until nslookup db; do sleep 2; done"]
    - name: migrate
      image: busybox:1.36
      command: ["sh", "-c", "echo running migrations"]
  containers:
    - name: app
      image: nginx:1.25
""",
       interview=["Init container vs sidecar -- what is the difference?",
                  "What happens if an init container keeps failing?"],
       lab="12-init-multicontainer.kubectl"))

add(_t("multi-container", "Multi-Container Pods", [20],
       "Sidecar, ambassador and adapter are the three classic multi-container "
       "patterns. Containers share the pod's network and can share volumes.",
       bullets=["Sidecar -- helper alongside the app (log shipper, proxy)",
                "Ambassador -- proxies outbound connections",
                "Adapter -- reshapes the app's output for a consumer",
                "Share data with an emptyDir volume mounted in both"],
       commands=["kubectl logs <pod> -c <container>",
                 "kubectl exec <pod> -c <container> -- sh"],
       yaml="""apiVersion: v1
kind: Pod
metadata:
  name: web-with-sidecar
  labels:
    app: web-with-sidecar
spec:
  volumes:
    - name: logs
      emptyDir: {}
  containers:
    - name: web
      image: nginx:1.25
      volumeMounts:
        - name: logs
          mountPath: /var/log/nginx
    - name: log-shipper
      image: fluent/fluent-bit:3.0
      volumeMounts:
        - name: logs
          mountPath: /var/log/nginx
""",
       interview=["Name the three multi-container patterns and an example of each.",
                  "How do two containers in a pod share files?"],
       lab="12-init-multicontainer.kubectl"))

add(_t("labels", "Labels & Selectors", [21],
       "Labels are key/value metadata for grouping. Selectors query them -- this is "
       "how Services find Pods and controllers find their children.",
       bullets=["Equality selectors: app=web, tier!=db",
                "Set-based: 'env in (prod,staging)', '!legacy'",
                "Recommended labels: app.kubernetes.io/name, /instance, /version",
                "Labels are for selection; annotations are for arbitrary metadata"],
       commands=["kubectl get pods --show-labels",
                 "kubectl get pods -l app=web",
                 "kubectl get pods -l 'tier!=db'",
                 "kubectl label pod web env=prod",
                 "kubectl label pod web env=dev --overwrite",
                 "kubectl label pod web env-"],
       interview=["How does a Service use labels?",
                  "Difference between a label and an annotation?"],
       lab="13-labels.kubectl"))

add(_t("annotations", "Annotations", [22],
       "Annotations attach arbitrary, non-identifying metadata to objects -- build "
       "info, tool configuration, change causes. They cannot be used as selectors.",
       bullets=["No size/character limits like labels have",
                "Used heavily by controllers (ingress rewrite rules, TLS issuers)",
                "kubernetes.io/change-cause shows up in rollout history"],
       commands=["kubectl annotate deploy/web owner=platform-team",
                 "kubectl describe deploy web",
                 "kubectl annotate deploy/web owner-"],
       interview=["When would you pick an annotation over a label?"],
       lab="13-labels.kubectl"))

add(_t("taints", "Taints & Tolerations", [23],
       "Taints are applied to nodes to repel pods; tolerations are set on pods to "
       "allow them onto tainted nodes. Together they keep workloads off nodes they "
       "do not belong on.",
       bullets=["Effects: NoSchedule, PreferNoSchedule, NoExecute",
                "NoExecute also evicts already-running pods that do not tolerate",
                "Control-plane nodes are tainted by default",
                "A toleration allows -- it does not guarantee -- placement"],
       commands=["kubectl taint nodes lab-worker-2 dedicated=payments:NoSchedule",
                 "kubectl describe node lab-worker-2",
                 "kubectl taint nodes lab-worker-2 dedicated-"],
       yaml="""apiVersion: v1
kind: Pod
metadata:
  name: payments
  labels:
    app: payments
spec:
  tolerations:
    - key: dedicated
      operator: Equal
      value: payments
      effect: NoSchedule
  containers:
    - name: app
      image: nginx:1.25
""",
       gotchas=["Tolerating a taint does not attract a pod to that node -- "
                "use nodeAffinity for that."],
       interview=["Taints/tolerations vs node affinity -- which does what?",
                  "What does NoExecute do that NoSchedule does not?"],
       lab="14-scheduling.kubectl"))

add(_t("node-affinity", "Node Affinity", [24],
       "Node affinity schedules pods onto nodes based on node labels -- a richer "
       "nodeSelector with required and preferred rules.",
       bullets=["requiredDuringScheduling... -- hard rule, pod stays Pending if unmet",
                "preferredDuringScheduling... -- soft rule with a weight",
                "Operators: In, NotIn, Exists, DoesNotExist, Gt, Lt"],
       commands=["kubectl get nodes --show-labels",
                 "kubectl label node lab-worker-3 gpu=true",
                 "kubectl get pods -o wide"],
       yaml="""apiVersion: v1
kind: Pod
metadata:
  name: gpu-job
  labels:
    app: gpu-job
spec:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: disktype
                operator: In
                values: [ssd]
      preferredDuringSchedulingIgnoredDuringExecution:
        - weight: 50
          preference:
            matchExpressions:
              - key: topology.kubernetes.io/zone
                operator: In
                values: [zone-b]
  containers:
    - name: app
      image: nginx:1.25
""",
       interview=["nodeSelector vs nodeAffinity?",
                  "What does 'IgnoredDuringExecution' mean?"],
       lab="14-scheduling.kubectl"))

add(_t("pod-affinity", "Pod Affinity & Anti-Affinity", [25],
       "Place pods relative to *other pods*: co-locate chatty services (affinity) or "
       "spread replicas across failure domains (anti-affinity).",
       bullets=["topologyKey defines the domain: hostname, zone, region",
                "Anti-affinity with topologyKey hostname = one replica per node",
                "Required rules can leave pods Pending if the topology is too small"],
       commands=["kubectl get pods -o wide", "kubectl describe pod <pending-pod>"],
       yaml="""apiVersion: apps/v1
kind: Deployment
metadata:
  name: spread
spec:
  replicas: 3
  selector:
    matchLabels:
      app: spread
  template:
    metadata:
      labels:
        app: spread
    spec:
      affinity:
        podAntiAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            - labelSelector:
                matchLabels:
                  app: spread
              topologyKey: kubernetes.io/hostname
      containers:
        - name: app
          image: nginx:1.25
""",
       interview=["How do you guarantee replicas land on different nodes?",
                  "What is topologyKey and why does it matter?"],
       lab="14-scheduling.kubectl"))

add(_t("resources", "Resource Requests & Limits", [26],
       "Requests are what the scheduler reserves; limits are the hard ceiling the "
       "runtime enforces. Together they set the pod's QoS class.",
       bullets=["CPU is compressible -- over-limit means throttling",
                "Memory is not -- over-limit means OOMKilled",
                "QoS: Guaranteed (requests==limits) > Burstable > BestEffort",
                "BestEffort pods are evicted first under node pressure"],
       commands=["kubectl top pods", "kubectl top nodes",
                 "kubectl describe node lab-worker-1",
                 "kubectl describe pod <name>"],
       gotchas=["No requests set means the scheduler assumes ~0 -- you will overcommit.",
                "Setting only limits makes requests equal limits."],
       interview=["What happens when a container exceeds its CPU limit? Its memory limit?",
                  "Explain the three QoS classes."],
       lab="15-resources-probes.kubectl"))

add(_t("probes", "Liveness, Readiness & Startup Probes", [27],
       "Probes tell the kubelet whether a container is alive, ready for traffic, and "
       "finished starting.",
       bullets=["liveness  -- failing restarts the container",
                "readiness -- failing removes the pod from Service endpoints",
                "startup   -- disables the other two until the app has booted",
                "Handlers: httpGet, tcpSocket, exec"],
       commands=["kubectl describe pod <name>", "kubectl get endpoints",
                 "sim chaos <pod> notready"],
       yaml="""apiVersion: v1
kind: Pod
metadata:
  name: probed
  labels:
    app: probed
spec:
  containers:
    - name: app
      image: nginx:1.25
      startupProbe:
        httpGet:
          path: /healthz
          port: 80
        failureThreshold: 30
        periodSeconds: 5
      readinessProbe:
        httpGet:
          path: /ready
          port: 80
        initialDelaySeconds: 5
        periodSeconds: 10
      livenessProbe:
        httpGet:
          path: /healthz
          port: 80
        initialDelaySeconds: 15
        periodSeconds: 20
""",
       gotchas=["A too-aggressive liveness probe causes restart loops on slow starts "
                "-- that is what startupProbe is for."],
       interview=["Liveness vs readiness -- what breaks if you swap them?",
                  "Why would you add a startup probe?"],
       lab="15-resources-probes.kubectl"))

add(_t("hpa", "Horizontal Pod Autoscaler", [28],
       "The HPA scales the number of pod replicas based on observed metrics, "
       "typically CPU utilisation against requests.",
       bullets=["Requires resource requests to compute utilisation",
                "Requires metrics-server to be installed",
                "desired = ceil(current * currentMetric / targetMetric)",
                "Scales up quickly, down slowly (stabilisation window)"],
       commands=["kubectl autoscale deploy/web --cpu-percent=50 --min=2 --max=10",
                 "kubectl get hpa", "sim load deploy/web 90",
                 "kubectl get hpa -w", "kubectl describe hpa web"],
       yaml="""apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: web
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: web
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 50
""",
       gotchas=["HPA shows <unknown> targets when containers have no CPU requests."],
       interview=["What does the HPA need in order to work at all?",
                  "Why is scale-down slower than scale-up?"],
       lab="16-autoscaling.kubectl"))

add(_t("vpa", "Vertical Pod Autoscaler", [29],
       "The VPA right-sizes CPU/memory requests based on real usage history. Modes: "
       "Off (recommend only), Initial, Auto (recreates pods).",
       bullets=["Prevents both under-provisioning and wasted reservations",
                "Auto mode evicts pods to apply new requests",
                "Do not run VPA and HPA on the same CPU metric"],
       commands=["kubectl get vpa", "kubectl describe vpa web"],
       yaml="""apiVersion: autoscaling.k8s.io/v1
kind: VerticalPodAutoscaler
metadata:
  name: web
spec:
  targetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: web
  updatePolicy:
    updateMode: "Off"
""",
       interview=["Why can HPA and VPA conflict?",
                  "What does updateMode Off give you?"],
       lab="16-autoscaling.kubectl"))

add(_t("cluster-autoscaler", "Cluster Autoscaler", [30],
       "The Cluster Autoscaler adds nodes when pods cannot be scheduled and removes "
       "underutilised nodes.",
       bullets=["Triggered by Pending pods that fail scheduling on resources",
                "Removes nodes that stay underutilised and whose pods can move",
                "Respects PodDisruptionBudgets and node group min/max"],
       commands=["sim node lab-worker-4 add", "kubectl get nodes",
                 "kubectl get pods -o wide", "kubectl drain lab-worker-3 "
                 "--ignore-daemonsets"],
       interview=["What triggers a scale-up? A scale-down?",
                  "How do HPA and Cluster Autoscaler work together?"],
       lab="16-autoscaling.kubectl"))

add(_t("ingress", "Ingress", [31],
       "An Ingress is an API object that manages external HTTP/HTTPS access, with "
       "host- and path-based routing and TLS termination.",
       bullets=["One load balancer can front many services",
                "Rules route by host and path to a backend Service",
                "TLS secrets terminate HTTPS at the ingress",
                "An Ingress does nothing without an Ingress Controller"],
       commands=["kubectl get ingress", "kubectl describe ingress web",
                 "kubectl get svc -n ingress-nginx"],
       yaml="""apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: web
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  ingressClassName: nginx
  rules:
    - host: shop.example.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: web
                port:
                  number: 80
          - path: /api
            pathType: Prefix
            backend:
              service:
                name: api
                port:
                  number: 8080
""",
       interview=["Ingress vs LoadBalancer Service -- when do you use each?",
                  "What happens if no Ingress Controller is installed?"],
       lab="17-ingress.kubectl"))

add(_t("ingress-controller", "Ingress Controller", [32],
       "The Ingress Controller is the pod that actually watches Ingress objects and "
       "programs a reverse proxy (nginx, HAProxy, Traefik, Envoy).",
       bullets=["Runs as a Deployment or DaemonSet, usually behind a LoadBalancer Service",
                "Multiple controllers can coexist -- selected by ingressClassName",
                "It is the component doing TLS termination and routing"],
       commands=["kubectl get pods -n ingress-nginx",
                 "kubectl get ingressclass", "kubectl logs -n ingress-nginx <pod>"],
       lab="17-ingress.kubectl"))

add(_t("network-policies", "Network Policies", [33],
       "NetworkPolicies control which pods can talk to which. By default all pods can "
       "reach all pods -- a policy makes that selective.",
       bullets=["Selecting a pod with any policy switches it to default-deny for that "
                "direction",
                "policyTypes: Ingress, Egress or both",
                "Peers: podSelector, namespaceSelector, ipBlock",
                "Requires a CNI that enforces policy (Calico, Cilium)"],
       commands=["kubectl get netpol", "kubectl describe netpol <name>"],
       yaml="""apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: api-allow-from-web
spec:
  podSelector:
    matchLabels:
      app: api
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app: web
      ports:
        - protocol: TCP
          port: 8080
""",
       interview=["What is the default network behaviour without policies?",
                  "How do you write a deny-all-ingress policy?"],
       lab="18-security.kubectl"))

add(_t("rbac", "RBAC", [34],
       "Role-Based Access Control: Roles and ClusterRoles define permissions; "
       "RoleBindings and ClusterRoleBindings grant them to subjects.",
       bullets=["Role/RoleBinding are namespaced; ClusterRole/ClusterRoleBinding are not",
                "A ClusterRole can be bound in one namespace with a RoleBinding",
                "Rules combine apiGroups + resources + verbs",
                "Everything is deny-by-default and purely additive"],
       commands=["kubectl create role pod-reader --verb=get,list,watch --resource=pods",
                 "kubectl create rolebinding read-pods --role=pod-reader --user=bob",
                 "sim rbac on", "sim user bob",
                 "kubectl auth can-i list pods",
                 "kubectl auth can-i delete deployments"],
       yaml="""apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: pod-reader
  namespace: dev
rules:
  - apiGroups: [""]
    resources: ["pods", "pods/log"]
    verbs: ["get", "list", "watch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: read-pods
  namespace: dev
subjects:
  - kind: User
    name: bob
    apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: Role
  name: pod-reader
  apiGroup: rbac.authorization.k8s.io
""",
       interview=["Role vs ClusterRole?",
                  "How do you grant a ServiceAccount read access in one namespace?",
                  "Can an RBAC rule deny something?"],
       lab="18-security.kubectl"))

add(_t("service-accounts", "Service Accounts", [35],
       "A ServiceAccount is the identity a Pod uses to talk to the API server. Every "
       "namespace has a 'default' one.",
       bullets=["Token is projected into the pod at "
                "/var/run/secrets/kubernetes.io/serviceaccount",
                "Bind it to a Role to give the pod API permissions",
                "Set automountServiceAccountToken: false when the pod does not need it"],
       commands=["kubectl create serviceaccount app-sa",
                 "kubectl create rolebinding app-sa-read --role=pod-reader "
                 "--serviceaccount=default:app-sa",
                 "kubectl get sa",
                 "kubectl auth can-i list pods "
                 "--as=system:serviceaccount:default:app-sa"],
       interview=["User account vs ServiceAccount?",
                  "How does a pod authenticate to the API server?"],
       lab="18-security.kubectl"))

add(_t("authentication", "Authentication", [36],
       "Authentication answers 'who are you?'. Kubernetes supports certificates, "
       "bearer tokens, ServiceAccount tokens and OIDC. There are no user objects.",
       bullets=["x509 client certs: CN = username, O = groups",
                "ServiceAccount tokens are JWTs signed by the API server",
                "OIDC integrates your company identity provider",
                "Authentication happens before authorization"],
       commands=["kubectl config view", "sim user alice", "kubectl auth can-i get pods"],
       interview=["Why are there no User objects in Kubernetes?",
                  "Name three authentication methods."],
       lab="18-security.kubectl"))

add(_t("authorization", "Authorization", [37],
       "Authorization answers 'can you do it?'. Modes: RBAC (default), ABAC, Node, "
       "Webhook. Deny is the default; any allowing module grants access.",
       bullets=["Request attributes: user, group, verb, resource, namespace",
                "RBAC is additive -- there are no deny rules",
                "Node authorizer restricts what kubelets may read"],
       commands=["kubectl auth can-i create deployments",
                 "kubectl auth can-i '*' '*' --list"],
       interview=["Order of the API request path stages?",
                  "Difference between authentication and authorization?"],
       lab="18-security.kubectl"))

add(_t("admission", "Admission Controllers", [38],
       "Admission controllers intercept requests after authorization but before "
       "persistence. Mutating ones change objects; validating ones accept or reject.",
       bullets=["Mutating runs first, then validating",
                "Built-ins: NamespaceLifecycle, LimitRanger, ResourceQuota, "
                "PodSecurity, DefaultStorageClass",
                "Webhooks let you plug in policy engines (OPA/Gatekeeper, Kyverno)"],
       commands=["kubectl apply -f manifests/quota.yaml",
                 "kubectl apply -f manifests/pod-over-quota.yaml"],
       interview=["Mutating vs validating admission?",
                  "Where do admission controllers sit in the request path?"],
       lab="18-security.kubectl"))

add(_t("helm", "Helm", [45],
       "Helm is the package manager for Kubernetes. A Chart is a templated bundle of "
       "manifests; installing it creates a Release.",
       bullets=["Chart = templates + values.yaml + Chart.yaml",
                "Release = an installed instance of a chart",
                "helm upgrade/rollback manage revisions",
                "values.yaml + --set parameterise environments"],
       commands=["helm install web charts/webapp",
                 "helm list",
                 "helm upgrade web charts/webapp --set replicaCount=4",
                 "helm template web charts/webapp",
                 "helm uninstall web"],
       interview=["Chart vs Release vs Repository?",
                  "How do you override values at install time?"],
       lab="19-helm-kustomize.kubectl"))

add(_t("kustomize", "Kustomize", [46],
       "Kustomize customises manifests without templates: a base plus overlays that "
       "patch it per environment. Built into kubectl (-k).",
       bullets=["base/ holds the common manifests",
                "overlays/dev, overlays/prod patch the base",
                "namePrefix, commonLabels, namespace, images, patches",
                "No templating language -- pure YAML merging"],
       commands=["kustomize build kustomize/overlays/dev",
                 "kubectl apply -k kustomize/overlays/dev",
                 "kubectl apply -k kustomize/overlays/prod"],
       interview=["Helm vs Kustomize -- trade-offs?",
                  "What does a strategic-merge patch do?"],
       lab="19-helm-kustomize.kubectl"))

add(_t("operators", "Operators", [47],
       "An Operator encodes human operational knowledge: a CRD defines a new resource "
       "type and a custom controller reconciles it.",
       bullets=["Operator = CRD + custom controller + domain logic",
                "Automates backups, failover, upgrades for stateful software",
                "Built with kubebuilder / Operator SDK"],
       commands=["kubectl get crd", "kubectl api-resources"],
       interview=["What is the operator pattern?",
                  "Why would a database need an operator?"],
       lab="20-crds.kubectl"))

add(_t("crds", "Custom Resource Definitions", [48],
       "CRDs extend the Kubernetes API with your own object kinds, which then behave "
       "like built-in resources.",
       bullets=["Define group, version, kind, plural and a schema",
                "Scope: Namespaced or Cluster",
                "kubectl get <your-kind> works immediately after creation",
                "A CRD without a controller just stores data"],
       commands=["kubectl apply -f manifests/crd.yaml", "kubectl get crd"],
       yaml="""apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: backups.lab.example.com
spec:
  group: lab.example.com
  scope: Namespaced
  names:
    plural: backups
    singular: backup
    kind: Backup
  versions:
    - name: v1
      served: true
      storage: true
""",
       interview=["CRD vs Operator?", "What does a CRD do on its own?"],
       lab="20-crds.kubectl"))

add(_t("observability", "Observability", [50],
       "Metrics Server feeds kubectl top and the HPA. Prometheus scrapes and stores "
       "metrics; Grafana visualises; Alertmanager notifies.",
       bullets=["Metrics Server = short-term metrics for autoscaling only",
                "Prometheus = pull-based time series with PromQL",
                "The four golden signals: latency, traffic, errors, saturation",
                "Instrument apps with a /metrics endpoint"],
       commands=["kubectl top nodes", "kubectl top pods -A",
                 "kubectl get events -A"],
       interview=["Why can't you use Metrics Server as your monitoring system?",
                  "What are the golden signals?"],
       lab="21-observability.kubectl"))

add(_t("logging", "Logging", [51],
       "Containers log to stdout/stderr; a node-level agent (DaemonSet) ships those "
       "files to a backend -- EFK (Elasticsearch/Fluentd/Kibana) or Loki + Grafana.",
       bullets=["kubectl logs reads the node's log file -- lost when the pod is deleted",
                "Ship logs off-node with a DaemonSet agent",
                "Loki indexes labels only, which makes it cheaper than Elasticsearch",
                "--previous reads the logs of the last crashed container"],
       commands=["kubectl logs <pod>", "kubectl logs <pod> -c <container>",
                 "kubectl logs -l app=web --tail=50"],
       interview=["Where do container logs physically live?",
                  "Why use a DaemonSet for log collection?"],
       lab="21-observability.kubectl"))

add(_t("troubleshooting", "Troubleshooting", [52],
       "A systematic approach: describe the object, read the events, check the logs, "
       "then check networking and RBAC.",
       bullets=[
           "Pending          -> scheduling problem: resources, taints, affinity, PVC",
           "ImagePullBackOff -> wrong image name/tag or missing registry credentials",
           "CrashLoopBackOff -> the app exits; read logs, then logs --previous",
           "CreateContainerConfigError -> missing ConfigMap/Secret",
           "OOMKilled        -> exceeded the memory limit",
           "Service has no endpoints -> selector does not match pod labels, or not Ready",
       ],
       commands=["kubectl get pods -o wide",
                 "kubectl describe pod <name>",
                 "kubectl logs <name>",
                 "kubectl get events --sort-by=.lastTimestamp",
                 "kubectl get endpoints",
                 "sim chaos <pod> crash",
                 "sim chaos <pod> clear"],
       interview=["Walk me through debugging a CrashLoopBackOff.",
                  "A Service returns nothing -- what do you check, in order?",
                  "A pod is Pending -- name four possible causes."],
       lab="22-troubleshooting.kubectl"))

add(_t("best-practices", "Production Best Practices", [53],
       "The habits that separate a demo cluster from a production one.",
       bullets=["Always set resource requests and limits",
                "Always define readiness (and usually liveness) probes",
                "Run multiple replicas plus a PodDisruptionBudget",
                "Spread replicas with anti-affinity or topology spread constraints",
                "Never use the :latest tag -- pin versions",
                "Run as non-root with a read-only root filesystem",
                "Use namespaces + quotas per team, and RBAC least privilege",
                "Keep manifests in git; deploy with CI/CD (GitOps)"],
       commands=["kubectl get pdb", "kubectl describe deploy web"],
       yaml="""apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: web
spec:
  minAvailable: 2
  selector:
    matchLabels:
      app: web
""",
       interview=["Name five things you would check before calling a workload "
                  "production-ready.",
                  "Why is :latest dangerous?"],
       lab="23-best-practices.kubectl"))

add(_t("interview", "CKA / CKAD Interview Questions", [54],
       "The exam is hands-on and time-pressured. Speed with kubectl matters as much "
       "as knowing the concepts.",
       bullets=["alias k=kubectl and set up bash completion first",
                "kubectl explain <resource>.<field> is your in-exam documentation",
                "--dry-run=client -o yaml generates manifests fast",
                "Always set the namespace: -n or config set-context",
                "CKA is cluster administration; CKAD is application development"],
       commands=["kubectl explain pods.spec.containers",
                 "kubectl create deploy web --image=nginx --dry-run=client -o yaml",
                 "kubectl run tmp --image=busybox --restart=Never -- sleep 3600",
                 "kubectl get pods -A --sort-by=.metadata.name"],
       interview=["What is a Pod?  A Deployment?  A Service?",
                  "How does a rolling update work end to end?",
                  "Explain PV, PVC and StorageClass.",
                  "How does RBAC work?",
                  "What happens when you run kubectl apply?",
                  "How do you debug a pod that will not start?"],
       lab="24-cka-drills.kubectl"))


# --------------------------------------------------------------------------
# Cluster administration -- the topics a workload simulator normally cannot
# reach. Appended at the end so the handbook order is untouched.
# --------------------------------------------------------------------------
add(_t("cluster-lifecycle", "kubeadm: join & upgrade", [4],
       "kubeadm builds and maintains the control plane. The exam tests the ORDER "
       "and the version-skew rules, and both are enforced here.",
       bullets=[
           "Upgrade the control plane FIRST, then the kubelets, one node at a time",
           "One minor version per hop -- 1.30 -> 1.31 -> 1.32, never 1.30 -> 1.32",
           "kubelet may trail the API server by up to 3 minor versions, never lead",
           "Per node: kubectl drain -> kubeadm upgrade node -> kubectl uncordon",
           "kubeadm token create --print-join-command gives you the join line",
           "kubeadm init/reset need real machines -- do those on kind or minikube",
       ],
       commands=["kubeadm version",
                 "kubeadm upgrade plan",
                 "kubeadm upgrade apply v1.31.1",
                 "kubectl drain lab-worker-1 --ignore-daemonsets",
                 "kubeadm upgrade node --node lab-worker-1",
                 "kubectl uncordon lab-worker-1",
                 "kubeadm token create --print-join-command",
                 "kubeadm join 172.18.0.2:6443 --token abc --node-name lab-worker-4",
                 "kubectl get nodes"],
       gotchas=["Upgrading a node before the control plane is refused -- the kubelet "
                "must never be newer than the API server.",
                "`kubeadm upgrade node` on a node you have not drained is refused, "
                "exactly like a careful runbook would."],
       interview=["What order do you upgrade a cluster in, and why?",
                  "How far behind the API server may a kubelet be?",
                  "How does a new node get a client certificate when it joins?"],
       lab="25-kubeadm-upgrade.kubectl"))

add(_t("etcd-backup", "etcd backup & restore", [39],
       "etcd holds every object in the cluster. A snapshot is your only real "
       "disaster recovery, and restoring one is a classic exam task.",
       bullets=[
           "Every etcdctl call needs --endpoints --cacert --cert --key",
           "ETCDCTL_API=3 -- v2 commands will not work",
           "snapshot save takes it, snapshot status inspects it (hash, revision, keys)",
           "snapshot restore writes a NEW data dir; then point etcd at it and restart",
           "A restore rewinds the whole cluster to the moment of the snapshot",
       ],
       commands=[
           "ETCDCTL_API=3 etcdctl member list --endpoints=https://127.0.0.1:2379 "
           "--cacert=/etc/kubernetes/pki/etcd/ca.crt "
           "--cert=/etc/kubernetes/pki/etcd/server.crt "
           "--key=/etc/kubernetes/pki/etcd/server.key",
           "ETCDCTL_API=3 etcdctl snapshot save /backup/etcd.db "
           "--endpoints=https://127.0.0.1:2379 "
           "--cacert=/etc/kubernetes/pki/etcd/ca.crt "
           "--cert=/etc/kubernetes/pki/etcd/server.crt "
           "--key=/etc/kubernetes/pki/etcd/server.key",
           "ETCDCTL_API=3 etcdctl snapshot status /backup/etcd.db "
           "--endpoints=https://127.0.0.1:2379 "
           "--cacert=/etc/kubernetes/pki/etcd/ca.crt "
           "--cert=/etc/kubernetes/pki/etcd/server.crt "
           "--key=/etc/kubernetes/pki/etcd/server.key",
           "ETCDCTL_API=3 etcdctl snapshot restore /backup/etcd.db "
           "--data-dir=/var/lib/etcd-restored "
           "--cacert=/etc/kubernetes/pki/etcd/ca.crt "
           "--cert=/etc/kubernetes/pki/etcd/server.crt "
           "--key=/etc/kubernetes/pki/etcd/server.key"],
       gotchas=["Forget one of the four TLS flags and you get a connection error that "
                "looks like etcd is down. It is not: your client is unauthenticated.",
                "A restore is a point-in-time rewind. Anything created after the "
                "snapshot is gone -- that is the whole idea."],
       interview=["Where does Kubernetes store its state, and how do you back it up?",
                  "What does snapshot status tell you?",
                  "After restoring, what else has to happen for the cluster to use it?"],
       lab="26-etcd-backup.kubectl"))

add(_t("certificates", "Certificates & CSRs", [36],
       "Kubernetes has no user objects: a user is a client certificate the API "
       "server trusts. You create one through the CSR API.",
       bullets=[
           "Create a CertificateSigningRequest, approve it, extract the certificate",
           "CN becomes the username, O becomes the groups -- that is what RBAC binds",
           "kubeadm certs check-expiration shows every control-plane certificate",
           "Control-plane certs last 1 year; `kubeadm upgrade` renews them for you",
           "kubeadm certs renew all does it manually (then restart the components)",
       ],
       commands=["kubectl create csr alice --user=alice --group=developers",
                 "kubectl get csr",
                 "kubectl certificate approve alice",
                 "kubectl certificate deny alice",
                 "kubeadm certs check-expiration",
                 "kubeadm certs renew all",
                 "sim age-certs 340"],
       gotchas=["Approving a CSR only issues a certificate -- it grants nothing. The "
                "user still needs a Role and a RoleBinding.",
                "Expired control-plane certificates lock you out of your own cluster; "
                "check them before they hit 30 days."],
       interview=["How do you add a new human user to a cluster?",
                  "Where do a user's groups come from?",
                  "What renews the control-plane certificates?"],
       lab="27-certs-kubeconfig.kubectl"))

add(_t("kubeconfig", "kubeconfig & contexts", [36],
       "A kubeconfig is three lists -- clusters, users, contexts -- plus a pointer "
       "to the current context. Every kubectl call reads it.",
       bullets=[
           "cluster = where (server URL + CA), user = who (cert or token)",
           "context = cluster + user + default namespace, given a name",
           "current-context is what kubectl uses when you do not say otherwise",
           "Switching context switches identity AND namespace in one move",
       ],
       commands=["kubectl config view",
                 "kubectl config get-contexts",
                 "kubectl config current-context",
                 "kubectl config set-cluster lab-cluster "
                 "--server=https://127.0.0.1:6443",
                 "kubectl config set-credentials alice --client-certificate=alice.crt "
                 "--client-key=alice.key",
                 "kubectl config set-context alice-ctx --cluster=lab-cluster "
                 "--user=alice --namespace=dev",
                 "kubectl config use-context alice-ctx",
                 "kubectl config set-context --current --namespace=default"],
       gotchas=["`kubectl config use-context` on the wrong context is how people run "
                "commands against production by accident -- check "
                "`current-context` first."],
       interview=["What are the three sections of a kubeconfig?",
                  "How do you stop typing -n every time?",
                  "How would you give a colleague read-only access to one namespace?"],
       lab="27-certs-kubeconfig.kubectl"))

add(_t("images", "Images, registries & pull secrets", [5],
       "A Kubernetes node pulls images from a registry over the network. Building "
       "one locally is not enough, and private registries need credentials.",
       bullets=[
           "Build and tag, then PUSH -- a node cannot pull from your laptop",
           "Private repository -> the pod needs spec.imagePullSecrets",
           "kubectl create secret docker-registry makes that secret",
           "imagePullPolicy: Always for :latest, IfNotPresent for pinned tags",
           "Pin a tag (or a digest); :latest makes rollbacks meaningless",
       ],
       commands=["docker build -t myapp:1.0 .",
                 "docker images",
                 "docker tag myapp:1.0 registry.lab/private/myapp:1.0",
                 "docker push registry.lab/private/myapp:1.0",
                 "kubectl create secret docker-registry regcred "
                 "--docker-server=registry.lab --docker-username=dev "
                 "--docker-password=s3cr3t",
                 "kubectl describe pod app"],
       gotchas=["A private image without an imagePullSecret gives you "
                "ImagePullBackOff with 'pull access denied' -- read the describe "
                "output, not just the status column.",
                "This lab models the registry, not a real build. Real Dockerfile "
                "work needs a real Docker daemon."],
       interview=["Why does a pod fail to pull an image you just built locally?",
                  "How do you give a pod credentials for a private registry?",
                  "When would you set imagePullPolicy: Always?"],
       lab="29-images-registry.kubectl"))


# --------------------------------------------------------------------------
ORDER = ["introduction", "architecture", "pods", "deployments", "replicasets",
         "services", "configmaps", "namespaces", "pv", "pvc", "storage-classes",
         "dynamic-provisioning", "statefulsets", "daemonsets", "jobs", "cronjobs",
         "init-containers", "multi-container", "labels", "annotations", "taints",
         "node-affinity", "pod-affinity", "resources", "probes", "hpa", "vpa",
         "cluster-autoscaler", "ingress", "ingress-controller", "network-policies",
         "rbac", "service-accounts", "authentication", "authorization", "admission",
         "helm", "kustomize", "operators", "crds", "observability", "logging",
         "troubleshooting", "best-practices", "interview",
         # cluster administration (added at the end)
         "cluster-lifecycle", "etcd-backup", "certificates", "kubeconfig", "images"]

SECTIONS = [
    ("Fundamentals", ["introduction", "architecture"]),
    ("Workloads", ["pods", "deployments", "replicasets", "statefulsets", "daemonsets",
                   "jobs", "cronjobs", "init-containers", "multi-container"]),
    ("Networking", ["services", "ingress", "ingress-controller", "network-policies"]),
    ("Configuration", ["configmaps", "namespaces", "labels", "annotations"]),
    ("Storage", ["pv", "pvc", "storage-classes", "dynamic-provisioning"]),
    ("Scheduling", ["taints", "node-affinity", "pod-affinity", "resources", "probes"]),
    ("Autoscaling", ["hpa", "vpa", "cluster-autoscaler"]),
    ("Security", ["rbac", "service-accounts", "authentication", "authorization",
                  "admission"]),
    ("Packaging", ["helm", "kustomize", "operators", "crds"]),
    ("Operations", ["observability", "logging", "troubleshooting", "best-practices",
                    "interview"]),
    ("Cluster administration", ["cluster-lifecycle", "etcd-backup", "certificates",
                                "kubeconfig", "images"]),
]


def get(key: str) -> Optional[Topic]:
    return TOPICS.get(key)


def search(text: str) -> List[Topic]:
    text = (text or "").lower().strip()
    if not text:
        return [TOPICS[k] for k in ORDER]
    hits = []
    for key in ORDER:
        topic = TOPICS[key]
        haystack = " ".join([topic.key, topic.title, topic.summary,
                             " ".join(topic.bullets), " ".join(topic.commands)]).lower()
        if text in haystack:
            hits.append(topic)
    return hits


def total_pages() -> int:
    try:
        return len([f for f in os.listdir(PAGES_DIR) if f.endswith(".png")])
    except OSError:
        return 0


# --------------------------------------------------------------------------
# command explanations -- every command shown in the UI carries a plain-English
# note saying exactly what it does.
# --------------------------------------------------------------------------
CURATED: Dict[str, str] = {
    "kubectl cluster-info": "Prints the control-plane and DNS endpoints -- the first "
                            "thing you run to confirm you are talking to a cluster.",
    "kubectl version": "Shows the client and server versions; a big skew between them "
                       "is a common source of odd behaviour.",
    "kubectl api-resources": "Lists every resource kind the API server knows, with its "
                             "short name, api group and whether it is namespaced.",
    "kubectl get all --all-namespaces": "Lists the common workload kinds in every "
                                        "namespace at once (not literally 'all' kinds).",
    "kubectl get nodes -o wide": "Lists nodes plus internal IP, OS image and container "
                                 "runtime -- the extra columns -o wide adds.",
    "kubectl get nodes --show-labels": "Lists nodes with every label, which is what "
                                       "nodeSelector and node affinity match against.",
    "kubectl top nodes": "Per-node CPU and memory actually in use, served by "
                         "metrics-server (the same source the HPA reads).",
    "kubectl top pods": "Per-pod CPU and memory actually in use -- compare against the "
                        "requests you set to see if you sized the pod correctly.",
    "kubectl get events": "The cluster's recent event log: scheduling decisions, image "
                          "pulls, probe failures. Your first stop when something is "
                          "stuck.",
    "kubectl get events --sort-by=.lastTimestamp": "Events in time order, newest last "
                                                   "-- read the tail during an incident.",
    "kubectl get endpoints": "Shows the pod IPs behind each Service. Empty means the "
                             "selector matches nothing or no pod is Ready.",
    "kubectl get pods --show-labels": "Lists pods with their labels, so you can see "
                                      "exactly what a Service selector has to match.",
    "kubectl get pv,pvc": "Shows volumes and claims side by side so you can see which "
                          "claim bound to which volume, and what is still Pending.",
    "kubectl get sc": "Lists StorageClasses; the one marked (default) is used when a "
                      "PVC does not name a class.",
    "kubectl get crd": "Lists Custom Resource Definitions -- the extra kinds installed "
                       "on top of the built-in API.",
    "kubectl get pdb": "Lists PodDisruptionBudgets: the minimum availability the "
                       "cluster must respect during drains and upgrades.",
    "kubectl auth can-i '*' '*' --list": "Dumps every permission your current identity "
                                         "has -- the quickest RBAC audit there is.",
    "kubectl config view": "Prints your kubeconfig: clusters, users and contexts, and "
                           "which one is current.",
    "kubectl config current-context": "Prints the context you are pointed at right now "
                                      "-- check this before running anything dangerous.",
    "kubectl explain pods": "The API reference for a kind, straight from the server. In "
                            "the CKA/CKAD exam this replaces the docs site.",
    "kubectl explain pods.spec.containers": "Drills into one field path of the schema; "
                                            "the fastest way to recall a field name.",
    "kubectl explain architecture": "Opens the handbook notes for this topic instead of "
                                    "an API schema (a lab convenience).",
}

_VERB_TEXT = {
    "get": "Lists {what}{ns}. Add -o wide for more columns or -o yaml for the "
           "full object.",
    "describe": "Shows {what} in detail plus its recent events -- the events at the "
                "bottom are usually the answer.",
    "create": "Creates {what} imperatively, without writing a manifest first.",
    "apply": "Sends {what} to the API server and reconciles the cluster towards it; "
             "safe to re-run, it only changes what differs.",
    "delete": "Deletes {what}. Anything it owns is garbage-collected with it.",
    "run": "Starts a single bare pod {what} -- handy for a throwaway debug container.",
    "expose": "Creates a Service in front of {what}, copying its labels into the "
              "selector so the Service finds its pods.",
    "scale": "Changes the replica count of {what}; the ReplicaSet controller adds or "
             "removes pods to match.",
    "autoscale": "Creates a HorizontalPodAutoscaler for {what} so the replica count "
                 "follows CPU utilisation.",
    "label": "Adds, changes or (with a trailing -) removes labels on {what}. Labels "
             "are what selectors match.",
    "annotate": "Attaches non-identifying metadata to {what}. Annotations cannot be "
                "used as selectors.",
    "taint": "Marks a node so pods are repelled from it unless they carry a matching "
             "toleration.",
    "cordon": "Marks a node unschedulable; running pods stay put, new ones go elsewhere.",
    "uncordon": "Makes a cordoned node schedulable again.",
    "drain": "Cordons a node and evicts its pods so you can safely take it down.",
    "logs": "Prints the container's stdout/stderr. Add --previous to read the logs of "
            "the last crashed container.",
    "exec": "Runs a command inside a running container -- the fastest way to check what "
            "the app actually sees.",
    "patch": "Merges a partial object into {what} without rewriting the whole manifest.",
    "wait": "Blocks until a condition is met, so scripts do not race the controllers.",
    "port-forward": "Tunnels a local port to a pod or service without exposing it.",
    "diff": "Shows what `apply` would change before you change it.",
}

_KIND_WORDS = {
    "po": "pods", "pod": "pods", "pods": "pods",
    "deploy": "deployments", "deployment": "deployments", "deployments": "deployments",
    "rs": "ReplicaSets", "replicaset": "ReplicaSets", "replicasets": "ReplicaSets",
    "svc": "Services", "service": "Services", "services": "Services",
    "sts": "StatefulSets", "ds": "DaemonSets", "cj": "CronJobs", "jobs": "Jobs",
    "cm": "ConfigMaps", "configmap": "ConfigMaps", "configmaps": "ConfigMaps",
    "secret": "Secrets", "secrets": "Secrets", "ns": "namespaces",
    "namespace": "namespaces", "namespaces": "namespaces",
    "pv": "PersistentVolumes", "pvc": "PersistentVolumeClaims",
    "sc": "StorageClasses", "hpa": "HorizontalPodAutoscalers",
    "vpa": "VerticalPodAutoscalers", "ing": "Ingresses", "ingress": "Ingresses",
    "netpol": "NetworkPolicies", "sa": "ServiceAccounts", "no": "nodes",
    "node": "nodes", "nodes": "nodes", "quota": "ResourceQuotas",
    "events": "events", "all": "the common workload kinds",
}

_SIM_TEXT = {
    "tick": "Advances the simulated control loop by n iterations, so you can watch "
            "controllers converge without waiting in real time.",
    "load": "Sets a synthetic CPU utilisation for a workload. This is what the HPA "
            "reads, so it is how you make autoscaling happen on demand.",
    "chaos": "Injects a failure into a pod or app: crash (CrashLoopBackOff), oom "
             "(OOMKilled), imagepull (ImagePullBackOff), notready (failing readiness "
             "probe), or clear to fix it.",
    "node": "Changes the node pool: down marks a node NotReady, up restores it, add "
            "joins a new node, remove deletes one.",
    "rbac": "Turns RBAC enforcement on or off. With it on, non-admin users are denied "
            "until you bind them a Role.",
    "user": "Switches the identity every later command runs as -- pair it with "
            "`sim rbac on` to feel deny-by-default.",
    "reset": "Throws away every object and rebuilds a clean 4-node cluster.",
    "save": "Writes the whole cluster state to a JSON file.",
    "load-state": "Restores a cluster state previously written with `sim save`.",
}


def describe_command(command: str) -> str:
    """One plain-English sentence describing exactly what a command does."""
    command = " ".join(str(command).split())
    if command in CURATED:
        return CURATED[command]

    tokens = command.split()
    while tokens and re.match(r"^[A-Z_][A-Z0-9_]*=", tokens[0]):
        tokens = tokens[1:]                    # ETCDCTL_API=3 etcdctl ...
    if not tokens:
        return ""
    program = tokens[0]

    if program == "sim":
        action = tokens[1] if len(tokens) > 1 else ""
        return _SIM_TEXT.get(action, "Lab-only control (not a real kubectl command).")

    if program == "kubeadm":
        action = " ".join(tokens[1:3])
        return {
            "version": "Prints the kubeadm/control-plane version you are working with.",
            "upgrade plan": "Shows the current and target version of every control-"
                            "plane component and kubelet, and the exact command to "
                            "run next.",
            "upgrade apply": "Upgrades the control plane (apiserver, scheduler, "
                             "controller-manager, etcd) and renews its certificates. "
                             "Always the FIRST step.",
            "upgrade node": "Upgrades the kubelet configuration on one node. Drain "
                            "the node first; the control plane must already be new.",
            "token create": "Mints a bootstrap token; --print-join-command gives you "
                            "the whole join line to paste on the new node.",
            "token list": "Lists the bootstrap tokens and how long they are valid.",
            "join": "Registers a new node with the control plane and starts its "
                    "kubelet with a TLS-bootstrapped client certificate.",
            "certs check-expiration": "Shows how many days are left on every "
                                      "control-plane certificate.",
            "certs renew": "Re-issues control-plane certificates (restart the "
                           "components afterwards).",
        }.get(action, "kubeadm manages the cluster's own lifecycle.")

    if program == "etcdctl":
        action = " ".join(tokens[1:3])
        return {
            "snapshot save": "Takes a point-in-time backup of the entire cluster "
                             "state. Needs ETCDCTL_API=3 and the four TLS flags.",
            "snapshot status": "Reads a snapshot file and reports its hash, revision "
                               "and key count -- verify every backup you take.",
            "snapshot restore": "Writes a snapshot into a NEW data directory; point "
                                "etcd at it and restart to rewind the cluster.",
            "member list": "Lists the etcd cluster members and their endpoints.",
            "endpoint status": "Health and size of each etcd endpoint.",
        }.get(action, "etcdctl talks directly to etcd, where all cluster state lives.")

    if program == "docker":
        action = tokens[1] if len(tokens) > 1 else ""
        return {
            "build": "Builds an image and tags it -- it exists on this machine only, "
                     "so a cluster node still cannot pull it.",
            "tag": "Gives an image a second name, usually one that includes the "
                   "registry host you are about to push to.",
            "push": "Uploads the image to a registry so nodes can pull it. Private "
                    "repositories then need an imagePullSecret.",
            "images": "Lists the images this lab knows about and whether they were "
                      "pushed or are private.",
            "rmi": "Removes an image tag.",
        }.get(action, "Container image tooling (the registry half is modelled here).")

    if program == "helm":
        action = tokens[1] if len(tokens) > 1 else ""
        return {
            "install": "Renders a chart's templates with its values and creates every "
                       "resulting object as one named release.",
            "upgrade": "Re-renders the chart with new values and applies the diff as a "
                       "new revision of the release.",
            "uninstall": "Deletes every object that belongs to the release.",
            "list": "Lists the releases installed in this namespace and their revision.",
            "template": "Renders the chart to YAML and prints it without touching the "
                        "cluster -- the way to debug a chart.",
            "repo": "Registers a chart repository.",
        }.get(action, "Helm, the Kubernetes package manager.")

    if program == "kustomize":
        return ("Renders a kustomization (base + overlay patches) to plain YAML and "
                "prints it; nothing is applied.")

    if program != "kubectl":
        return ""

    verb = tokens[1] if len(tokens) > 1 else ""
    rest = tokens[2:]
    namespace = ""
    for index, token in enumerate(rest):
        if token in ("-n", "--namespace") and index + 1 < len(rest):
            namespace = f" in namespace {rest[index + 1]}"
        elif token.startswith("--namespace="):
            namespace = f" in namespace {token.split('=', 1)[1]}"
        elif token in ("-A", "--all-namespaces"):
            namespace = " across every namespace"

    positional = []
    skip = False
    for index, token in enumerate(rest):
        if skip:
            skip = False
            continue
        if token.startswith("-"):
            skip = token in ("-n", "--namespace", "-o", "--output", "-l", "--selector",
                             "-f", "--filename", "-c", "--containers")
            continue
        positional.append(token)
    target = positional[0] if positional else ""
    kind, slash, name = target.partition("/")
    if not slash and len(positional) > 1 and "=" not in positional[1]:
        name = positional[1]
    words = _KIND_WORDS.get(kind.lower(), kind or "the resource")
    what = f"{words} named {name}" if name else words

    if verb == "rollout":
        action = rest[0] if rest else ""
        return {
            "status": "Waits for the rollout to finish and reports how many updated "
                      "replicas are available.",
            "history": "Lists the deployment's revisions -- each one is a ReplicaSet "
                       "kept for rollback.",
            "undo": "Rolls back to the previous revision (or --to-revision=N) by "
                    "restoring that ReplicaSet's pod template.",
            "restart": "Triggers a rolling restart by stamping an annotation on the pod "
                       "template; no image change needed.",
        }.get(action, "Manages a rollout.")
    if verb == "set":
        return ("Changes the container image in the pod template, which starts a "
                "rolling update and creates a new ReplicaSet revision.")
    if verb == "auth":
        return ("Asks the API server whether your current identity is allowed to do "
                "this -- the definitive RBAC check.")
    if verb == "config":
        return ("Edits your kubeconfig. `set-context --current --namespace=x` changes "
                "the default namespace so you can stop typing -n.")
    if verb == "top":
        return ("Live CPU and memory usage from metrics-server -- what is actually "
                "consumed, not what was requested.")
    if verb == "explain":
        return "Prints the API schema for a kind straight from the server."
    if verb == "apply" and ("-k" in rest or "--kustomize" in rest):
        return ("Builds the kustomization in that directory and applies the result -- "
                "base plus overlay in one step.")
    if verb == "apply":
        path = next((t for i, t in enumerate(rest)
                     if i and rest[i - 1] in ("-f", "--filename")), "")
        return (f"Applies the manifest {path}{namespace}: creates the objects it "
                "declares, or updates them in place if they already exist."
                if path else _VERB_TEXT["apply"].format(what=what, ns=namespace))
    if verb == "create" and target in ("configmap", "cm"):
        return ("Creates a ConfigMap from literal key/value pairs -- the imperative "
                "shortcut for a small config object.")
    if verb == "create" and target == "secret":
        return ("Creates a Secret. Values are base64-encoded (not encrypted), so treat "
                "read access to Secrets as access to the data.")

    template = _VERB_TEXT.get(verb)
    if template:
        return template.format(what=what, ns=namespace)
    return f"Runs `kubectl {verb}`."


def annotated_commands(topic: "Topic") -> List[dict]:
    return [{"cmd": command, "why": describe_command(command)}
            for command in topic.commands]


# --------------------------------------------------------------------------
# certification coverage -- which exam domain each topic belongs to
# --------------------------------------------------------------------------
CKA_DOMAINS = {
    "arch": ("Cluster Architecture, Installation & Configuration", 25),
    "workloads": ("Workloads & Scheduling", 15),
    "network": ("Services & Networking", 20),
    "storage": ("Storage", 10),
    "trouble": ("Troubleshooting", 30),
}

CKAD_DOMAINS = {
    "design": ("Application Design and Build", 20),
    "deploy": ("Application Deployment", 20),
    "observe": ("Application Observability and Maintenance", 15),
    "config": ("Application Environment, Configuration and Security", 25),
    "network": ("Services and Networking", 20),
}

# topic -> (CKA domain key or None, CKAD domain key or None)
CERT_MAP: Dict[str, tuple] = {
    "introduction": ("arch", "design"),
    "architecture": ("arch", None),
    "pods": ("workloads", "design"),
    "deployments": ("workloads", "deploy"),
    "replicasets": ("workloads", "deploy"),
    "services": ("network", "network"),
    "configmaps": ("workloads", "config"),
    "namespaces": ("arch", "config"),
    "pv": ("storage", "design"),
    "pvc": ("storage", "design"),
    "storage-classes": ("storage", None),
    "dynamic-provisioning": ("storage", None),
    "statefulsets": ("workloads", "design"),
    "daemonsets": ("workloads", "design"),
    "jobs": ("workloads", "design"),
    "cronjobs": ("workloads", "design"),
    "init-containers": ("workloads", "design"),
    "multi-container": ("workloads", "design"),
    "labels": ("workloads", "deploy"),
    "annotations": (None, "deploy"),
    "taints": ("workloads", None),
    "node-affinity": ("workloads", None),
    "pod-affinity": ("workloads", None),
    "resources": ("workloads", "config"),
    "probes": ("workloads", "observe"),
    "hpa": ("workloads", "deploy"),
    "vpa": (None, None),
    "cluster-autoscaler": ("arch", None),
    "ingress": ("network", "network"),
    "ingress-controller": ("network", "network"),
    "network-policies": ("network", "network"),
    "rbac": ("arch", "config"),
    "service-accounts": ("arch", "config"),
    "authentication": ("arch", None),
    "authorization": ("arch", "config"),
    "admission": ("arch", None),
    "helm": ("arch", "deploy"),
    "kustomize": ("arch", "deploy"),
    "operators": (None, None),
    "crds": ("arch", None),
    "observability": ("trouble", "observe"),
    "logging": ("trouble", "observe"),
    "troubleshooting": ("trouble", "observe"),
    "best-practices": ("trouble", "config"),
    "interview": ("trouble", "deploy"),
    "cluster-lifecycle": ("arch", None),
    "etcd-backup": ("arch", None),
    "certificates": ("arch", "config"),
    "kubeconfig": ("arch", "config"),
    "images": ("workloads", "design"),
}


def certs_for(key: str) -> List[dict]:
    """Which exam domains a topic counts towards."""
    cka, ckad = CERT_MAP.get(key, (None, None))
    out = []
    if cka:
        name, weight = CKA_DOMAINS[cka]
        out.append({"exam": "CKA", "domain": name, "weight": weight})
    if ckad:
        name, weight = CKAD_DOMAINS[ckad]
        out.append({"exam": "CKAD", "domain": name, "weight": weight})
    return out


def coverage() -> dict:
    """Topic counts per exam domain -- what this lab does and does not cover."""
    report = {"CKA": {}, "CKAD": {}}
    for domain, (name, weight) in CKA_DOMAINS.items():
        report["CKA"][name] = {"weight": weight, "topics": []}
    for domain, (name, weight) in CKAD_DOMAINS.items():
        report["CKAD"][name] = {"weight": weight, "topics": []}
    for key in ORDER:
        cka, ckad = CERT_MAP.get(key, (None, None))
        if cka:
            report["CKA"][CKA_DOMAINS[cka][0]]["topics"].append(TOPICS[key].title)
        if ckad:
            report["CKAD"][CKAD_DOMAINS[ckad][0]]["topics"].append(TOPICS[key].title)
    return report


NOT_COVERED = [
    "`kubeadm init` and `kubeadm reset` -- building a control plane from bare "
    "machines. The upgrade and join workflow IS practised here (lab 25), but "
    "bootstrapping needs real hosts: use kind or minikube.",
    "Real TLS material. The CSR -> approve -> kubeconfig workflow is practised "
    "(lab 27), but no actual keys are generated, so `openssl` practice belongs on "
    "a real cluster.",
    "Real container builds. The registry, push, private repositories and "
    "imagePullSecrets are modelled (lab 29); writing an efficient Dockerfile is a "
    "Docker skill and needs a real daemon.",
    "A real CNI dataplane. NetworkPolicies ARE evaluated here and connections are "
    "genuinely allowed or denied (lab 28), but no packets move -- so CNI-specific "
    "behaviour (Calico vs Cilium) is out of scope.",
    "Node-level debugging: systemd, kubelet logs on disk, container runtime "
    "inspection with crictl.",
]


# --------------------------------------------------------------------------
# per-topic starter manifests
# --------------------------------------------------------------------------
def manifest_filename(topic: "Topic") -> str:
    lab = f"lab{topic.lab_number:02d}_" if topic.lab_number else ""
    section = topic.section.lower().replace(" ", "-") or "kubernetes"
    return f"{section}_{topic.key}_{lab}p{topic.pages[0]}.yaml"


def manifest_for(topic: "Topic") -> str:
    """A downloadable, applyable manifest with a labelled header.

    Topics that do not create objects still get a valid YAML file: a commented
    block with the commands to run, so `Download all` gives one file per topic.
    """
    lab_line = (f"# Lab:      {topic.lab_number:02d} - {topic.lab}"
                if topic.lab_number else "# Lab:      (none)")
    header = "\n".join([
        "# ---------------------------------------------------------------",
        f"# Topic:    {topic.title}",
        f"# Section:  {topic.section}",
        lab_line,
        f"# Handbook: page {', '.join(str(p) for p in topic.pages)}",
        f"# Key:      {topic.key}",
        "# ---------------------------------------------------------------",
        "#",
        "# " + topic.summary.replace("\n", "\n# "),
        "# ---------------------------------------------------------------",
        "",
    ])
    if topic.yaml.strip():
        return header + topic.yaml.rstrip() + "\n"
    body = ["# This topic is practised with commands rather than a manifest.",
            "# Run these in the terminal (or use the Script tab):", "#"]
    body += [f"#   {command}" for command in topic.commands]
    body += ["#",
             "# Everything below this line is intentionally empty: applying this "
             "file is a no-op.", ""]
    return header + "\n".join(body)
