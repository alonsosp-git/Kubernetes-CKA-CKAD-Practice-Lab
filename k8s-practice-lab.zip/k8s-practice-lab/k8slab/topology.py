"""Turns cluster state into a positioned graph that both front ends can draw.

Two views:

  logical  -- Ingress -> Service -> Workload -> ReplicaSet -> Pod, with a side
              rail for ConfigMaps/Secrets/PVCs/PVs and the objects they feed.
  physical -- Node boxes with their pods packed inside, the way the cluster is
              actually laid out on machines.

The layout is a layered (Sugiyama-lite) algorithm: assign each object to a tier
by kind, then order each tier by the average position of its parents so the
edges cross as little as possible.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .model import Cluster, annotation, deep_get, fmt_cpu, fmt_mem, match_labels

# ---------------------------------------------------------------------------
# palette (shared by the Tk canvas and the web UI so both look the same)
# ---------------------------------------------------------------------------
# Each handbook section owns a hue family; every object kind gets a distinct tone
# inside its family, so you can tell at a glance which part of Kubernetes a card
# belongs to. Nothing yellow: on a dark canvas it reads badly next to the amber
# "warning" status dot.
SECTION_COLORS: Dict[str, str] = {
    # Eleven sections, hues spread right around the wheel (skipping the yellow
    # band, which reads badly on this canvas), and where two hues sit close the
    # lightness pulls them apart. Read the comments as: name  hue/sat/light.
    "Security":               "#ef4444",   # red        0  / 84 / 60
    "Packaging":              "#fb923c",   # orange     27 / 96 / 61
    "Operations":             "#8bd450",   # leaf       95 / 60 / 57
    "Storage":                "#22c55e",   # green     142 / 71 / 45
    "Cluster administration": "#0d9488",   # deep teal 175 / 84 / 32
    "Networking":             "#22d3ee",   # cyan      188 / 86 / 53
    "Fundamentals":           "#7dd3fc",   # sky       199 / 95 / 74
    "Workloads":              "#4f7ef9",   # blue      222 / 94 / 64
    "Scheduling":             "#7c6cf7",   # indigo    247 / 90 / 70
    "Configuration":          "#b45cf0",   # purple    280 / 83 / 65
    "Autoscaling":            "#e935b8",   # magenta   313 / 82 / 56
}

# kind -> (section, exact tone within that section's family)
KIND_STYLE: Dict[str, Tuple[str, str]] = {
    # --- Workloads: blues -------------------------------------------------
    "Deployment":               ("Workloads", "#4f7ef9"),
    "ReplicaSet":               ("Workloads", "#1d4ed8"),
    "Pod":                      ("Workloads", "#93b4fd"),
    "StatefulSet":              ("Workloads", "#1e3a8a"),
    "DaemonSet":                ("Workloads", "#2563eb"),
    "Job":                      ("Workloads", "#bfd4fe"),
    "CronJob":                  ("Workloads", "#60a5fa"),
    # --- Networking: cyans ------------------------------------------------
    "Service":                  ("Networking", "#22d3ee"),
    "Ingress":                  ("Networking", "#0e7490"),
    "IngressClass":             ("Networking", "#a5f3fc"),
    "NetworkPolicy":            ("Networking", "#0891b2"),
    # --- Configuration: purples ------------------------------------------
    "ConfigMap":                ("Configuration", "#b45cf0"),
    "Secret":                   ("Configuration", "#7e22ce"),
    "Namespace":                ("Configuration", "#9333ea"),
    "ResourceQuota":            ("Configuration", "#e9d5ff"),
    "LimitRange":               ("Configuration", "#581c87"),
    # --- Storage: greens --------------------------------------------------
    "PersistentVolumeClaim":    ("Storage", "#22c55e"),
    "PersistentVolume":         ("Storage", "#15803d"),
    "StorageClass":             ("Storage", "#86efac"),
    # --- Autoscaling: magenta --------------------------------------------
    "HorizontalPodAutoscaler":  ("Autoscaling", "#e935b8"),
    "VerticalPodAutoscaler":    ("Autoscaling", "#9d174d"),
    "PodDisruptionBudget":      ("Autoscaling", "#f9a8d4"),
    # --- Security: reds ---------------------------------------------------
    "ServiceAccount":           ("Security", "#ef4444"),
    "Role":                     ("Security", "#b91c1c"),
    "RoleBinding":              ("Security", "#fca5a5"),
    "ClusterRole":              ("Security", "#7f1d1d"),
    "ClusterRoleBinding":       ("Security", "#fecaca"),
    "CertificateSigningRequest": ("Security", "#f87171"),
    # --- Packaging: orange ------------------------------------------------
    "CustomResourceDefinition": ("Packaging", "#fb923c"),
    # --- Cluster administration: deep teal --------------------------------
    "Node":                     ("Cluster administration", "#0d9488"),
    "Event":                    ("Operations", "#8bd450"),
}

PALETTE: Dict[str, str] = {kind: tone for kind, (_, tone) in KIND_STYLE.items()}


def section_of(kind: str) -> str:
    return KIND_STYLE.get(kind, ("Operations", "#94a3b8"))[0]


def colour_of(kind: str) -> str:
    return KIND_STYLE.get(kind, ("Operations", "#94a3b8"))[1]


# status is deliberately a separate axis from the section colours: the small dot
# in the corner of every card, nothing else.
STATUS_COLORS = {
    "ok": "#22c55e",
    "warn": "#f59e0b",
    "error": "#ef4444",
    "pending": "#94a3b8",
}

TIERS = ["Ingress", "Service", "Workload", "ReplicaSet", "Pod"]
TIER_OF = {
    "Ingress": 0,
    "Service": 1,
    "Deployment": 2, "StatefulSet": 2, "DaemonSet": 2, "Job": 2, "CronJob": 2,
    "ReplicaSet": 3,
    "Pod": 4,
}

NODE_W, NODE_H = 146, 48
X_GAP, Y_GAP = 20, 84
MARGIN_X, MARGIN_Y = 26, 26


@dataclass
class GNode:
    id: str
    kind: str
    name: str
    namespace: str
    label: str
    sublabel: str
    status: str = "ok"
    detail: str = ""
    tier: int = 0
    x: float = 0.0
    y: float = 0.0
    w: float = NODE_W
    h: float = NODE_H
    color: str = "#38bdf8"
    badge: str = ""
    topic: str = ""
    fresh: bool = False
    band: str = ""            # namespace lane this card is drawn inside

    def as_dict(self) -> dict:
        return dict(id=self.id, kind=self.kind, name=self.name, ns=self.namespace,
                    band=self.band or self.namespace,
                    label=self.label, sublabel=self.sublabel, status=self.status,
                    detail=self.detail, x=round(self.x, 1), y=round(self.y, 1),
                    w=self.w, h=self.h, color=self.color, badge=self.badge,
                    topic=self.topic, fresh=self.fresh, tier=self.tier)


@dataclass
class GEdge:
    src: str
    dst: str
    kind: str = "owns"        # owns | selects | routes | mounts | scales | binds
    label: str = ""
    colour: str = ""          # section colour of the object the edge points at

    def as_dict(self) -> dict:
        return dict(src=self.src, dst=self.dst, kind=self.kind, label=self.label,
                    colour=self.colour)


@dataclass
class Graph:
    nodes: List[GNode] = field(default_factory=list)
    edges: List[GEdge] = field(default_factory=list)
    groups: List[dict] = field(default_factory=list)
    width: float = 900
    height: float = 600
    view: str = "logical"
    stats: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return dict(nodes=[n.as_dict() for n in self.nodes],
                    edges=[e.as_dict() for e in self.edges],
                    groups=self.groups, width=self.width, height=self.height,
                    view=self.view, stats=self.stats)

    def by_id(self, node_id: str) -> Optional[GNode]:
        for node in self.nodes:
            if node.id == node_id:
                return node
        return None


# ---------------------------------------------------------------------------
def _pod_status_class(pod: dict) -> Tuple[str, str]:
    phase = deep_get(pod, "status.phase", "Pending")
    reason = deep_get(pod, "status.reason", "")
    if reason in ("CrashLoopBackOff", "ImagePullBackOff", "OOMKilled",
                  "CreateContainerConfigError", "NodeLost"):
        return "error", reason
    if reason == "Unschedulable":
        return "error", "Unschedulable"
    if phase == "Succeeded":
        return "ok", "Completed"
    if phase == "Failed":
        return "error", "Failed"
    if phase == "Running" and deep_get(pod, "status.ready"):
        return "ok", "Running"
    if phase == "Running":
        return "warn", reason or "NotReady"
    return "pending", reason or "Pending"


def _workload_status(obj: dict) -> Tuple[str, str]:
    desired = int(deep_get(obj, "spec.replicas", 1) or 0)
    ready = int(deep_get(obj, "status.readyReplicas", 0) or 0)
    if obj.get("kind") == "DaemonSet":
        desired = int(deep_get(obj, "status.desiredNumberScheduled", 0) or 0)
        ready = int(deep_get(obj, "status.numberReady", 0) or 0)
    if obj.get("kind") in ("Job", "CronJob"):
        return "ok", ""
    if desired == 0:
        return "pending", "scaled to 0"
    if ready >= desired:
        return "ok", f"{ready}/{desired} ready"
    if ready == 0:
        return "error", f"0/{desired} ready"
    return "warn", f"{ready}/{desired} ready"


def elide(text: str, limit: int = 22) -> str:
    """Middle-elide long names so both the workload prefix and suffix stay visible."""
    text = str(text)
    if len(text) <= limit:
        return text
    head = max(6, limit - 9)
    return f"{text[:head]}..{text[-6:]}"


def _oid(obj: dict) -> str:
    return f'{obj.get("kind")}/{deep_get(obj, "metadata.namespace", "-")}/' \
           f'{deep_get(obj, "metadata.name")}'


def _fresh(cluster: Cluster, obj: dict, window: int = 12) -> bool:
    return cluster.tick - int(deep_get(obj, "metadata.creationTick", 0)) <= window


# ---------------------------------------------------------------------------
def build(cluster: Cluster, namespace: Optional[str] = None, view: str = "logical",
          include_system: bool = False) -> Graph:
    if view == "physical":
        return _build_physical(cluster, namespace, include_system)
    return _build_logical(cluster, namespace, include_system)


def _namespaces(cluster: Cluster, namespace: Optional[str],
                include_system: bool) -> List[str]:
    if namespace and namespace != "*":
        return [namespace]
    out = []
    for ns in cluster.namespaces():
        if not include_system and ns in ("kube-system", "kube-public",
                                         "kube-node-lease"):
            continue
        out.append(ns)
    return out


def _build_logical(cluster: Cluster, namespace: Optional[str],
                   include_system: bool) -> Graph:
    graph = Graph(view="logical")
    namespaces = _namespaces(cluster, namespace, include_system)
    index: Dict[str, GNode] = {}

    def push(node: GNode) -> GNode:
        index[node.id] = node
        graph.nodes.append(node)
        return node

    for ns in namespaces:
        # --- ingress ---------------------------------------------------
        for ing in cluster.list("Ingress", ns):
            hosts = ",".join(r.get("host", "*")
                             for r in deep_get(ing, "spec.rules", []) or []) or "*"
            missing = deep_get(ing, "status.missingBackends", []) or []
            push(GNode(_oid(ing), "Ingress", deep_get(ing, "metadata.name"), ns,
                       deep_get(ing, "metadata.name"), hosts[:26],
                       "error" if missing else "ok", tier=0,
                       color=colour_of("Ingress"), topic="ingress",
                       detail=f"class={deep_get(ing, 'spec.ingressClassName', 'none')}",
                       fresh=_fresh(cluster, ing)))
            for rule in deep_get(ing, "spec.rules", []) or []:
                for path in deep_get(rule, "http.paths", []) or []:
                    svc = deep_get(path, "backend.service.name")
                    if svc:
                        graph.edges.append(GEdge(_oid(ing), f"Service/{ns}/{svc}",
                                                 "routes", path.get("path", "/")))

        # --- services --------------------------------------------------
        for svc in cluster.list("Service", ns):
            endpoints = deep_get(svc, "status.endpoints", []) or []
            selector = deep_get(svc, "spec.selector", {}) or {}
            stype = deep_get(svc, "spec.type", "ClusterIP")
            status = "ok" if (endpoints or not selector) else "error"
            ports = ",".join(str(p.get("port")) for p in
                             deep_get(svc, "spec.ports", []) or [])
            push(GNode(_oid(svc), "Service", deep_get(svc, "metadata.name"), ns,
                       deep_get(svc, "metadata.name"),
                       f"{stype} :{ports}", status, tier=1,
                       color=colour_of("Service"), topic="services",
                       badge=f"{len(endpoints)} ep",
                       detail=f"clusterIP={deep_get(svc, 'spec.clusterIP', 'None')}",
                       fresh=_fresh(cluster, svc)))

        # --- workloads -------------------------------------------------
        for kind, topic in (("Deployment", "deployments"),
                            ("StatefulSet", "statefulsets"),
                            ("DaemonSet", "daemonsets"),
                            ("CronJob", "cronjobs"),
                            ("Job", "jobs")):
            for obj in cluster.list(kind, ns):
                if kind == "Job" and any(
                        o.get("kind") == "CronJob"
                        for o in deep_get(obj, "metadata.ownerReferences", []) or []):
                    pass  # keep, but it will be linked to its CronJob
                status, note = _workload_status(obj)
                images = ",".join(
                    str(c.get("image", "")).split("/")[-1]
                    for c in deep_get(obj, "spec.template.spec.containers", []) or [])
                if kind == "CronJob":
                    images = deep_get(obj, "spec.schedule", "")
                    note = "schedule"
                push(GNode(_oid(obj), kind, deep_get(obj, "metadata.name"), ns,
                           deep_get(obj, "metadata.name"), images[:26] or note,
                           status, tier=2, color=colour_of(kind), topic=topic,
                           badge=note, fresh=_fresh(cluster, obj),
                           detail=note))
                for ref in deep_get(obj, "metadata.ownerReferences", []) or []:
                    parent = f'{ref.get("kind")}/{ns}/{ref.get("name")}'
                    if parent in index or ref.get("kind") == "CronJob":
                        graph.edges.append(GEdge(parent, _oid(obj), "owns"))

        # --- replicasets ------------------------------------------------
        for rs in cluster.list("ReplicaSet", ns):
            desired = int(deep_get(rs, "spec.replicas", 0) or 0)
            ready = int(deep_get(rs, "status.readyReplicas", 0) or 0)
            if desired == 0 and ready == 0:
                continue           # old revisions kept for rollback; hide the clutter
            status = "ok" if ready >= desired else ("warn" if ready else "error")
            revision = annotation(rs, "deployment.kubernetes.io/revision", "")
            push(GNode(_oid(rs), "ReplicaSet", deep_get(rs, "metadata.name"), ns,
                       elide(deep_get(rs, "metadata.name"), 20),
                       f"rev {revision}" if revision else "", status, tier=3,
                       color=colour_of("ReplicaSet"), topic="replicasets",
                       badge=f"{ready}/{desired}", fresh=_fresh(cluster, rs)))
            for ref in deep_get(rs, "metadata.ownerReferences", []) or []:
                graph.edges.append(
                    GEdge(f'{ref.get("kind")}/{ns}/{ref.get("name")}', _oid(rs), "owns"))

        # --- pods -------------------------------------------------------
        for pod in cluster.list("Pod", ns):
            status, reason = _pod_status_class(pod)
            node_name = deep_get(pod, "spec.nodeName", "")
            push(GNode(_oid(pod), "Pod", deep_get(pod, "metadata.name"), ns,
                       elide(deep_get(pod, "metadata.name"), 20),
                       reason or "Running", status, tier=4,
                       color=colour_of("Pod"), topic="pods",
                       badge=node_name.replace("lab-", "") if node_name else "unscheduled",
                       detail=f'{deep_get(pod, "status.podIP", "-")} on '
                              f'{node_name or "-"}',
                       fresh=_fresh(cluster, pod)))
            owners = deep_get(pod, "metadata.ownerReferences", []) or []
            for ref in owners:
                graph.edges.append(
                    GEdge(f'{ref.get("kind")}/{ns}/{ref.get("name")}', _oid(pod), "owns"))
            # service -> pod
            for svc in cluster.list("Service", ns):
                selector = deep_get(svc, "spec.selector", {}) or {}
                if selector and match_labels(deep_get(pod, "metadata.labels", {}) or {},
                                             selector):
                    ready = deep_get(pod, "status.ready")
                    graph.edges.append(GEdge(_oid(svc), _oid(pod),
                                             "selects" if ready else "selects-notready"))

        # --- config / storage side rail ---------------------------------
        for kind, topic in (("ConfigMap", "configmaps"), ("Secret", "configmaps"),
                            ("PersistentVolumeClaim", "pvc")):
            for obj in cluster.list(kind, ns):
                name = deep_get(obj, "metadata.name")
                if kind == "ConfigMap" and str(name).startswith("sh.helm.release"):
                    continue
                if kind == "PersistentVolumeClaim":
                    phase = deep_get(obj, "status.phase", "Pending")
                    status = "ok" if phase == "Bound" else "warn"
                    sub = f'{phase} {deep_get(obj, "spec.resources.requests.storage", "")}'
                else:
                    status = "ok"
                    keys = {**(obj.get("data") or {}), **(obj.get("stringData") or {})}
                    sub = f'{len(keys)} keys'
                push(GNode(_oid(obj), kind, name, ns, name[:24], sub, status,
                           tier=-1, color=colour_of(kind), topic=topic,
                           fresh=_fresh(cluster, obj)))

        for hpa in cluster.list("HorizontalPodAutoscaler", ns):
            ref = deep_get(hpa, "spec.scaleTargetRef", {}) or {}
            current = deep_get(hpa, "status.currentCPUUtilizationPercentage", 0)
            target = deep_get(hpa, "status.targetCPUUtilizationPercentage", 80)
            status = "warn" if current > target else "ok"
            push(GNode(_oid(hpa), "HorizontalPodAutoscaler",
                       deep_get(hpa, "metadata.name"), ns,
                       deep_get(hpa, "metadata.name")[:24],
                       f"cpu {current}%/{target}%", status, tier=-1,
                       color=colour_of("HorizontalPodAutoscaler"), topic="hpa",
                       badge=f'{deep_get(hpa, "spec.minReplicas", 1)}-'
                             f'{deep_get(hpa, "spec.maxReplicas", 10)}',
                       fresh=_fresh(cluster, hpa)))
            graph.edges.append(GEdge(_oid(hpa),
                                     f'{ref.get("kind")}/{ns}/{ref.get("name")}',
                                     "scales"))

        for netpol in cluster.list("NetworkPolicy", ns):
            push(GNode(_oid(netpol), "NetworkPolicy", deep_get(netpol, "metadata.name"),
                       ns, deep_get(netpol, "metadata.name")[:24], "policy", "ok",
                       tier=-1, color=colour_of("NetworkPolicy"), topic="network-policies",
                       fresh=_fresh(cluster, netpol)))

        # pod -> configmap/secret/pvc edges
        for pod in cluster.list("Pod", ns):
            refs = set()
            for volume in deep_get(pod, "spec.volumes", []) or []:
                if deep_get(volume, "configMap.name"):
                    refs.add(f'ConfigMap/{ns}/{deep_get(volume, "configMap.name")}')
                if deep_get(volume, "secret.secretName"):
                    refs.add(f'Secret/{ns}/{deep_get(volume, "secret.secretName")}')
                claim = deep_get(volume, "persistentVolumeClaim.claimName")
                if claim:
                    refs.add(f"PersistentVolumeClaim/{ns}/{claim}")
            for container in deep_get(pod, "spec.containers", []) or []:
                for entry in container.get("env", []) or []:
                    ref = entry.get("valueFrom", {}) or {}
                    if deep_get(ref, "configMapKeyRef.name"):
                        refs.add(f'ConfigMap/{ns}/'
                                 f'{deep_get(ref, "configMapKeyRef.name")}')
                    if deep_get(ref, "secretKeyRef.name"):
                        refs.add(f'Secret/{ns}/{deep_get(ref, "secretKeyRef.name")}')
                for source in container.get("envFrom", []) or []:
                    if deep_get(source, "configMapRef.name"):
                        refs.add(f'ConfigMap/{ns}/'
                                 f'{deep_get(source, "configMapRef.name")}')
                    if deep_get(source, "secretRef.name"):
                        refs.add(f'Secret/{ns}/{deep_get(source, "secretRef.name")}')
            for ref_id in refs:
                if ref_id in index:
                    graph.edges.append(GEdge(ref_id, _oid(pod), "mounts"))

    # bound PVs
    for pvc in [o for o in cluster.all_objects()
                if o.get("kind") == "PersistentVolumeClaim" and
                deep_get(o, "metadata.namespace") in namespaces]:
        volume_name = deep_get(pvc, "status.volumeName")
        if not volume_name:
            continue
        pv = cluster.get("PersistentVolume", "", volume_name)
        if pv is None:
            continue
        pv_id = f"PersistentVolume/-/{volume_name}"
        if pv_id not in index:
            push(GNode(pv_id, "PersistentVolume", volume_name, "", volume_name[:22],
                       deep_get(pv, "spec.capacity.storage", ""), "ok", tier=-1,
                       color=colour_of("PersistentVolume"), topic="pv",
                       fresh=_fresh(cluster, pv),
                       band=deep_get(pvc, "metadata.namespace", "default")))
        graph.edges.append(GEdge(pv_id, _oid(pvc), "binds"))

    graph.edges = [e for e in graph.edges if e.src in index and e.dst in index]
    for edge in graph.edges:                      # tint each edge by what it feeds
        anchor = index.get(edge.dst if edge.kind in ("owns", "routes", "selects",
                                                     "selects-notready", "mounts",
                                                     "binds") else edge.src)
        if anchor is not None:
            edge.colour = colour_of(anchor.kind)
    _layout_namespaced(graph, namespaces)
    graph.stats = _stats(cluster, namespaces)
    return graph


BAND_HEAD, BAND_PAD, BAND_GAP, RAIL_GAP = 38, 16, 20, 32
MAX_PER_ROW = 6          # wrap a wide tier instead of running off the screen
ROW_GAP = 10


def _layout_namespaced(graph: Graph, namespaces: List[str]) -> None:
    """Lay out one layered sub-graph per namespace, stacked in labelled lanes.

    Everything you create lands in the lane of the namespace it was created in
    -- including ConfigMaps, Secrets, PVCs and HPAs, which sit in that lane's
    side rail with dashed edges to the pods that consume them.
    """
    parents: Dict[str, List[str]] = {}
    for edge in graph.edges:
        parents.setdefault(edge.dst, []).append(edge.src)

    lanes: Dict[str, List[GNode]] = {}
    for node in graph.nodes:
        lanes.setdefault(node.band or node.namespace or "default", []).append(node)

    ordered = [ns for ns in namespaces if ns in lanes]
    ordered += [ns for ns in sorted(lanes) if ns not in ordered]

    y_cursor = float(MARGIN_Y)
    widest = 0.0
    for ns in ordered:
        members = lanes[ns]
        main = [n for n in members if n.tier >= 0]
        rail = [n for n in members if n.tier < 0]
        if not main and not rail:
            continue

        tiers: Dict[int, List[GNode]] = {}
        for node in main:
            tiers.setdefault(node.tier, []).append(node)
        order = sorted(tiers)

        positions: Dict[str, float] = {}
        for index, tier in enumerate(order):
            nodes = tiers[tier]
            if index == 0:
                nodes.sort(key=lambda n: n.name)
            else:
                def barycenter(node: GNode) -> float:
                    seen = [positions[p] for p in parents.get(node.id, [])
                            if p in positions]
                    return sum(seen) / len(seen) if seen else 9999.0
                nodes.sort(key=lambda n: (barycenter(n), n.name))
            for column, node in enumerate(nodes):
                positions[node.id] = float(column)

        widest_row = min(MAX_PER_ROW,
                         max((len(v) for v in tiers.values()), default=0))
        grid_w = widest_row * (NODE_W + X_GAP) - X_GAP if widest_row else 0
        x0 = MARGIN_X + BAND_PAD
        y0 = y_cursor + BAND_HEAD

        cursor_y = y0
        for tier in order:
            nodes = tiers[tier]
            rows = [nodes[i:i + MAX_PER_ROW]
                    for i in range(0, len(nodes), MAX_PER_ROW)] or [[]]
            for row_index, row in enumerate(rows):
                row_w = len(row) * (NODE_W + X_GAP) - X_GAP
                start = x0 + (grid_w - row_w) / 2
                for column, node in enumerate(row):
                    node.x = start + column * (NODE_W + X_GAP)
                    node.y = cursor_y + row_index * (NODE_H + ROW_GAP)
            cursor_y += (len(rows) - 1) * (NODE_H + ROW_GAP) + Y_GAP

        grid_h = (cursor_y - Y_GAP + NODE_H) - y0 if order else 0

        rail.sort(key=lambda n: (RAIL_ORDER.get(n.kind, 9), n.name))
        rail_x = x0 + (grid_w + RAIL_GAP if grid_w else 0)
        for index, node in enumerate(rail):
            node.x = rail_x
            node.y = y0 + index * (NODE_H + 12)
        rail_h = len(rail) * (NODE_H + 12) - 12 if rail else 0

        band_w = (rail_x + (NODE_W if rail else 0) + BAND_PAD) - MARGIN_X
        band_w = max(band_w, 460)
        band_h = BAND_HEAD + max(grid_h, rail_h) + 18

        pods = sum(1 for n in members if n.kind == "Pod")
        problems = sum(1 for n in members if n.status == "error")
        graph.groups.append({
            "id": f"ns-{ns}", "kind": "Namespace", "name": ns,
            "x": MARGIN_X, "y": y_cursor, "w": band_w, "h": band_h,
            "status": "error" if problems else "ok",
            "title": f"namespace: {ns}",
            "subtitle": f"{len(members)} objects - {pods} pods"
                        + (f" - {problems} with problems" if problems else ""),
            "cpu_pct": 0, "mem_pct": 0, "taints": [], "labels": {},
            "pods": pods})
        widest = max(widest, MARGIN_X + band_w)
        y_cursor += band_h + BAND_GAP

    graph.width = max(widest + MARGIN_X, 760)
    graph.height = max(y_cursor - BAND_GAP + MARGIN_Y, 420)


RAIL_ORDER = {"ConfigMap": 0, "Secret": 1, "PersistentVolumeClaim": 2,
              "PersistentVolume": 3, "HorizontalPodAutoscaler": 4,
              "VerticalPodAutoscaler": 5, "NetworkPolicy": 6, "ServiceAccount": 7}


def _build_physical(cluster: Cluster, namespace: Optional[str],
                    include_system: bool) -> Graph:
    graph = Graph(view="physical")
    namespaces = _namespaces(cluster, namespace, include_system)
    nodes = cluster.list("Node")
    pods_by_node: Dict[str, List[dict]] = {}
    unscheduled: List[dict] = []
    for pod in cluster.list("Pod"):
        if deep_get(pod, "metadata.namespace") not in namespaces:
            continue
        node_name = deep_get(pod, "spec.nodeName")
        if node_name:
            pods_by_node.setdefault(node_name, []).append(pod)
        else:
            unscheduled.append(pod)

    box_w, pad = 306, 18
    pod_w, pod_h, pod_gap = 130, 50, 9
    per_row = 2
    columns = max(1, min(4, len(nodes)))
    col_gap, row_gap = 26, 24

    def box_height(count: int) -> float:
        rows = max(1, (count + per_row - 1) // per_row)
        return 76 + rows * (pod_h + pod_gap)

    row_tops: Dict[int, float] = {}
    row_heights: Dict[int, float] = {}
    for index, node in enumerate(nodes):
        row = index // columns
        height = box_height(len(pods_by_node.get(deep_get(node, "metadata.name"), [])))
        row_heights[row] = max(row_heights.get(row, 0), height)
    running_y = MARGIN_Y
    for row in sorted(row_heights):
        row_tops[row] = running_y
        running_y += row_heights[row] + row_gap
    max_height = running_y - row_gap if row_heights else MARGIN_Y

    for index, node in enumerate(nodes):
        name = deep_get(node, "metadata.name")
        pods = pods_by_node.get(name, [])
        usage = deep_get(node, "status.usage", {}) or {}
        ready = deep_get(node, "status.ready", True)
        cordoned = deep_get(node, "spec.unschedulable", False)
        taints = deep_get(node, "spec.taints", []) or []
        status = "ok" if ready and not cordoned else ("warn" if ready else "error")
        col, row = index % columns, index // columns
        node_x = MARGIN_X + col * (box_w + col_gap)
        node_y = row_tops[row]
        role = deep_get(node, "status.role", "worker")
        state = "NotReady" if not ready else ("cordoned" if cordoned else "Ready")
        graph.groups.append({
            "id": f"node-{name}", "kind": "Node", "name": name,
            "x": node_x, "y": node_y, "w": box_w, "h": row_heights[row],
            "status": status, "title": name,
            "subtitle": f"{role} - {state} - {len(pods)} pods"
                        + (f" - {len(taints)} taint(s)" if taints else ""),
            "cpu_pct": usage.get("cpuPct", 0), "mem_pct": usage.get("memPct", 0),
            "taints": [f'{t.get("key")}={t.get("value", "")}:{t.get("effect")}'
                       for t in taints],
            "labels": deep_get(node, "metadata.labels", {}) or {},
            "pods": len(pods)})
        for pod_index, pod in enumerate(pods):
            status, reason = _pod_status_class(pod)
            graph.nodes.append(GNode(
                _oid(pod), "Pod", deep_get(pod, "metadata.name"),
                deep_get(pod, "metadata.namespace", "default"),
                elide(deep_get(pod, "metadata.name"), 18), reason, status,
                x=node_x + pad + (pod_index % per_row) * (pod_w + pod_gap),
                y=node_y + 68 + (pod_index // per_row) * (pod_h + pod_gap),
                w=pod_w, h=pod_h, color=colour_of("Pod"), topic="pods",
                badge=deep_get(pod, "metadata.namespace", ""),
                detail=f'{deep_get(pod, "status.podIP", "-")}',
                fresh=_fresh(cluster, pod)))

    if unscheduled:
        node_y = max_height + row_gap
        height = box_height(len(unscheduled))
        graph.groups.append({
            "id": "node-pending", "kind": "Pending", "name": "Unscheduled",
            "x": MARGIN_X, "y": node_y, "w": box_w, "h": height, "status": "error",
            "title": "Unscheduled (Pending)",
            "subtitle": "no node satisfied these pods -- describe them",
            "cpu_pct": 0, "mem_pct": 0, "taints": [], "labels": {},
            "pods": len(unscheduled)})
        for pod_index, pod in enumerate(unscheduled):
            status, reason = _pod_status_class(pod)
            graph.nodes.append(GNode(
                _oid(pod), "Pod", deep_get(pod, "metadata.name"),
                deep_get(pod, "metadata.namespace", "default"),
                elide(deep_get(pod, "metadata.name"), 18), reason, status,
                x=MARGIN_X + pad + (pod_index % per_row) * (pod_w + pod_gap),
                y=node_y + 68 + (pod_index // per_row) * (pod_h + pod_gap),
                w=pod_w, h=pod_h, color=colour_of("Pod"), topic="troubleshooting",
                badge=deep_get(pod, "metadata.namespace", ""),
                fresh=_fresh(cluster, pod)))
        max_height = node_y + height

    graph.width = max(MARGIN_X * 2 + columns * (box_w + col_gap), 720)
    graph.height = max_height + MARGIN_Y
    graph.stats = _stats(cluster, namespaces)
    return graph


def _stats(cluster: Cluster, namespaces: List[str]) -> dict:
    pods = [p for p in cluster.list("Pod")
            if deep_get(p, "metadata.namespace") in namespaces]
    running = sum(1 for p in pods if deep_get(p, "status.phase") == "Running" and
                  deep_get(p, "status.ready"))
    problems = sum(1 for p in pods if _pod_status_class(p)[0] == "error")
    warnings = len([e for e in cluster.events[-60:] if e.type == "Warning"])
    return {
        "tick": cluster.tick,
        "nodes": len(cluster.list("Node")),
        "pods": len(pods),
        "running": running,
        "problems": problems,
        "warnings": warnings,
        "namespaces": len(cluster.namespaces()),
        "objects": len(cluster.all_objects()),
    }


def legend() -> List[Tuple[str, str]]:
    """(label, colour) pairs grouped by section, for the canvas legend."""
    seen, out = set(), []
    for kind, (section, _) in KIND_STYLE.items():
        if section in seen:
            continue
        seen.add(section)
        out.append((section, SECTION_COLORS.get(section, "#94a3b8")))
    return out


def legend_detail() -> List[dict]:
    """Full section -> colour -> kinds map, for the sidebar and canvas legend."""
    groups: Dict[str, List[dict]] = {}
    for kind, (section, tone) in KIND_STYLE.items():
        groups.setdefault(section, []).append({"kind": kind, "colour": tone})
    for section in SECTION_COLORS:                 # sections with no object kinds
        groups.setdefault(section, [])
    return [{"section": section,
             "colour": SECTION_COLORS.get(section, "#94a3b8"),
             "kinds": kinds}
            for section, kinds in groups.items()]
