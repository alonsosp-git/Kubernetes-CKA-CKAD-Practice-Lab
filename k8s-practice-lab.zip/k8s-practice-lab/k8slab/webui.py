"""Browser UI, served by the standard library only (no Flask, no npm).

    python k8s_lab.py --web            -> http://127.0.0.1:8899

This is also what the Docker container runs, which is why the very first panel
in the page is "Deploy to Docker": build the image, start the container and
open it, without leaving the UI.

Security model
--------------
This server drives a shell and can build container images, so it is treated as
a privileged local application, not as a public web site:

* it listens on the loopback interface only, unless you deliberately override
  that and acknowledge the consequences;
* every request must carry a session token that is minted at start-up and only
  ever handed to the page this process itself served;
* every request must arrive with a loopback ``Host`` and a same-origin
  ``Origin``/``Sec-Fetch-Site``, which is what stops another site in your
  browser from driving it (CSRF) or resolving its own name to 127.0.0.1 to read
  the answers (DNS rebinding);
* responses carry a nonce-based Content-Security-Policy and the usual
  hardening headers, so injected markup cannot execute or phone home.
"""
from __future__ import annotations

import json
import mimetypes
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qs, urlparse

from . import (dictionary, diagrams, export, handbook, labs as lab_index,
               miniyaml, portable, printers, security, topology)
from .controllers import reconcile
from .kubectl import Shell

STATE_LOCK = threading.RLock()
_SERVER: Optional[ThreadingHTTPServer] = None
_SERVER_URL = ""

IN_CONTAINER = os.path.exists("/.dockerenv") or os.environ.get("K8SLAB_IN_DOCKER") == "1"
IMAGE_NAME = "k8s-practice-lab"
CONTAINER_NAME = "k8s-lab"

#: Expensive endpoints (zip building, whole-cluster rendering, docker) are
#: rate-limited so one tab cannot pin a CPU (CWE-400 / OWASP API4). The ceiling
#: is generous -- this is a single-user local tool, and the point is to bound
#: a runaway loop, not to ration normal use.
HEAVY_LIMITER = security.RateLimiter(capacity=40, per_seconds=60.0)
DOCKER_LIMITER = security.RateLimiter(capacity=4, per_seconds=60.0)

#: The lab bundles are a pure function of the files on disk, so building one
#: twice in a row is wasted work. Caching removes most of the reason the
#: limiter above exists, which is the better way round: make the expensive
#: thing cheap rather than relying on a quota to contain it.
_BUNDLE_CACHE: Dict[str, bytes] = {}
_BUNDLE_LOCK = threading.Lock()


def _bundle(flavour: str, base_dir: str) -> bytes:
    with _BUNDLE_LOCK:
        cached = _BUNDLE_CACHE.get(flavour)
        if cached is None:
            cached = portable.build_full_bundle(base_dir, flavour)
            if len(cached) <= security.MAX_ARCHIVE_BYTES:
                _BUNDLE_CACHE[flavour] = cached
        return cached


# ---------------------------------------------------------------------------
class LabService:
    """Everything the browser can ask for, wrapped around one Shell."""

    def __init__(self, shell: Shell, state_dir: Optional[str] = None):
        self.shell = shell
        self.state_dir = state_dir
        if state_dir:
            # The one directory outside the project the shell may use, and only
            # because that is where progress is stored.
            shell.extra_roots.append(os.path.abspath(state_dir))
        self.log: List[dict] = []
        self.autotick = True
        self.started_at = time.time()
        self.runner: Dict[str, Any] = {"active": False, "lab": "", "index": 0,
                                       "total": 0, "done": [], "stop": False,
                                       "command": "", "errors": 0}
        self._stop = threading.Event()
        self._ticker = threading.Thread(target=self._tick_loop, daemon=True)
        self._ticker.start()

    def _tick_loop(self) -> None:
        while not self._stop.is_set():
            time.sleep(1.0)
            if self.autotick:
                with STATE_LOCK:
                    try:
                        reconcile(self.shell.cluster, 1)
                    except Exception:
                        pass

    # -- actions -------------------------------------------------------
    def run(self, command: str, expected: bool = False) -> dict:
        with STATE_LOCK:
            result = self.shell.run(command)
        # The transcript is exportable and gets pasted into issues and chats,
        # so anything shaped like a credential is masked on the way in
        # (CWE-532). The lab's own Secrets are fake; live mode's flags are not.
        entry = {"cmd": security.redact(command), "ok": result.ok,
                 "out": security.redact(result.out if result.ok else result.err),
                 "topic": result.topic,
                 "expected": bool(expected and not result.ok),
                 "ns": self.shell.cluster.current_namespace,
                 "tick": self.shell.cluster.tick,
                 "at": time.strftime("%H:%M:%S"),
                 "elapsed": round(time.time() - self.started_at, 1),
                 "lab": self.runner.get("lab", "") if self.runner.get("active") else ""}
        self.log.append(entry)
        del self.log[:-security.MAX_LOG_ENTRIES]
        return entry

    # -- run every lab, back to back -----------------------------------
    def run_all(self, pause: float = 0.25, tick_between: int = 6,
                reset_between: bool = False, mark_progress: bool = True) -> None:
        """Replay every lab.

        By default nothing is reset, so when it finishes the topology holds
        everything all 29 labs built -- which is the whole point of leaving it
        running. Pass reset_between to get a clean slate per lab instead.
        """
        if self.runner["active"]:
            return
        labs = [lab for lab in lab_index.LABS if lab.exists()]
        self.runner.update({"active": True, "stop": False, "index": 0,
                            "total": len(labs), "done": [], "errors": 0,
                            "reset_between": reset_between})

        def worker():
            try:
                for number, lab in enumerate(labs, start=1):
                    if self.runner["stop"]:
                        break
                    self.runner.update({"lab": lab.title, "index": number})
                    expect = False
                    for raw in lab.read().splitlines():
                        if self.runner["stop"]:
                            break
                        line = raw.strip()
                        if line.startswith("#!expect-error"):
                            expect = True
                            continue
                        if not line or line.startswith("#"):
                            continue
                        self.runner["command"] = line
                        entry = self.run(line, expect)
                        if not entry["ok"] and not entry["expected"]:
                            self.runner["errors"] += 1
                        expect = False
                        time.sleep(pause)
                    with STATE_LOCK:
                        reconcile(self.shell.cluster, tick_between)
                    self.runner["done"].append(lab.title)
                    if mark_progress:
                        self._mark_lab_done(lab)
                    if reset_between and number < len(labs) and not self.runner["stop"]:
                        self.shell.run("sim reset")
            finally:
                self.runner.update({"active": False, "command": "", "lab": ""})

        threading.Thread(target=worker, daemon=True).start()

    def _mark_lab_done(self, lab) -> None:
        """Tick every handbook topic this lab covers."""
        done = set(self.load_progress()["done"])
        for key in handbook.ORDER:
            topic = handbook.TOPICS[key]
            if topic.lab == lab.file or topic.key == lab.topic:
                done.add(key)
        self.save_progress(sorted(done))

    def log_text(self) -> str:
        cluster = self.shell.cluster
        lines = [
            "# k8s-practice-lab session transcript",
            f"# cluster:   {cluster.name}",
            f"# exported:  {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"# commands:  {len(self.log)}",
            f"# failures:  {sum(1 for e in self.log if not e['ok'] and not e['expected'])}"
            f"  (plus {sum(1 for e in self.log if e['expected'])} deliberate)",
            "#" + "-" * 70, ""]
        for index, entry in enumerate(self.log, start=1):
            status = "OK" if entry["ok"] else ("EXPECTED-FAIL" if entry["expected"]
                                               else "FAIL")
            lines.append(f"[{index:>4}] {entry.get('at', '')}  tick "
                         f"{entry.get('tick', 0):<5} {status:<14}"
                         + (f"lab: {entry['lab']}" if entry.get("lab") else ""))
            lines.append(f"{entry.get('ns', 'default')} $ {entry['cmd']}")
            if entry["out"]:
                lines.append("    " + entry["out"].replace("\n", "\n    "))
            lines.append("")
        return "\n".join(lines)

    def topology_svg(self, namespace: Optional[str], view: str,
                     system: bool) -> Dict[str, Any]:
        with STATE_LOCK:
            graph = topology.build(self.shell.cluster, namespace, view, system)
        return {"svg": export.to_svg(graph, "", with_background=False),
                "width": graph.width, "height": graph.height + 20,
                "stats": graph.stats,
                "nodes": [n.as_dict() for n in graph.nodes]}

    def state(self) -> dict:
        cluster = self.shell.cluster
        with STATE_LOCK:
            events = [{"type": e.type, "reason": e.reason, "message": e.message,
                       "object": e.involved, "ns": e.namespace,
                       "age": cluster.tick - e.tick} for e in cluster.events[-25:]][::-1]
        return {
            "namespaces": cluster.namespaces(),
            "current": cluster.current_namespace,
            "user": cluster.current_user,
            "rbac": cluster.rbac_enforced,
            "tick": cluster.tick,
            "live": self.shell.live,
            "autotick": self.autotick,
            "events": events,
            "in_container": IN_CONTAINER,
            "docker": shutil.which("docker") is not None,
        }

    # -- progress -----------------------------------------------------
    @property
    def progress_path(self) -> str:
        """Where ticked topics are remembered.

        Per-service, so two servers in one process (the test suite) never share
        a file. Falls back to $K8SLAB_STATE, then to the project directory.
        """
        root = self.state_dir or os.environ.get("K8SLAB_STATE") \
            or self.shell.base_dir
        return os.path.join(root, "lab-progress.json")

    def load_progress(self) -> dict:
        try:
            with open(self.progress_path, encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            data = {}
        done = [k for k in data.get("done", []) if k in handbook.TOPICS]
        return {"done": done, "total": len(handbook.ORDER),
                "notes": data.get("notes", {})}

    def save_progress(self, done: List[str], notes: Optional[dict] = None) -> dict:
        payload = {"done": sorted(set(k for k in done if k in handbook.TOPICS)),
                   "notes": notes or {}}
        try:
            with open(self.progress_path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
        except OSError:
            pass
        payload["total"] = len(handbook.ORDER)
        return payload

    def describe(self, node_id: str) -> str:
        parts = node_id.split("/")
        if len(parts) != 3:
            return "unknown object"
        kind, namespace, name = parts
        namespace = "" if namespace == "-" else namespace
        with STATE_LOCK:
            obj = self.shell.cluster.get(kind, namespace, name)
            if obj is None:
                return f"{node_id} no longer exists"
            return (printers.describe(self.shell.cluster, obj) +
                    "\n\n" + "-" * 58 + "\nYAML\n" + "-" * 58 + "\n" +
                    printers.to_output(obj, "yaml"))


# ---------------------------------------------------------------------------
def _docker_ready() -> Optional[str]:
    """Return None when docker can be used, otherwise a human explanation."""
    if IN_CONTAINER:
        return ("This UI is already running inside the container.\n"
                "Manage it from your host shell:  docker ps / docker logs "
                f"{CONTAINER_NAME}")
    if shutil.which("docker") is None:
        return ("Docker is not installed (or not on PATH).\n\n"
                "Install Docker Desktop from https://docs.docker.com/get-docker/ "
                "and press Deploy again.\n\n"
                "The lab keeps working without Docker -- you are using it right now.")
    probe = subprocess.run(["docker", "info", "--format", "{{.ServerVersion}}"],
                           capture_output=True, text=True, timeout=30)
    if probe.returncode != 0:
        detail = (probe.stderr or probe.stdout or "").strip().splitlines()
        hint = detail[-1] if detail else ""
        return ("Docker is installed but the engine is not running.\n\n"
                "  * Windows / macOS : start Docker Desktop and wait for the whale "
                "icon to stop animating\n"
                "  * Linux           : sudo systemctl start docker\n"
                "  * WSL             : enable Settings > Resources > WSL integration "
                "in Docker Desktop\n\n"
                f"Docker said: {hint}\n\n"
                "Nothing is broken in the lab -- this only affects the container "
                "deployment.")
    return None


def docker_action(action: str, port: int) -> dict:
    """Build / run / stop the container on behalf of the browser.

    `deploy` is the single button: one call builds the image, replaces any old
    container and starts the new one.
    """
    try:
        problem = _docker_ready()
    except Exception as exc:                       # docker present but wedged
        problem = f"Could not talk to Docker: {exc}"
    if problem:
        return {"ok": False, "reason": "docker-unavailable", "out": problem,
                "commands": [f"docker build -t {IMAGE_NAME} .",
                             f"docker run -d --name {CONTAINER_NAME} "
                             f"-p {port}:8899 {IMAGE_NAME}"]}

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # Every argument is a literal in a list -- there is no shell here, so no
    # amount of odd input can add a flag (CWE-78). The run flags mirror
    # docker-compose.yml: loopback publish, no capabilities, no privilege
    # escalation, read-only root, bounded memory and process count.
    deploy = [["docker", "build", "-t", IMAGE_NAME, "."],
              ["docker", "rm", "-f", CONTAINER_NAME],
              ["docker", "run", "-d", "--name", CONTAINER_NAME,
               "-p", f"127.0.0.1:{port}:8899",
               "--cap-drop", "ALL",
               "--security-opt", "no-new-privileges:true",
               "--read-only",
               "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=64m",
               "--pids-limit", "256",
               "--memory", "512m",
               # a path inside the container's own tmpfs, not on this host
               "-e", "K8SLAB_STATE=/tmp/k8slab",  # nosec B108
               IMAGE_NAME]]
    commands = {
        "deploy": deploy, "up": deploy, "build": [deploy[0]], "run": deploy[1:],
        "compose": [["docker", "compose", "up", "-d", "--build"]],
        "stop": [["docker", "rm", "-f", CONTAINER_NAME]],
        "status": [["docker", "ps", "-a", "--filter", f"name={CONTAINER_NAME}",
                    "--format", "table {{.Names}}\t{{.Status}}\t{{.Ports}}"]],
        "logs": [["docker", "logs", "--tail", "40", CONTAINER_NAME]],
    }.get(action)
    if commands is None:
        return {"ok": False, "out": f"unknown docker action {action}"}

    output, ok = [], True
    for argv in commands:
        output.append("$ " + " ".join(argv))
        try:
            proc = subprocess.run(argv, cwd=root, capture_output=True, text=True,
                                  timeout=1800)
            body = ((proc.stdout or "") + (proc.stderr or "")).strip()
            if body:
                output.append(body)
            if proc.returncode != 0 and argv[1] != "rm":
                ok = False
                break
        except Exception as exc:
            output.append(f"error: {exc}")
            ok = False
            break
    if ok and action in ("deploy", "up", "run", "compose"):
        output.append(f"\nContainer is up  ->  http://localhost:{port}")
    return {"ok": ok, "out": "\n".join(output)}


# ---------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    service: LabService
    port: int = 8899
    token: str = ""
    allow_remote: bool = False
    #: Suppress the Python/BaseHTTP version banner (CWE-200): the client has no
    #: use for our interpreter version, and scanners do.
    server_version = security.SERVER_TOKEN
    sys_version = ""
    protocol_version = "HTTP/1.1"

    def version_string(self) -> str:
        return security.SERVER_TOKEN

    def log_message(self, fmt, *args):        # keep the console quiet
        pass

    def handle_one_request(self):             # ignore client disconnects
        try:
            super().handle_one_request()
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True

    # -- request gate --------------------------------------------------
    def _client(self) -> str:
        try:
            return self.client_address[0]
        except Exception:                     # pragma: no cover
            return "?"

    def _refuse(self, status: int, reason: str) -> None:
        """One shape of refusal for every reason, with no internal detail.

        Verbose failures tell an attacker which control they tripped; the user
        is running this locally and gets the real explanation on the console.
        """
        self._send(reason.encode(), "text/plain; charset=utf-8", status)

    def _authorised(self, path: str, query: Dict[str, List[str]]) -> Optional[str]:
        """Return None when the request may proceed, else a refusal reason.

        Four independent checks, applied in order of cheapness. The token is the
        real access control; Host and Origin exist so that a *browser* cannot be
        tricked into making the request on the user's behalf with their token
        attached, and the loopback check is the backstop if the server was
        deliberately exposed.
        """
        # 1. connection must come from this machine, unless explicitly opened up
        if not self.allow_remote and not security.is_loopback(self._client()):
            return "this lab only accepts connections from the same machine"

        # 2. Host header must be one of ours -- the DNS-rebinding control
        if not security.host_allowed(self.headers.get("Host"), self.port):
            return "unexpected Host header"

        # 3. no cross-site requests, ever -- the CSRF control
        if not security.origin_allowed(self.headers.get("Origin"),
                                       self.headers.get("Referer"),
                                       self.headers.get("Sec-Fetch-Site"),
                                       self.port):
            return "cross-origin requests are not accepted"

        # 4. session token. Two routes are exempt: the page itself, because
        #    serving it is how the browser learns the token, and /healthz,
        #    which the container runtime probes and which discloses nothing.
        if path in ("/", "/index.html", "/healthz"):
            return None
        presented = (self.headers.get("X-K8SLab-Token")
                     or query.get("token", [""])[0])
        if not security.token_matches(self.token, presented):
            return ("missing or invalid session token -- open the URL printed "
                    "by the lab in your own browser")
        return None

    def _read_body(self) -> Optional[dict]:
        """Read and parse a JSON body, with a hard size ceiling.

        Requiring `application/json` is a second CSRF control: a cross-origin
        `fetch` with that content type is not a "simple request", so the browser
        must preflight it, and our missing CORS headers make the preflight fail
        before the real request is ever sent.
        """
        raw_length = self.headers.get("Content-Length") or "0"
        try:
            length = int(raw_length)
        except ValueError:
            return None
        if length < 0 or length > security.MAX_REQUEST_BYTES:
            return None
        content_type = (self.headers.get("Content-Type") or "").split(";")[0].strip()
        if length and content_type != security.JSON_CONTENT_TYPE:
            return None
        try:
            body = self.rfile.read(length) if length else b"{}"
        except (BrokenPipeError, ConnectionResetError):
            return None
        try:
            parsed = json.loads(body or b"{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None
        return parsed if isinstance(parsed, dict) else None

    # -- helpers -------------------------------------------------------
    def _send(self, body: bytes, content_type: str = "text/html; charset=utf-8",
              status: int = 200, cache: bool = False,
              nonce: str = "", filename: str = "") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        for name, value in security.SECURITY_HEADERS.items():
            self.send_header(name, value)
        self.send_header("Content-Security-Policy",
                         security.CSP_TEMPLATE.format(nonce=nonce or "none"))
        # Cache only the immutable assets; everything else reflects live
        # cluster state and must not sit in a shared cache (CWE-524).
        self.send_header("Cache-Control",
                         "private, max-age=86400" if cache else security.NO_STORE)
        if filename:
            # Quotes and separators are stripped so the header cannot be split
            # or the name used to suggest a path (CWE-113 / CWE-22).
            safe = "".join(c for c in filename
                           if c.isalnum() or c in "._- ()").strip()[:120]
            self.send_header("Content-Disposition",
                             f'attachment; filename="{safe or "download"}"')
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _json(self, payload: Any, status: int = 200) -> None:
        self._send(json.dumps(payload, default=str).encode(),
                   "application/json; charset=utf-8", status)

    def _zip(self, body: bytes, filename: str) -> None:
        self._send(body, "application/zip", filename=filename)

    # -- routes --------------------------------------------------------
    def do_GET(self) -> None:                                   # noqa: N802
        try:
            self._get()
        except Exception:                     # pragma: no cover - safety net
            # A traceback in the response body is an information leak
            # (CWE-209); it goes to the console the user is already watching.
            import traceback
            traceback.print_exc(file=sys.stderr)
            self._refuse(500, "internal error -- see the lab's console output")

    def _get(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        if len(self.path) > 4096:
            return self._refuse(414, "URL too long")
        query = parse_qs(parsed.query)
        refusal = self._authorised(path, query)
        if refusal:
            return self._refuse(403, refusal)
        service = self.service

        if path in ("/", "/index.html"):
            # A fresh nonce per response, so the CSP can forbid inline script
            # outright and still allow our own one <script> block to run.
            nonce = security.new_nonce()
            return self._send(page_html(self.port, self.token, nonce).encode(),
                              nonce=nonce)
        if path == "/healthz":
            # Deliberately says nothing beyond "the process is up": no version,
            # no uptime, no object counts (CWE-200).
            return self._send(b"ok", "text/plain; charset=utf-8")
        if path == "/api/state":
            return self._json(service.state())
        if path == "/api/topology":
            namespace = query.get("ns", ["default"])[0]
            namespace = None if namespace == "*" else namespace
            view = query.get("view", ["logical"])[0]
            system = query.get("system", ["0"])[0] == "1"
            return self._json(service.topology_svg(namespace, view, system))
        if path == "/api/handbook":
            return self._json({
                "sections": [{"name": name,
                              "topics": [{"key": k,
                                          "title": handbook.TOPICS[k].title,
                                          "page": handbook.TOPICS[k].pages[0],
                                          "lab": handbook.TOPICS[k].lab_number}
                                         for k in keys]}
                             for name, keys in handbook.SECTIONS]})
        if path.startswith("/api/topic/"):
            key = security.safe_name(path.rsplit("/", 1)[-1], security.TOPIC_KEY)
            topic = handbook.TOPICS.get(key) if key else None
            if topic is None:
                return self._json({"error": "not found"}, 404)
            related = lab_index.by_topic(topic.key)
            if topic.lab:
                direct = lab_index.by_file(topic.lab)
                if direct is not None and direct not in related:
                    related = [direct] + related
            script = ""
            if related and related[0].exists():
                script = related[0].read()
            return self._json({
                "key": topic.key, "title": topic.title, "summary": topic.summary,
                "section": topic.section, "lab_number": topic.lab_number,
                "manifest": handbook.manifest_for(topic),
                "manifest_name": handbook.manifest_filename(topic),
                "bullets": topic.bullets,
                "commands": handbook.annotated_commands(topic),
                "yaml": topic.yaml, "gotchas": topic.gotchas,
                "interview": topic.interview, "pages": topic.pages,
                "images": [f"/pages/{os.path.basename(p)}"
                           for p in topic.page_files()],
                "script": script,
                "diagram": f"/diagram/{topic.key}.svg" if diagrams.has(topic.key)
                           else "",
                "certs": handbook.certs_for(topic.key),
                "labs": [{"file": lab.file, "title": lab.title}
                         for lab in related]})
        if path == "/api/labs":
            return self._json({"labs": [{"file": lab.file, "title": lab.title,
                                         "goal": lab.goal, "topic": lab.topic,
                                         "checks": lab.checks,
                                         "exists": lab.exists()}
                                        for lab in lab_index.LABS]})
        if path.startswith("/api/lab/"):
            # Allowlisted by shape, so the route cannot be walked out of the
            # labs directory no matter how the name is encoded (CWE-22).
            name = security.safe_name(path.rsplit("/", 1)[-1], security.LAB_FILE)
            lab = lab_index.by_file(name) if name else None
            if lab is None or not lab.exists():
                return self._json({"error": "not found"}, 404)
            return self._json({"file": lab.file, "title": lab.title,
                               "body": lab.read(), "commands": lab.commands()})
        if path.startswith("/diagram/"):
            key = security.safe_name(
                path.rsplit("/", 1)[-1].removesuffix(".svg"), security.TOPIC_KEY)
            svg = diagrams.render(key) if key else None
            if svg is None:
                return self._send(b"no diagram", "text/plain", 404)
            return self._send(svg.encode(), "image/svg+xml; charset=utf-8",
                              cache=True)
        if path.startswith("/pages/"):
            name = security.safe_name(path.rsplit("/", 1)[-1], security.PAGE_IMAGE)
            if not name:
                return self._send(b"not found", "text/plain", 404)
            try:
                full = security.safe_path(handbook.PAGES_DIR, name,
                                          must_exist=True)
            except security.PathRefused:
                return self._send(b"not found", "text/plain", 404)
            if os.path.getsize(full) > 32 * 1024 * 1024:
                return self._send(b"page image is implausibly large",
                                  "text/plain", 413)
            with open(full, "rb") as handle:
                mime = mimetypes.guess_type(full)[0] or "image/png"
                return self._send(handle.read(), mime, cache=True)
        if path == "/api/describe":
            return self._send(service.describe(query.get("id", [""])[0]).encode(),
                              "text/plain; charset=utf-8")
        if path == "/api/export.svg":
            namespace = query.get("ns", ["default"])[0]
            view = query.get("view", ["logical"])[0]
            system = query.get("system", ["0"])[0] == "1"
            graph = topology.build(service.shell.cluster,
                                   None if namespace == "*" else namespace, view,
                                   include_system=system)
            title = (f"{service.shell.cluster.name} - {view} view - "
                     f"namespace {namespace if namespace != '*' else 'all'} - "
                     f"tick {service.shell.cluster.tick}")
            return self._send(export.to_svg(graph, title).encode(),
                              "image/svg+xml")
        if path == "/api/log":
            return self._json({"log": service.log[-120:]})
        if path == "/api/progress":
            return self._json(service.load_progress())
        if path == "/api/dictionary":
            namespace = query.get("ns", ["*"])[0]
            system = query.get("system", ["0"])[0] == "1"
            entries = dictionary.build(service.shell.cluster,
                                       None if namespace == "*" else namespace, system)
            return self._json({"objects": entries, "tick": service.shell.cluster.tick})
        if path == "/api/dictionary.txt":
            namespace = query.get("ns", ["*"])[0]
            entries = dictionary.build(service.shell.cluster,
                                       None if namespace == "*" else namespace, True)
            body = dictionary.to_text(service.shell.cluster, entries)
            return self._send(body.encode(), "text/plain; charset=utf-8")
        if path == "/api/log.txt":
            return self._send(service.log_text().encode(),
                              "text/plain; charset=utf-8")
        if path == "/api/log.json":
            return self._send(json.dumps(service.log, indent=2).encode(),
                              "application/json; charset=utf-8")
        if path == "/api/run-all/status":
            return self._json(service.runner)
        if path == "/api/preview-command":
            name = query.get("lab", [""])[0]
            overrides = _clean_overrides(query)
            lab = lab_index.by_file(
                security.safe_name(name, security.LAB_FILE) or "") if name else None
            if name == "env.sh":
                body = portable.env_sh(overrides, query.get("flavour",
                                                           ["kubernetes"])[0])
            elif name == "lib.sh":
                body = portable.LIB_SH
            elif name == "run-all.sh":
                body = portable.run_all_sh(lab_index.available())
            elif lab is not None and lab.exists():
                body = portable.lab_script(lab, 1)
            else:
                body = "# pick a file on the left"
            return self._send(body.encode(), "text/plain; charset=utf-8")
        if path == "/api/variables":
            return self._json({"variables": [
                {"name": n, "default": d, "help": h}
                for n, d, h in portable.VARIABLES]})
        if path == "/api/labs-bundle.zip":
            if not HEAVY_LIMITER.allow(self._client()):
                return self._refuse(429, "too many bundle downloads; wait a moment")
            flavour = query.get("flavour", ["kubernetes"])[0]
            if flavour not in portable.FLAVOURS:
                flavour = "kubernetes"
            return self._zip(_bundle(flavour, service.shell.base_dir),
                             f"k8s-labs-{flavour}.zip")
        if path == "/api/commands.zip":
            if not HEAVY_LIMITER.allow(self._client()):
                return self._refuse(429, "too many bundle downloads; wait a moment")
            overrides = _clean_overrides(query)
            return self._zip(portable.build_bundle(overrides,
                                                   service.shell.base_dir),
                             "k8s-lab-commands.zip")
        if path == "/api/legend":
            return self._json({"sections": topology.legend_detail()})
        if path.startswith("/api/manifest/"):
            key = security.safe_name(
                path.rsplit("/", 1)[-1].removesuffix(".yaml"), security.TOPIC_KEY)
            topic = handbook.TOPICS.get(key) if key else None
            if topic is None:
                return self._send(b"unknown topic", "text/plain", 404)
            return self._send(handbook.manifest_for(topic).encode(),
                              "application/yaml; charset=utf-8",
                              filename=handbook.manifest_filename(topic))
        if path == "/api/manifests.zip":
            if not HEAVY_LIMITER.allow(self._client()):
                return self._refuse(429, "too many bundle downloads; wait a moment")
            import io
            import zipfile
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
                index_lines = ["# k8s-practice-lab -- exercise manifests", ""]
                for key in handbook.ORDER:
                    topic = handbook.TOPICS[key]
                    name = handbook.manifest_filename(topic)
                    archive.writestr(f"manifests/{name}", handbook.manifest_for(topic))
                    index_lines.append(
                        f"{name}\n    {topic.title} | {topic.section} | "
                        f"lab {topic.lab_number or '-'} | page {topic.pages[0]}")
                for lab in lab_index.LABS:
                    if lab.exists():
                        archive.writestr(f"scripts/{lab.file}", lab.read())
                archive.writestr("INDEX.txt", "\n".join(index_lines))
            return self._zip(buffer.getvalue(), "k8s-lab-exercises.zip")
        if path == "/api/export.html":
            namespace = query.get("ns", ["default"])[0]
            view = query.get("view", ["logical"])[0]
            system = query.get("system", ["0"])[0] == "1"
            graph = topology.build(service.shell.cluster,
                                   None if namespace == "*" else namespace, view,
                                   include_system=system)
            title = (f"{service.shell.cluster.name} - {view} view - namespace "
                     f"{namespace if namespace != '*' else 'all'} - tick "
                     f"{service.shell.cluster.tick}")
            return self._send(export.to_interactive_html(graph, title).encode(),
                              "text/html; charset=utf-8")
        if path == "/api/coverage":
            return self._json({"coverage": handbook.coverage(),
                               "not_covered": handbook.NOT_COVERED})
        return self._send(b"not found", "text/plain", 404)

    def do_POST(self) -> None:                                  # noqa: N802
        try:
            self._post()
        except Exception:                     # pragma: no cover - safety net
            import traceback
            traceback.print_exc(file=sys.stderr)
            self._refuse(500, "internal error -- see the lab's console output")

    def _post(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        refusal = self._authorised(path, parse_qs(parsed.query))
        if refusal:
            return self._refuse(403, refusal)
        payload = self._read_body()
        if payload is None:
            return self._refuse(
                400, "expected a JSON body of at most "
                     f"{security.MAX_REQUEST_BYTES // 1024} KiB "
                     "with Content-Type: application/json")
        service = self.service

        if path == "/api/run":
            command = str(payload.get("cmd", "")).strip()
            if not command:
                return self._json({"ok": True, "out": ""})
            return self._json(service.run(command,
                                          bool(payload.get("expect_error"))))
        if path == "/api/run-many":
            commands = payload.get("cmds", [])
            if not isinstance(commands, list):
                return self._refuse(400, "cmds must be a list")
            if len(commands) > security.MAX_COMMANDS_PER_BATCH:
                return self._refuse(
                    413, f"at most {security.MAX_COMMANDS_PER_BATCH} commands "
                         "per request")
            results = [service.run(str(c)) for c in commands]
            return self._json({"results": results})
        if path == "/api/run-all":
            if payload.get("stop"):
                service.runner["stop"] = True
                return self._json({"ok": True, "stopping": True})
            service.run_all(float(payload.get("pause", 0.25)),
                            reset_between=bool(payload.get("reset_between")),
                            mark_progress=payload.get("mark_progress", True))
            return self._json({"ok": True, "runner": service.runner})
        if path == "/api/tick":
            # A tick is a full reconcile pass over every controller, so the
            # count is clamped: `{"n": 10_000_000}` would otherwise be a
            # one-request denial of service (CWE-1284).
            try:
                ticks = max(1, min(500, int(payload.get("n", 1))))
            except (TypeError, ValueError):
                ticks = 1
            with STATE_LOCK:
                reconcile(service.shell.cluster, ticks)
            return self._json({"ok": True, "tick": service.shell.cluster.tick})
        if path == "/api/autotick":
            service.autotick = bool(payload.get("on", True))
            return self._json({"ok": True, "autotick": service.autotick})
        if path == "/api/namespace":
            name = str(payload.get("ns", "default"))
            if service.shell.cluster.get("Namespace", "", name):
                service.shell.cluster.current_namespace = name
            return self._json({"ok": True, "current":
                               service.shell.cluster.current_namespace})
        if path == "/api/progress":
            return self._json(service.save_progress(payload.get("done", []),
                                                    payload.get("notes")))
        if path == "/api/reset":
            scope = str(payload.get("scope", "cluster"))
            if scope in ("cluster", "all"):
                service.run("sim reset")
                service.log.clear()
            if scope in ("progress", "all"):
                service.save_progress([])
            return self._json({"ok": True, "scope": scope})
        if path == "/api/apply":
            body = str(payload.get("yaml", ""))
            if len(body) > security.MAX_YAML_BYTES:
                return self._json({"ok": False, "out":
                                   "manifest is larger than "
                                   f"{security.MAX_YAML_BYTES // 1024} KiB"})
            # The file name is generated, never taken from the request, and is
            # written with owner-only permissions inside the project directory.
            name = f".webui-buffer-{os.getpid()}-{threading.get_ident()}.yaml"
            temp = os.path.join(service.shell.base_dir, name)
            try:
                fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    handle.write(body)
            except OSError as exc:
                return self._json({"ok": False, "out": f"cannot write buffer: {exc}"})
            try:
                return self._json(service.run(f"kubectl apply -f {name}"))
            finally:
                try:
                    os.remove(temp)
                except OSError:
                    pass
        if path == "/api/docker":
            # The highest-privilege thing this app can do: talking to the Docker
            # socket is effectively root on the host. Loopback only, no matter
            # what --host was set to, and rate limited.
            if not security.is_loopback(self._client()):
                return self._json({"ok": False, "out":
                                   "Docker deployment can only be driven from "
                                   "the machine the lab is running on."}, 403)
            if not DOCKER_LIMITER.allow(self._client()):
                return self._json({"ok": False, "out":
                                   "too many Docker requests; wait a minute."}, 429)
            return self._json(docker_action(str(payload.get("action", "status")),
                                            self.port))
        return self._json({"error": "not found"}, 404)

    def do_HEAD(self) -> None:                                  # noqa: N802
        self.do_GET()

    def do_OPTIONS(self) -> None:                               # noqa: N802
        # No CORS headers are ever sent: there is no legitimate cross-origin
        # caller, and a permissive preflight response is what turns a local
        # tool into a remotely-drivable one (CWE-942).
        self._refuse(405, "method not allowed")

    def do_PUT(self) -> None:                                   # noqa: N802
        self._refuse(405, "method not allowed")

    do_DELETE = do_PUT
    do_PATCH = do_PUT


def _clean_overrides(query: Dict[str, List[str]]) -> Dict[str, str]:
    """Keep only known variable names, with sane values.

    These end up inside a generated shell script, so both the name and the value
    are constrained here, and `portable` quotes them again on the way out
    (defence in depth against CWE-78).
    """
    known = {name for name, _, _ in portable.VARIABLES}
    known |= {name for name, _, _ in portable.MINIKUBE_VARIABLES}
    out: Dict[str, str] = {}
    for key, values in query.items():
        if key in known and values:
            value = str(values[0])[:256]
            if "\n" not in value and "\x00" not in value:
                out[key] = value
    return out


# ---------------------------------------------------------------------------
def _free_port(preferred: int) -> int:
    for candidate in [preferred] + list(range(preferred + 1, preferred + 25)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            if sock.connect_ex(("127.0.0.1", candidate)) != 0:
                return candidate
    return preferred


def serve(shell: Shell, port: int = 8899, host: str = "127.0.0.1",
          background: bool = False, open_browser: bool = False,
          state_dir: Optional[str] = None, token: Optional[str] = None) -> str:
    """Start the UI.

    Defaults are the safe ones: loopback interface, fresh session token. Any
    other interface has to be asked for, and is refused unless the operator
    also sets K8SLAB_ALLOW_REMOTE=1 -- because on a shared network this port is
    a shell and a Docker build button (CWE-1327).
    """
    global _SERVER, _SERVER_URL
    port = _free_port(port)
    exposed = not security.is_loopback(host) and host not in ("", None)
    allow_remote = exposed and os.environ.get("K8SLAB_ALLOW_REMOTE") == "1"
    if exposed and not allow_remote and not IN_CONTAINER:
        print(f"\n  refusing to listen on {host}: this UI can run commands and\n"
              "  build container images, so it is loopback-only by default.\n"
              "  If you really want it on the network, put it behind something\n"
              "  that authenticates, and set K8SLAB_ALLOW_REMOTE=1.\n"
              "  Falling back to 127.0.0.1.\n", file=sys.stderr)
        host = "127.0.0.1"
        exposed = False
    if IN_CONTAINER:
        # Inside the container 0.0.0.0 is correct -- the isolation boundary is
        # the published port, which the compose file pins to loopback.
        allow_remote = True

    # A token per process. `K8SLAB_TOKEN=` (empty) disables it, which is what
    # the test-suite does; anything else is used as given.
    if token is None:
        token = os.environ.get("K8SLAB_TOKEN")
        token = security.new_token() if token is None else token

    handler = type("BoundHandler", (Handler,),
                   {"service": LabService(shell, state_dir), "port": port,
                    "token": token, "allow_remote": allow_remote})
    server = ThreadingHTTPServer((host, port), handler)
    server.daemon_threads = True
    _SERVER = server
    suffix = f"/?token={token}" if token else "/"
    _SERVER_URL = f"http://127.0.0.1:{port}{suffix}"
    if open_browser and not IN_CONTAINER:
        threading.Timer(0.8, lambda: _open(_SERVER_URL)).start()
    if background:
        threading.Thread(target=server.serve_forever, daemon=True).start()
        return _SERVER_URL
    print(f"\n  k8s-practice-lab web UI  ->  {_SERVER_URL}\n"
          "  that link contains this session's access token -- it changes\n"
          "  every time you start the lab, and is not valid anywhere else.\n"
          "  press Ctrl-C to stop\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")
    finally:
        server.shutdown()
    return _SERVER_URL


def _open(url: str) -> None:
    try:
        import webbrowser
        webbrowser.open(url)
    except Exception:
        pass


def ensure_server(shell: Shell, port: int = 8899) -> str:
    """Start the web UI in the background if it is not already running."""
    global _SERVER_URL
    if _SERVER is not None:
        return _SERVER_URL
    return serve(shell, port=port, background=True)


# ---------------------------------------------------------------------------
PAGE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "page.html")


def page_html(port: int, token: str = "", nonce: str = "") -> str:
    """The single-page app, with the port, token and CSP nonce substituted in.

    The token goes into the document the server itself just handed to the
    browser -- never into a URL another site could read, and never into a
    cookie, so it cannot be attached automatically to a forged request.
    """
    with open(PAGE_PATH, encoding="utf-8") as handle:
        page = handle.read()
    replacements = {
        "__PORT__": str(port),
        "__TOKEN__": json.dumps(token)[1:-1],   # JS-escaped, no quotes
        "__NONCE__": nonce,
    }
    import re as _re
    return _re.sub(r"__PORT__|__TOKEN__|__NONCE__",
                   lambda m: replacements[m.group(0)], page)
