"""The simulated kube-scheduler (handbook page 40).

Two phases, exactly like the real thing:

    1. Filtering  -- which nodes *can* run this pod?
       taints/tolerations, nodeSelector, node affinity, pod (anti)affinity,
       resource requests vs allocatable, node readiness.
    2. Scoring    -- of those, which node is *best*?  Least-allocated wins,
       with preferred affinity terms adding weight.

When filtering leaves nothing, the pod stays Pending and the reason is written
as an event -- which is what you practise reading in the troubleshooting lab.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from .model import Cluster, deep_get, match_labels, parse_cpu, parse_mem


def pod_requests(pod: dict) -> Tuple[float, float]:
    """Sum of container resource requests -> (millicores, MiB)."""
    cpu = mem = 0.0
    for container in deep_get(pod, "spec.containers", []) or []:
        req = deep_get(container, "resources.requests", {}) or {}
        cpu += parse_cpu(req.get("cpu", 0))
        mem += parse_mem(req.get("memory", 0))
    init_cpu = init_mem = 0.0
    for container in deep_get(pod, "spec.initContainers", []) or []:
        req = deep_get(container, "resources.requests", {}) or {}
        init_cpu = max(init_cpu, parse_cpu(req.get("cpu", 0)))
        init_mem = max(init_mem, parse_mem(req.get("memory", 0)))
    return max(cpu, init_cpu), max(mem, init_mem)


def node_allocatable(node: dict) -> Tuple[float, float]:
    alloc = deep_get(node, "status.allocatable", {}) or {}
    return parse_cpu(alloc.get("cpu", "4")), parse_mem(alloc.get("memory", "8Gi"))


def node_usage(cluster: Cluster, node_name: str,
               exclude: Optional[str] = None) -> Tuple[float, float]:
    cpu = mem = 0.0
    for pod in cluster.list("Pod"):
        if deep_get(pod, "spec.nodeName") != node_name:
            continue
        if deep_get(pod, "status.phase") in ("Succeeded", "Failed"):
            continue
        if exclude and deep_get(pod, "metadata.name") == exclude:
            continue
        pcpu, pmem = pod_requests(pod)
        cpu += pcpu
        mem += pmem
    return cpu, mem


def _tolerates(pod: dict, taint: dict) -> bool:
    for tol in deep_get(pod, "spec.tolerations", []) or []:
        op = tol.get("operator", "Equal")
        if tol.get("key") not in (None, "", taint.get("key")) and op != "Exists":
            continue
        if op == "Exists":
            if tol.get("key") in (None, "", taint.get("key")):
                if tol.get("effect") in (None, "", taint.get("effect")):
                    return True
            continue
        if str(tol.get("value")) == str(taint.get("value")) and \
                tol.get("effect") in (None, "", taint.get("effect")):
            return True
    return False


def _node_affinity_ok(pod: dict, node: dict) -> Tuple[bool, str]:
    required = deep_get(
        pod, "spec.affinity.nodeAffinity."
             "requiredDuringSchedulingIgnoredDuringExecution")
    if not required:
        return True, ""
    labels = deep_get(node, "metadata.labels", {}) or {}
    terms = required.get("nodeSelectorTerms") or []
    if not terms:
        return True, ""
    for term in terms:
        ok = True
        for expr in term.get("matchExpressions") or []:
            key, op = expr.get("key"), expr.get("operator", "In")
            values = [str(v) for v in expr.get("values") or []]
            have = labels.get(key)
            if op == "In" and str(have) not in values:
                ok = False
            elif op == "NotIn" and str(have) in values:
                ok = False
            elif op == "Exists" and key not in labels:
                ok = False
            elif op == "DoesNotExist" and key in labels:
                ok = False
            elif op == "Gt" and not (have is not None and float(have) > float(values[0])):
                ok = False
            elif op == "Lt" and not (have is not None and float(have) < float(values[0])):
                ok = False
            if not ok:
                break
        if ok:
            return True, ""
    return False, "node(s) didn't match Pod's node affinity/selector"


def _topology_value(node: dict, key: str) -> str:
    return str((deep_get(node, "metadata.labels", {}) or {}).get(key, ""))


def _pod_affinity_ok(cluster: Cluster, pod: dict, node: dict) -> Tuple[bool, str]:
    ns = deep_get(pod, "metadata.namespace", "default")
    running = [p for p in cluster.list("Pod", ns)
               if deep_get(p, "spec.nodeName") and
               deep_get(p, "metadata.name") != deep_get(pod, "metadata.name")]
    nodes_by_name = {deep_get(n, "metadata.name"): n for n in cluster.list("Node")}

    for kind in ("podAffinity", "podAntiAffinity"):
        terms = deep_get(pod, f"spec.affinity.{kind}."
                              "requiredDuringSchedulingIgnoredDuringExecution") or []
        for term in terms:
            topo_key = term.get("topologyKey", "kubernetes.io/hostname")
            selector = term.get("labelSelector") or {}
            here = _topology_value(node, topo_key)
            found = False
            for other in running:
                other_node = nodes_by_name.get(deep_get(other, "spec.nodeName"))
                if other_node is None:
                    continue
                if _topology_value(other_node, topo_key) != here:
                    continue
                if match_labels(deep_get(other, "metadata.labels", {}) or {}, selector):
                    found = True
                    break
            if kind == "podAffinity" and not found:
                return False, "node(s) didn't satisfy pod affinity rules"
            if kind == "podAntiAffinity" and found:
                return False, "node(s) didn't match pod anti-affinity rules"
    return True, ""


def filter_nodes(cluster: Cluster, pod: dict) -> Tuple[List[dict], Dict[str, str]]:
    """Return (feasible nodes, {node_name: rejection reason})."""
    feasible, reasons = [], {}
    req_cpu, req_mem = pod_requests(pod)
    selector = deep_get(pod, "spec.nodeSelector", {}) or {}
    pinned = deep_get(pod, "spec.nodeName")

    for node in cluster.list("Node"):
        name = deep_get(node, "metadata.name")
        if pinned and name != pinned:
            continue
        if deep_get(node, "status.ready", True) is False:
            reasons[name] = "node(s) were not ready"
            continue
        if deep_get(node, "spec.unschedulable", False):
            reasons[name] = "node(s) were unschedulable (cordoned)"
            continue
        labels = deep_get(node, "metadata.labels", {}) or {}
        if selector and not all(str(labels.get(k)) == str(v)
                                for k, v in selector.items()):
            reasons[name] = "node(s) didn't match Pod's nodeSelector"
            continue
        blocked = False
        for taint in deep_get(node, "spec.taints", []) or []:
            if taint.get("effect") == "PreferNoSchedule":
                continue
            if not _tolerates(pod, taint):
                reasons[name] = (f'node(s) had untolerated taint '
                                 f'{{{taint.get("key")}: {taint.get("value", "")}}}')
                blocked = True
                break
        if blocked:
            continue
        ok, why = _node_affinity_ok(pod, node)
        if not ok:
            reasons[name] = why
            continue
        ok, why = _pod_affinity_ok(cluster, pod, node)
        if not ok:
            reasons[name] = why
            continue
        cap_cpu, cap_mem = node_allocatable(node)
        used_cpu, used_mem = node_usage(cluster, name,
                                        exclude=deep_get(pod, "metadata.name"))
        if used_cpu + req_cpu > cap_cpu:
            reasons[name] = "Insufficient cpu"
            continue
        if used_mem + req_mem > cap_mem:
            reasons[name] = "Insufficient memory"
            continue
        feasible.append(node)
    return feasible, reasons


def score_nodes(cluster: Cluster, pod: dict, nodes: List[dict]) -> List[Tuple[int, dict]]:
    scored = []
    req_cpu, req_mem = pod_requests(pod)
    for node in nodes:
        name = deep_get(node, "metadata.name")
        cap_cpu, cap_mem = node_allocatable(node)
        used_cpu, used_mem = node_usage(cluster, name)
        cpu_free = (cap_cpu - used_cpu - req_cpu) / max(cap_cpu, 1)
        mem_free = (cap_mem - used_mem - req_mem) / max(cap_mem, 1)
        score = int((cpu_free + mem_free) / 2 * 100)          # LeastAllocated
        for pref in deep_get(pod, "spec.affinity.nodeAffinity."
                                  "preferredDuringSchedulingIgnoredDuringExecution",
                             []) or []:
            weight = int(pref.get("weight", 1))
            term = pref.get("preference", {})
            ok, _ = _node_affinity_ok({"spec": {"affinity": {"nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [term]}}}}}, node)
            if ok:
                score += weight
        for taint in deep_get(node, "spec.taints", []) or []:
            if taint.get("effect") == "PreferNoSchedule" and not _tolerates(pod, taint):
                score -= 50
        scored.append((score, node))
    scored.sort(key=lambda item: (-item[0], deep_get(item[1], "metadata.name")))
    return scored


def schedule_pod(cluster: Cluster, pod: dict) -> Optional[str]:
    """Bind a Pending pod to a node. Returns the node name or None."""
    name = deep_get(pod, "metadata.name")
    ns = deep_get(pod, "metadata.namespace", "default")
    feasible, reasons = filter_nodes(cluster, pod)
    if not feasible:
        total = len(cluster.list("Node"))
        summary: Dict[str, int] = {}
        for reason in reasons.values():
            summary[reason] = summary.get(reason, 0) + 1
        detail = ", ".join(f"{count} {reason}" for reason, count in summary.items()) \
            or "no nodes available"
        pod.setdefault("status", {})["phase"] = "Pending"
        pod["status"]["reason"] = "Unschedulable"
        pod["status"]["message"] = f"0/{total} nodes are available: {detail}."
        cluster.record("Warning", "FailedScheduling",
                       f"0/{total} nodes are available: {detail}.",
                       f"pod/{name}", ns)
        return None
    best = score_nodes(cluster, pod, feasible)[0][1]
    node_name = deep_get(best, "metadata.name")
    pod.setdefault("spec", {})["nodeName"] = node_name
    pod.setdefault("status", {})["phase"] = "Pending"
    pod["status"].pop("reason", None)
    pod["status"].pop("message", None)
    pod["status"]["scheduledTick"] = cluster.tick
    pod["status"]["hostIP"] = deep_get(best, "status.addresses.0.address", "10.0.0.1")
    cluster.record("Normal", "Scheduled",
                   f"Successfully assigned {ns}/{name} to {node_name}",
                   f"pod/{name}", ns)
    return node_name
