"""The kubectl / helm / kustomize command engine.

``Shell.run("kubectl get pods -o wide")`` parses the command, calls the
simulated API server and returns text exactly the way kubectl would print it.
Also implements ``helm``, ``kustomize``, and the lab-only ``sim`` verb used to
inject load and failures.
"""
from __future__ import annotations

import base64
import copy
import json
import os
import re
import shlex
import subprocess
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from . import admin, miniyaml, netpolicy, printers, security
from .apiserver import ApiError, Forbidden, apply, can_i, delete, scale
from .cluster_factory import add_node, build_cluster
from .controllers import REVISION_KEY, reconcile
from .model import (Cluster, annotation, deep_get, deep_set, fmt_age, fmt_cpu,
                    fmt_mem, label, match_labels, parse_cpu, parse_mem,
                    parse_selector_string, resolve_kind, REGISTRY)


EXPECT_ERROR_MARKER = "#!expect-error"


@dataclass
class Result:
    ok: bool
    out: str = ""
    err: str = ""
    objects_changed: bool = False
    topic: str = ""            # handbook topic to surface in the GUI
    expected: bool = False     # a deliberate teaching failure, not a real one

    @property
    def text(self) -> str:
        return self.out if self.ok else self.err


class ShellError(Exception):
    pass


# --------------------------------------------------------------------------
# flag parsing
# --------------------------------------------------------------------------
VALUE_FLAGS = {"-n", "--namespace", "-o", "--output", "-l", "--selector", "-f",
               "--filename", "-k", "--kustomize", "--image", "--replicas", "--port",
               "--target-port", "--type", "--as", "--from-literal", "--from-file",
               "--from-env-file", "--restart", "--schedule", "--cpu-percent", "--min",
               "--max", "--containers", "-c", "--to-revision", "--dry-run", "--sort-by",
               "--field-selector", "--node-port", "--target", "--values", "--set",
               "--tail", "--since", "--timeout", "--for", "--patch", "-p", "--revision",
               "--context", "--hard", "--verb", "--resource", "--role", "--clusterrole",
               "--user", "--serviceaccount", "--name", "--schedule",
               # cluster administration
               "--node", "--node-name", "--token", "--discovery-token-ca-cert-hash",
               "--data-dir", "--endpoints", "--cacert", "--cert", "--key",
               "--docker-server", "--docker-username", "--docker-password",
               "--docker-email", "--client-certificate", "--client-key",
               "--server", "--certificate-authority", "--cluster", "--group",
               "--tag", "--config", "--kubeconfig", "--signer", "--labels"}

BOOL_FLAGS = {"-A", "--all-namespaces", "--all", "-w", "--watch", "-it", "-i", "-t",
              "--force", "--now", "--ignore-not-found", "--show-labels", "--record",
              "--follow", "--previous", "--recursive", "-R", "--ignore-daemonsets",
              "--delete-emptydir-data", "--wide", "--no-headers", "--list", "--quiet",
              "--current", "--overwrite", "--command", "--server-side"}


def parse_flags(tokens: List[str]) -> Tuple[List[str], Dict[str, Any]]:
    args: List[str] = []
    flags: Dict[str, Any] = {}
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token.startswith("-") and token != "-":
            key, eq, inline = token.partition("=")
            if eq:
                _store(flags, key, inline)
            elif key in VALUE_FLAGS and i + 1 < len(tokens):
                _store(flags, key, tokens[i + 1])
                i += 1
            else:
                flags[key] = True
        else:
            args.append(token)
        i += 1
    return args, flags


def _store(flags: Dict[str, Any], key: str, value: str) -> None:
    if key in ("--from-literal", "--from-file", "--set", "--values"):
        flags.setdefault(key, []).append(value)
    else:
        flags[key] = value


def flag(flags: Dict[str, Any], *names, default=None):
    for name in names:
        if name in flags:
            return flags[name]
    return default


# --------------------------------------------------------------------------
# the shell
# --------------------------------------------------------------------------
class Shell:
    """Runs commands against either the simulator or a real cluster."""

    def __init__(self, cluster: Optional[Cluster] = None, base_dir: str = ".",
                 live: bool = False, auto_tick: int = 4,
                 extra_roots: Optional[List[str]] = None):
        self.cluster = cluster or build_cluster()
        self.base_dir = os.path.abspath(base_dir)
        self.live = live
        self.auto_tick = auto_tick
        self.history: List[str] = []
        self.last_topic = "introduction"
        #: Directories outside the project the shell may also touch. Empty by
        #: default -- least privilege. The web server adds its state directory.
        self.extra_roots: List[str] = [os.path.abspath(p)
                                       for p in (extra_roots or [])]

    # -- entry point ------------------------------------------------------
    def run(self, line: str) -> Result:
        line = line.strip()
        if not line or line.startswith("#"):
            return Result(True, "")
        # A single command line is bounded, so neither the tokenizer nor the
        # transcript can be used to exhaust memory (CWE-400).
        if len(line) > security.MAX_COMMAND_CHARS:
            return Result(False, err=f"command is longer than "
                                     f"{security.MAX_COMMAND_CHARS} characters")
        self.history.append(line)
        del self.history[:-2000]
        self.cluster.current_command = line
        try:
            tokens = shlex.split(line, comments=True)
        except ValueError as exc:
            return Result(False, err=f"parse error: {exc}")
        if not tokens:
            return Result(True, "")

        env: Dict[str, str] = {}
        while tokens and re.match(r"^[A-Z_][A-Z0-9_]*=", tokens[0]):
            key, _, value = tokens[0].partition("=")
            env[key] = value
            tokens = tokens[1:]
        if not tokens:
            return Result(True, "")
        program, rest = tokens[0], tokens[1:]
        if self.live and program in ("kubectl", "helm", "kustomize", "kubeadm",
                                     "etcdctl", "docker"):
            return self._run_live(tokens)

        handler = {
            "kubectl": self.kubectl,
            "k": self.kubectl,
            "helm": self.helm,
            "kustomize": self.kustomize,
            "kubeadm": self.kubeadm,
            "etcdctl": lambda a: self.etcdctl(a, env),
            "docker": self.docker,
            "sim": self.sim,
            "lab": self.sim,
            "echo": lambda a: Result(True, " ".join(a)),
            "sleep": lambda a: self._tick(int(float(a[0])) if a else 1),
            "clear": lambda a: Result(True, "\x1bCLEAR"),
            "help": lambda a: Result(True, HELP_TEXT),
        }.get(program)
        if handler is None:
            return Result(False, err=f"{program}: command not found. Try `help`.")
        try:
            result = handler(rest)
        except (ApiError, ShellError) as exc:
            return Result(False, err=f"error: {exc}")
        except Exception as exc:                     # pragma: no cover - safety net
            return Result(False, err=f"error: {type(exc).__name__}: {exc}")
        if result.objects_changed:
            reconcile(self.cluster, self.auto_tick)
        if result.topic:
            self.last_topic = result.topic
        return result

    def run_script(self, text: str, on_line=None) -> List[Tuple[str, Result]]:
        """Run a preloaded script; ``on_line(cmd, result)`` is called per command.

        A line reading ``#!expect-error`` marks the next command as a deliberate
        teaching failure, so the UI can show it in amber ("expected") instead of
        red ("something went wrong").
        """
        out = []
        expect = False
        for raw in text.splitlines():
            command = raw.strip()
            if command.startswith(EXPECT_ERROR_MARKER):
                expect = True
                continue
            if not command or command.startswith("#"):
                if on_line and command:
                    on_line(command, Result(True, ""))
                continue
            result = self.run(command)
            result.expected = expect and not result.ok
            expect = False
            out.append((command, result))
            if on_line:
                on_line(command, result)
        return out

    def _run_live(self, tokens: List[str]) -> Result:
        """Hand a command to the real OS. The only such path in the program.

        `tokens` is a list, never a string, and `shell=False` is the default --
        so there is no shell to inject into (CWE-78). On top of that the program
        and its flags are allowlisted, because `helm --post-renderer` and
        `kubectl --kubeconfig` are arbitrary-code-execution primitives dressed
        up as configuration.
        """
        refusal = security.live_command_refusal(tokens)
        if refusal:
            return Result(False, err=f"refused: {refusal}")
        try:
            proc = subprocess.run(tokens, capture_output=True, text=True,
                                  timeout=security.SUBPROCESS_TIMEOUT,
                                  cwd=self.base_dir, shell=False,
                                  stdin=subprocess.DEVNULL)
        except FileNotFoundError:
            return Result(False, err=f"{tokens[0]}: not found on PATH. Install it or "
                                     "drop --live to use the built-in simulator.")
        except subprocess.TimeoutExpired:
            return Result(False, err="command timed out after 60s")
        return Result(proc.returncode == 0, proc.stdout.rstrip(),
                      proc.stderr.rstrip(), objects_changed=True)

    def _tick(self, ticks: int = 1) -> Result:
        reconcile(self.cluster, ticks)
        return Result(True, f"advanced {ticks} control-loop tick(s) "
                            f"(cluster tick {self.cluster.tick})", objects_changed=False)

    # -- helpers ----------------------------------------------------------
    def ns(self, flags: Dict[str, Any]) -> str:
        return flag(flags, "-n", "--namespace", default=self.cluster.current_namespace)

    # -- sandboxed filesystem access -------------------------------------
    #
    # Everything below goes through security.safe_path, which keeps the shell
    # inside the project directory. Without it, `kubectl apply -f /etc/passwd`,
    # `--from-file=../../../.ssh/id_rsa` and `sim save /etc/cron.d/x` are an
    # arbitrary read and an arbitrary write -- reachable from the web UI by
    # anyone who can reach the port (CWE-22 / CWE-73).
    def _resolve(self, path: str, *, write: bool = False,
                 must_exist: bool = False) -> str:
        try:
            return security.safe_path(self.base_dir, path, write=write,
                                      must_exist=must_exist,
                                      extra_roots=self.extra_roots)
        except security.PathRefused as exc:
            raise ShellError(str(exc)) from None

    def _open_text(self, path: str, limit: int = security.MAX_YAML_BYTES) -> str:
        """Read a file we have already vetted, with a size ceiling (CWE-400)."""
        full = self._resolve(path, must_exist=True)
        if os.path.getsize(full) > limit:
            raise ShellError(f'"{path}" is larger than {limit // 1024} KiB; '
                             "the lab refuses to load it.")
        with open(full, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read(limit + 1)

    def _read_manifest(self, path: str, depth: int = 0) -> List[dict]:
        if depth > 8:                                # directory-recursion guard
            raise ShellError("manifest directories are nested too deeply")
        for prefix in ("", "manifests"):
            candidate = os.path.join(prefix, path) if prefix else path
            try:
                full = security.safe_path(self.base_dir, candidate,
                                          extra_roots=self.extra_roots)
            except security.PathRefused as exc:
                # An unsafe path is refused outright -- we do not fall through
                # to another candidate, because that would let a caller probe.
                raise ShellError(str(exc)) from None
            if os.path.isdir(full):
                docs = []
                for entry in sorted(os.listdir(full))[:512]:
                    if entry.endswith((".yaml", ".yml")):
                        docs.extend(self._read_manifest(
                            os.path.join(candidate, entry), depth + 1))
                return docs
            if os.path.isfile(full):
                return miniyaml.load_all(self._open_text(candidate))
        raise ShellError(f'the path "{path}" does not exist')

    # ------------------------------------------------------------------
    # kubectl
    # ------------------------------------------------------------------
    def kubectl(self, tokens: List[str]) -> Result:
        if not tokens:
            return Result(True, HELP_TEXT)
        verb, rest = tokens[0], tokens[1:]
        args, flags = parse_flags(rest)
        method = getattr(self, f"_kc_{verb.replace('-', '_')}", None)
        if method is None:
            return Result(False, err=f'unknown command "{verb}" for "kubectl". '
                                     "Run `help` for the supported verbs.")
        impersonating = "--as" in flags
        previous_user = self.cluster.current_user
        if impersonating:
            self.cluster.current_user = flags["--as"]
        try:
            return method(args, flags)
        finally:
            # --as is per-command; anything else (config use-context) may keep it
            if impersonating:
                self.cluster.current_user = previous_user

    # -- get / describe ---------------------------------------------------
    def _resolve_target(self, args: List[str]) -> Tuple[Optional[Any], Optional[str]]:
        """``pods`` / ``pod web`` / ``pod/web`` -> (ResourceKind, name)."""
        if not args:
            return None, None
        first = args[0]
        if "/" in first:
            kind_part, _, name = first.partition("/")
            return resolve_kind(kind_part), name
        rk = resolve_kind(first)
        name = args[1] if len(args) > 1 else None
        return rk, name

    def _kc_get(self, args, flags) -> Result:
        if not args:
            return Result(False, err="You must specify the type of resource to get.")
        if args[0] in ("all",):
            args = ["deployments,replicasets,pods,services"]
        if str(args[0]).lower() in ("event", "events", "ev"):
            return self._kc_events(args[1:], flags)
        all_ns = bool(flag(flags, "-A", "--all-namespaces"))
        namespace = None if all_ns else self.ns(flags)
        output = flag(flags, "-o", "--output", default="")
        wide = output == "wide" or bool(flags.get("--wide"))
        selector = flag(flags, "-l", "--selector")
        chunks, topics = [], []

        for spec in str(args[0]).split(","):
            rk, name = self._resolve_target([spec] + args[1:])
            if rk is None:
                return Result(False, err=f'the server doesn\'t have a resource type '
                                         f'"{spec}"')
            topics.append(rk.topic)
            ns_for_kind = namespace if rk.namespaced else None
            if not can_i(self.cluster, "list", rk.plural, ns_for_kind or "default"):
                return Result(False, err=f'Error from server (Forbidden): '
                                         f'{rk.plural} is forbidden: User '
                                         f'"{self.cluster.current_user}" cannot list '
                                         f'resource "{rk.plural}"')
            objs = self.cluster.list(rk.kind, ns_for_kind,
                                     parse_selector_string(selector) if selector else None)
            if name:
                objs = [o for o in objs if deep_get(o, "metadata.name") == name]
                if not objs:
                    return Result(False, err=f'Error from server (NotFound): '
                                             f'{rk.plural} "{name}" not found')
            if output in ("yaml", "json"):
                payload = objs[0] if (name and objs) else {
                    "apiVersion": "v1", "kind": "List", "items": objs}
                chunks.append(printers.to_output(payload, output))
                continue
            if not objs:
                scope = "" if all_ns else f" in namespace \"{namespace}\""
                chunks.append(f"No resources found{scope}.")
                continue
            if rk.kind == "Pod":
                chunks.append(printers.print_pods(self.cluster, objs, wide, all_ns))
            else:
                chunks.append(printers.print_generic(self.cluster, rk.kind, objs,
                                                     wide, all_ns))
            if flags.get("--show-labels"):
                chunks[-1] += "\n" + printers.table(
                    ["NAME", "LABELS"],
                    [[deep_get(o, "metadata.name"),
                      ",".join(f"{k}={v}" for k, v in
                               (deep_get(o, "metadata.labels", {}) or {}).items())]
                     for o in objs])
        return Result(True, "\n\n".join(c for c in chunks if c),
                      topic=topics[0] if topics else "")

    def _kc_describe(self, args, flags) -> Result:
        rk, name = self._resolve_target(args)
        if rk is None:
            return Result(False, err="You must specify the type of resource to describe.")
        namespace = self.ns(flags) if rk.namespaced else ""
        objs = self.cluster.list(rk.kind, namespace or None)
        if name:
            objs = [o for o in objs if deep_get(o, "metadata.name") == name]
            if not objs:
                return Result(False, err=f'Error from server (NotFound): '
                                         f'{rk.plural} "{name}" not found')
        if not objs:
            return Result(True, "No resources found.")
        return Result(True, "\n\n\n".join(printers.describe(self.cluster, o)
                                          for o in objs[:8]), topic=rk.topic)

    def _kc_explain(self, args, flags) -> Result:
        from .handbook import TOPICS, search
        rk, _ = self._resolve_target(args)
        if rk is None:
            # not a resource kind -- treat it as a handbook topic
            query = " ".join(args)
            topic = TOPICS.get(query.lower().replace(" ", "-"))
            if topic is None:
                hits = search(query)
                topic = hits[0] if hits else None
            if topic is None:
                return Result(False, err=f'no resource or handbook topic matches '
                                         f'"{query}"')
            body = [f"TOPIC:    {topic.title}",
                    f"HANDBOOK: page {topic.pages[0]}", "", "DESCRIPTION:",
                    "     " + topic.summary.replace("\n", "\n     "), "",
                    "KEY POINTS:"]
            body += [f"   * {point}" for point in topic.bullets]
            if topic.commands:
                body += ["", "COMMANDS TO TRY:"] + \
                        [f"   $ {c}" for c in topic.commands]
            return Result(True, "\n".join(body), topic=topic.key)
        topic = TOPICS.get(rk.topic)
        body = [f"KIND:     {rk.kind}", f"VERSION:  {rk.api_version}", "",
                "DESCRIPTION:"]
        if topic:
            body.append("     " + topic.summary.replace("\n", "\n     "))
            body.append("")
            body.append("FIELDS / KEY POINTS:")
            for point in topic.bullets:
                body.append(f"   * {point}")
            body.append("")
            body.append(f"HANDBOOK: page {topic.pages[0]}")
        return Result(True, "\n".join(body), topic=rk.topic)

    # -- apply / create / delete -----------------------------------------
    def _kc_apply(self, args, flags) -> Result:
        if "-k" in flags or "--kustomize" in flags:
            return self.kustomize(["build", flag(flags, "-k", "--kustomize")],
                                  apply_after=True, flags=flags)
        path = flag(flags, "-f", "--filename")
        if not path:
            return Result(False, err="error: must specify -f FILENAME or -k DIR")
        docs = self._read_manifest(path)
        dry = str(flag(flags, "--dry-run", default="none")) not in ("none", "false")
        lines, topics = [], []
        for doc in docs:
            if flags.get("-n") or flags.get("--namespace"):
                rk = resolve_kind(doc.get("kind", ""))
                if rk and rk.namespaced:
                    doc.setdefault("metadata", {})["namespace"] = self.ns(flags)
            lines.append(apply(self.cluster, doc, dry_run=dry))
            rk = resolve_kind(doc.get("kind", ""))
            if rk:
                topics.append(rk.topic)
        if not lines:
            return Result(True, "no objects in this file -- it is a comment-only "
                                "starter. Switch this tab to Script, or write a "
                                "manifest under the header.")
        return Result(True, "\n".join(lines), objects_changed=not dry,
                      topic=topics[0] if topics else "")

    def _kc_create(self, args, flags) -> Result:
        if flag(flags, "-f", "--filename"):
            return self._kc_apply(args, flags)
        if not args:
            return Result(False, err="You must specify a resource type to create.")
        kind_word = args[0].lower()
        name = args[1] if len(args) > 1 else None
        namespace = self.ns(flags)

        if kind_word in ("namespace", "ns"):
            obj = {"apiVersion": "v1", "kind": "Namespace",
                   "metadata": {"name": name}, "spec": {}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="namespaces")
        if kind_word in ("configmap", "cm"):
            data = {}
            for literal in flags.get("--from-literal", []):
                key, _, value = literal.partition("=")
                data[key] = value
            for filename in flags.get("--from-file", []):
                key, _, path = filename.partition("=")
                path = path or filename
                try:
                    # 64 KiB is far more than a ConfigMap should hold and keeps
                    # `--from-file` from being a way to slurp a large file.
                    data[key or os.path.basename(path)] = self._open_text(
                        path, limit=64 * 1024)
                except (ShellError, OSError) as exc:
                    data[key or os.path.basename(path)] = f"<{exc}>"
            obj = {"apiVersion": "v1", "kind": "ConfigMap",
                   "metadata": {"name": name, "namespace": namespace}, "data": data,
                   "spec": {}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="configmaps")
        if kind_word == "secret":
            sub = args[1] if len(args) > 2 else "generic"
            name = args[2] if len(args) > 2 else args[1]
            data = {}
            for literal in flags.get("--from-literal", []):
                key, _, value = literal.partition("=")
                data[key] = base64.b64encode(value.encode()).decode()
            secret_type = "Opaque"
            if sub in ("docker-registry",):
                secret_type = "kubernetes.io/dockerconfigjson"
                server = flag(flags, "--docker-server", default="registry.lab")
                user = flag(flags, "--docker-username", default="user")
                password = flag(flags, "--docker-password", default="")
                blob = json.dumps({"auths": {server: {"username": user,
                                                      "password": password}}})
                data[".dockerconfigjson"] = base64.b64encode(blob.encode()).decode()
            elif sub == "tls":
                secret_type = "kubernetes.io/tls"
            obj = {"apiVersion": "v1", "kind": "Secret",
                   "metadata": {"name": name, "namespace": namespace},
                   "type": secret_type, "data": data,
                   "spec": {}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="configmaps")
        if kind_word in ("serviceaccount", "sa"):
            obj = {"apiVersion": "v1", "kind": "ServiceAccount",
                   "metadata": {"name": name, "namespace": namespace}, "spec": {}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="service-accounts")
        if kind_word == "deployment":
            image = flag(flags, "--image", default="nginx:1.25")
            replicas = int(flag(flags, "--replicas", default=1))
            obj = _deployment_object(name, namespace, image, replicas)
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="deployments")
        if kind_word == "job":
            image = flag(flags, "--image", default="busybox:1.36")
            obj = {"apiVersion": "batch/v1", "kind": "Job",
                   "metadata": {"name": name, "namespace": namespace},
                   "spec": {"template": {"metadata": {"labels": {"job-name": name}},
                                         "spec": {"restartPolicy": "Never",
                                                  "containers": [
                                                      {"name": name, "image": image}]}}}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="jobs")
        if kind_word == "cronjob":
            image = flag(flags, "--image", default="busybox:1.36")
            schedule = flag(flags, "--schedule", default="*/1 * * * *")
            obj = {"apiVersion": "batch/v1", "kind": "CronJob",
                   "metadata": {"name": name, "namespace": namespace},
                   "spec": {"schedule": schedule,
                            "jobTemplate": {"spec": {"template": {
                                "metadata": {"labels": {"cronjob": name}},
                                "spec": {"restartPolicy": "OnFailure",
                                         "containers": [{"name": name,
                                                         "image": image}]}}}}}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="cronjobs")
        if kind_word in ("quota", "resourcequota"):
            hard = {}
            for literal in str(flag(flags, "--hard", default="")).split(","):
                if "=" in literal:
                    key, _, value = literal.partition("=")
                    hard[key] = value
            obj = {"apiVersion": "v1", "kind": "ResourceQuota",
                   "metadata": {"name": name, "namespace": namespace},
                   "spec": {"hard": hard}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="namespaces")
        if kind_word in ("csr", "certificatesigningrequest"):
            user = flag(flags, "--user", default=name)
            groups = [g for g in str(flag(flags, "--group", default="")).split(",") if g]
            obj = admin.make_csr(self.cluster, name, user, groups)
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="certificates")
        if kind_word in ("role", "clusterrole"):
            verbs = str(flag(flags, "--verb", default="get,list,watch")).split(",")
            resources = str(flag(flags, "--resource", default="pods")).split(",")
            kind = "Role" if kind_word == "role" else "ClusterRole"
            obj = {"apiVersion": "rbac.authorization.k8s.io/v1", "kind": kind,
                   "metadata": {"name": name,
                                **({"namespace": namespace} if kind == "Role" else {})},
                   "rules": [{"apiGroups": [""], "resources": resources,
                              "verbs": verbs}], "spec": {}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="rbac")
        if kind_word in ("rolebinding", "clusterrolebinding"):
            kind = "RoleBinding" if kind_word == "rolebinding" else "ClusterRoleBinding"
            role_ref = flag(flags, "--role") or flag(flags, "--clusterrole")
            subjects = []
            for user in str(flag(flags, "--user", default="")).split(","):
                if user:
                    subjects.append({"kind": "User", "name": user,
                                     "apiGroup": "rbac.authorization.k8s.io"})
            for sa in str(flag(flags, "--serviceaccount", default="")).split(","):
                if sa:
                    sa_ns, _, sa_name = sa.partition(":")
                    subjects.append({"kind": "ServiceAccount", "name": sa_name or sa_ns,
                                     "namespace": sa_ns if sa_name else namespace})
            obj = {"apiVersion": "rbac.authorization.k8s.io/v1", "kind": kind,
                   "metadata": {"name": name, **({"namespace": namespace}
                                                 if kind == "RoleBinding" else {})},
                   "roleRef": {"kind": "ClusterRole" if flag(flags, "--clusterrole")
                               else "Role", "name": role_ref,
                               "apiGroup": "rbac.authorization.k8s.io"},
                   "subjects": subjects, "spec": {}}
            return Result(True, apply(self.cluster, obj), objects_changed=True,
                          topic="rbac")
        return Result(False, err=f'unknown resource type "{kind_word}" for create')

    def _kc_run(self, args, flags) -> Result:
        if not args:
            return Result(False, err="You must specify a name for the pod.")
        name = args[0]
        image = flag(flags, "--image", default="nginx:1.25")
        namespace = self.ns(flags)
        labels = {"run": name}
        for pair in str(flag(flags, "--labels", "-l", default="")).split(","):
            if "=" in pair:
                key, _, value = pair.partition("=")
                labels[key.strip()] = value.strip()
        pod = {"apiVersion": "v1", "kind": "Pod",
               "metadata": {"name": name, "namespace": namespace, "labels": labels},
               "spec": {"containers": [{"name": name, "image": image}]}}
        if flag(flags, "--port"):
            pod["spec"]["containers"][0]["ports"] = [
                {"containerPort": int(flag(flags, "--port"))}]
        if flag(flags, "--restart") == "Never":
            pod["spec"]["restartPolicy"] = "Never"
        for secret in str(flag(flags, "--image-pull-secret", default="")).split(","):
            if secret:
                pod["spec"].setdefault("imagePullSecrets", []).append({"name": secret})
        return Result(True, apply(self.cluster, pod), objects_changed=True, topic="pods")

    def _kc_delete(self, args, flags) -> Result:
        if flag(flags, "-f", "--filename"):
            docs = self._read_manifest(flag(flags, "-f", "--filename"))
            lines = []
            for doc in docs:
                rk = resolve_kind(doc.get("kind", ""))
                if rk is None:
                    continue
                namespace = deep_get(doc, "metadata.namespace") or self.ns(flags)
                try:
                    lines.append(delete(self.cluster, rk.kind, namespace,
                                        deep_get(doc, "metadata.name")))
                except ApiError as exc:
                    if not flags.get("--ignore-not-found"):
                        lines.append(f"error: {exc}")
            return Result(True, "\n".join(lines), objects_changed=True)

        rk, name = self._resolve_target(args)
        if rk is None:
            return Result(False, err="You must specify the type of resource to delete.")
        namespace = self.ns(flags) if rk.namespaced else ""
        targets = []
        if flags.get("--all"):
            targets = [deep_get(o, "metadata.name")
                       for o in self.cluster.list(rk.kind, namespace or None)]
        elif flag(flags, "-l", "--selector"):
            selector = parse_selector_string(flag(flags, "-l", "--selector"))
            targets = [deep_get(o, "metadata.name")
                       for o in self.cluster.list(rk.kind, namespace or None, selector)]
        elif name:
            targets = [name] + [a for a in args[2:]]
        else:
            return Result(False, err="resource name, --all or -l is required")
        lines = []
        for target in targets:
            try:
                lines.append(delete(self.cluster, rk.kind, namespace, target))
            except ApiError as exc:
                if flags.get("--ignore-not-found"):
                    continue
                lines.append(f"error: {exc}")
        return Result(True, "\n".join(lines) or "No resources found",
                      objects_changed=True, topic=rk.topic)

    # -- workload operations ---------------------------------------------
    def _kc_scale(self, args, flags) -> Result:
        rk, name = self._resolve_target(args)
        replicas = flag(flags, "--replicas")
        if replicas is None:
            return Result(False, err="error: --replicas is required")
        if rk is None:
            return Result(False, err="You must specify a resource to scale.")
        return Result(True, scale(self.cluster, rk.kind, self.ns(flags), name,
                                  int(replicas)), objects_changed=True, topic=rk.topic)

    def _kc_autoscale(self, args, flags) -> Result:
        rk, name = self._resolve_target(args)
        if rk is None:
            return Result(False, err="You must specify a resource to autoscale.")
        namespace = self.ns(flags)
        hpa = {"apiVersion": "autoscaling/v2", "kind": "HorizontalPodAutoscaler",
               "metadata": {"name": name, "namespace": namespace},
               "spec": {"scaleTargetRef": {"apiVersion": "apps/v1", "kind": rk.kind,
                                           "name": name},
                        "minReplicas": int(flag(flags, "--min", default=1)),
                        "maxReplicas": int(flag(flags, "--max", default=10)),
                        "metrics": [{"type": "Resource",
                                     "resource": {"name": "cpu", "target": {
                                         "type": "Utilization",
                                         "averageUtilization": int(
                                             flag(flags, "--cpu-percent",
                                                  default=80))}}}]}}
        return Result(True, apply(self.cluster, hpa), objects_changed=True, topic="hpa")

    def _kc_expose(self, args, flags) -> Result:
        rk, name = self._resolve_target(args)
        if rk is None:
            return Result(False, err="You must specify a resource to expose.")
        namespace = self.ns(flags)
        obj = self.cluster.get(rk.kind, namespace, name)
        if obj is None:
            return Result(False, err=f'{rk.plural} "{name}" not found')
        if rk.kind == "Pod":
            selector = deep_get(obj, "metadata.labels", {}) or {}
        else:
            selector = deep_get(obj, "spec.selector.matchLabels", {}) or {}
        port = int(flag(flags, "--port", default=80))
        target_port = flag(flags, "--target-port", default=port)
        svc_name = flag(flags, "--name", default=name)
        svc = {"apiVersion": "v1", "kind": "Service",
               "metadata": {"name": svc_name, "namespace": namespace,
                            "labels": dict(selector)},
               "spec": {"type": flag(flags, "--type", default="ClusterIP"),
                        "selector": dict(selector),
                        "ports": [{"port": port, "targetPort": int(target_port),
                                   "protocol": "TCP"}]}}
        return Result(True, apply(self.cluster, svc), objects_changed=True,
                      topic="services")

    def _kc_set(self, args, flags) -> Result:
        if not args or args[0] != "image":
            return Result(False, err="only `kubectl set image` is supported")
        rk, name = self._resolve_target(args[1:2])
        namespace = self.ns(flags)
        obj = self.cluster.get(rk.kind if rk else "Deployment", namespace, name)
        if obj is None:
            return Result(False, err=f'resource "{name}" not found')
        changed = False
        for pair in args[2:]:
            container_name, _, image = pair.partition("=")
            containers = deep_get(obj, "spec.template.spec.containers", []) or []
            for container in containers:
                if container.get("name") == container_name or container_name == "*":
                    container["image"] = image
                    changed = True
        if changed:
            obj.setdefault("metadata", {}).setdefault("annotations", {})[
                "kubernetes.io/change-cause"] = f"kubectl set image {' '.join(args[2:])}"
            self.cluster.record("Normal", "RollingUpdate",
                                f"Rolling update started for {name}",
                                f"{obj['kind'].lower()}/{name}", namespace)
        return Result(True, f"{obj['kind'].lower()}/{name} image updated" if changed
                      else "no container matched", objects_changed=True,
                      topic="deployments")

    def _kc_rollout(self, args, flags) -> Result:
        if not args:
            return Result(False, err="usage: kubectl rollout [status|history|undo|restart]")
        action = args[0]
        rk, name = self._resolve_target(args[1:])
        namespace = self.ns(flags)
        if rk is None or name is None:
            return Result(False, err="usage: kubectl rollout %s deployment/<name>" % action)
        obj = self.cluster.get(rk.kind, namespace, name)
        if obj is None:
            return Result(False, err=f'{rk.plural} "{name}" not found')

        if action == "status":
            reconcile(self.cluster, 12)
            ready = deep_get(obj, "status.readyReplicas", 0)
            desired = deep_get(obj, "spec.replicas", 1)
            if ready >= desired:
                return Result(True, f'deployment "{name}" successfully rolled out',
                              topic="deployments")
            return Result(True, f"Waiting for deployment \"{name}\" rollout to finish: "
                                f"{ready} of {desired} updated replicas are available...",
                          topic="deployments")
        if action == "history":
            from .controllers import _owned_pods_rs
            rows = []
            for rs in _owned_pods_rs(self.cluster, name, namespace):
                revision = annotation(rs, REVISION_KEY, "1")
                cause = (deep_get(rs, "spec.template.metadata.annotations", {}) or {}
                         ).get("kubernetes.io/change-cause", "<none>")
                images = ",".join(c.get("image", "") for c in
                                  deep_get(rs, "spec.template.spec.containers", []) or [])
                rows.append([revision, images, cause])
            return Result(True, f"deployment.apps/{name}\n" +
                          printers.table(["REVISION", "IMAGES", "CHANGE-CAUSE"], rows),
                          topic="deployments")
        if action == "undo":
            from .controllers import _owned_pods_rs
            sets = _owned_pods_rs(self.cluster, name, namespace)
            if len(sets) < 2:
                return Result(False, err=f'deployment "{name}" has no rollout history')
            target_rev = flag(flags, "--to-revision")
            previous = sets[-2]
            if target_rev:
                for rs in sets:
                    if str(annotation(rs, REVISION_KEY)) == str(target_rev):
                        previous = rs
            template = copy.deepcopy(deep_get(previous, "spec.template", {}))
            deep_get(template, "metadata.labels", {}).pop("pod-template-hash", None)
            obj["spec"]["template"] = template
            self.cluster.record("Normal", "RollbackDone",
                                f"Rolled back deployment {name}",
                                f"deployment/{name}", namespace)
            return Result(True, f"deployment.apps/{name} rolled back",
                          objects_changed=True, topic="deployments")
        if action == "restart":
            annotations = obj.setdefault("spec", {}).setdefault("template", {}) \
                .setdefault("metadata", {}).setdefault("annotations", {})
            annotations["kubectl.kubernetes.io/restartedAt"] = str(self.cluster.tick)
            return Result(True, f"deployment.apps/{name} restarted",
                          objects_changed=True, topic="deployments")
        return Result(False, err=f"unknown rollout action {action}")

    # -- metadata ---------------------------------------------------------
    def _kc_label(self, args, flags) -> Result:
        return self._meta_edit(args, flags, "labels")

    def _kc_annotate(self, args, flags) -> Result:
        return self._meta_edit(args, flags, "annotations")

    def _meta_edit(self, args, flags, section: str) -> Result:
        rk, name = self._resolve_target(args)
        if rk is None or not name:
            return Result(False, err=f"usage: kubectl {section[:-1]} <type> <name> k=v")
        namespace = self.ns(flags) if rk.namespaced else ""
        obj = self.cluster.get(rk.kind, namespace, name)
        if obj is None:
            return Result(False, err=f'{rk.plural} "{name}" not found')
        target = obj.setdefault("metadata", {}).setdefault(section, {})
        first = 1 if "/" in args[0] else 2       # `deploy/web k=v` vs `deploy web k=v`
        pairs = [a for a in args[first:] if "=" in a or a.endswith("-")]
        if not pairs:
            return Result(False, err="at least one key=value pair is required")
        for pair in pairs:
            if pair.endswith("-"):
                target.pop(pair[:-1], None)
            elif "=" in pair:
                key, _, value = pair.partition("=")
                if key in target and not flags.get("--overwrite"):
                    return Result(False, err=f"error: '{key}' already has a value "
                                             f"({target[key]}), and --overwrite is false")
                target[key] = value
        return Result(True, f"{rk.kind.lower()}/{name} {section[:-1]}ed",
                      objects_changed=True,
                      topic="labels" if section == "labels" else "annotations")

    def _kc_taint(self, args, flags) -> Result:
        if len(args) < 2:
            return Result(False, err="usage: kubectl taint nodes <node> key=value:Effect")
        node = self.cluster.get("Node", "", args[1])
        if node is None:
            return Result(False, err=f'nodes "{args[1]}" not found')
        taints = node.setdefault("spec", {}).setdefault("taints", [])
        for spec in args[2:]:
            if spec.endswith("-"):
                key = spec[:-1].split("=")[0].split(":")[0]
                node["spec"]["taints"] = [t for t in taints if t.get("key") != key]
                continue
            key_value, _, effect = spec.partition(":")
            key, _, value = key_value.partition("=")
            taints = [t for t in taints if t.get("key") != key]
            taints.append({"key": key, "value": value, "effect": effect or "NoSchedule"})
            node["spec"]["taints"] = taints
        _evict_untolerated(self.cluster)
        return Result(True, f"node/{args[1]} tainted", objects_changed=True,
                      topic="taints")

    def _kc_cordon(self, args, flags) -> Result:
        return self._node_flag(args, True, "cordoned")

    def _kc_uncordon(self, args, flags) -> Result:
        return self._node_flag(args, False, "uncordoned")

    def _node_flag(self, args, value: bool, word: str) -> Result:
        if not args:
            return Result(False, err="usage: kubectl cordon <node>")
        name = args[-1]
        node = self.cluster.get("Node", "", name)
        if node is None:
            return Result(False, err=f'nodes "{name}" not found')
        node.setdefault("spec", {})["unschedulable"] = value
        return Result(True, f"node/{name} {word}", objects_changed=True,
                      topic="architecture")

    def _kc_drain(self, args, flags) -> Result:
        if not args:
            return Result(False, err="usage: kubectl drain <node>")
        name = args[-1]
        node = self.cluster.get("Node", "", name)
        if node is None:
            return Result(False, err=f'nodes "{name}" not found')
        node.setdefault("spec", {})["unschedulable"] = True
        evicted = []
        for pod in list(self.cluster.list("Pod")):
            if deep_get(pod, "spec.nodeName") != name:
                continue
            owners = [o.get("kind") for o in
                      deep_get(pod, "metadata.ownerReferences", []) or []]
            if "DaemonSet" in owners and not flags.get("--ignore-daemonsets"):
                return Result(False, err="cannot delete DaemonSet-managed Pods "
                                         "(use --ignore-daemonsets)")
            if "DaemonSet" in owners:
                continue
            self.cluster.delete("Pod", deep_get(pod, "metadata.namespace"),
                                deep_get(pod, "metadata.name"))
            evicted.append(deep_get(pod, "metadata.name"))
        return Result(True, f"node/{name} cordoned\n" +
                      "\n".join(f"evicting pod {e}" for e in evicted) +
                      f"\nnode/{name} drained", objects_changed=True,
                      topic="architecture")

    def _kc_patch(self, args, flags) -> Result:
        rk, name = self._resolve_target(args)
        patch_text = flag(flags, "-p", "--patch", default="{}")
        if rk is None or not name:
            return Result(False, err="usage: kubectl patch <type> <name> -p '<json>'")
        namespace = self.ns(flags) if rk.namespaced else ""
        obj = self.cluster.get(rk.kind, namespace, name)
        if obj is None:
            return Result(False, err=f'{rk.plural} "{name}" not found')
        try:
            patch = json.loads(patch_text)
        except json.JSONDecodeError:
            patch = miniyaml.load(patch_text) or {}
        _merge(obj, patch)
        return Result(True, f"{rk.kind.lower()}/{name} patched", objects_changed=True,
                      topic=rk.topic)

    # -- diagnostics ------------------------------------------------------
    def _kc_logs(self, args, flags) -> Result:
        rk, name = self._resolve_target(args)
        namespace = self.ns(flags)
        selector = flag(flags, "-l", "--selector")
        if selector:
            pods = self.cluster.list("Pod", namespace,
                                     parse_selector_string(selector))
            if not pods:
                return Result(False, err=f"No resources found matching -l {selector}")
            chunks = []
            for pod in pods[:6]:
                header = f"==> {deep_get(pod, 'metadata.name')} <=="
                chunks.append(header + "\n" + _fake_logs(self.cluster, pod))
            return Result(True, "\n\n".join(chunks), topic="logging")
        if name is None and args:
            name = args[0]
        pod = self.cluster.get("Pod", namespace, name)
        if pod is None:
            candidates = [p for p in self.cluster.list("Pod", namespace)
                          if str(deep_get(p, "metadata.name", "")).startswith(str(name))]
            if not candidates and rk is not None and name:
                candidates = [p for p in self.cluster.list("Pod", namespace)
                              if any(o.get("name") == name for o in
                                     deep_get(p, "metadata.ownerReferences", []) or [])
                              or label(p, "job-name") == name]
            pod = candidates[0] if candidates else None
        if pod is None:
            return Result(False, err=f'pods "{name}" not found')
        return Result(True, _fake_logs(self.cluster, pod), topic="troubleshooting")

    def _kc_exec(self, args, flags) -> Result:
        namespace = self.ns(flags)
        name = args[0] if args else ""
        pod = self.cluster.get("Pod", namespace, name)
        if pod is None:
            return Result(False, err=f'pods "{name}" not found')
        if deep_get(pod, "status.phase") != "Running":
            return Result(False, err=f'cannot exec into a container in a '
                                     f'{printers.pod_status(pod)} pod')
        command = args[1:]
        if "--" in command:
            command = command[command.index("--") + 1:]
        output = _fake_exec(self.cluster, pod, command)
        failed = any(marker in output for marker in
                     ("curl: (", "NXDOMAIN", "No such file or directory",
                      "wget: "))
        if failed:
            return Result(False, err=output, topic="network-policies"
                          if "NetworkPolicy" in output else "troubleshooting")
        return Result(True, output, topic="troubleshooting")

    def _kc_top(self, args, flags) -> Result:
        what = (args[0] if args else "pods").lower()
        if what.startswith("node"):
            rows = []
            for node in self.cluster.list("Node"):
                usage = deep_get(node, "status.usage", {}) or {}
                rows.append([deep_get(node, "metadata.name"),
                             fmt_cpu(usage.get("cpu", 0)), f"{usage.get('cpuPct', 0)}%",
                             fmt_mem(usage.get("memory", 0)),
                             f"{usage.get('memPct', 0)}%"])
            return Result(True, printers.table(
                ["NAME", "CPU(cores)", "CPU%", "MEMORY(bytes)", "MEMORY%"], rows),
                topic="observability")
        namespace = None if flag(flags, "-A", "--all-namespaces") else self.ns(flags)
        rows = []
        for pod in self.cluster.list("Pod", namespace):
            if deep_get(pod, "status.phase") != "Running":
                continue
            from .scheduler import pod_requests
            cpu, mem = pod_requests(pod)
            key = f'{deep_get(pod, "metadata.namespace")}/Deployment/' \
                  f'{str(deep_get(pod, "metadata.name")).rsplit("-", 2)[0]}'
            load = self.cluster.load.get(key, 25.0) / 100.0
            rows.append([deep_get(pod, "metadata.name"),
                         fmt_cpu(max(1, cpu * load) if cpu else 5 + 20 * load),
                         fmt_mem(max(8, mem * 0.6) if mem else 24)])
        return Result(True, printers.table(["NAME", "CPU(cores)", "MEMORY(bytes)"], rows),
                      topic="observability")

    def _kc_events(self, args, flags) -> Result:
        namespace = None if flag(flags, "-A", "--all-namespaces") else self.ns(flags)
        events = [e for e in self.cluster.events
                  if namespace is None or e.namespace == namespace][-40:]
        rows = [[fmt_age(self.cluster.tick - e.tick), e.type, e.reason, e.involved,
                 e.message] for e in events]
        return Result(True, printers.table(
            ["LAST SEEN", "TYPE", "REASON", "OBJECT", "MESSAGE"], rows),
            topic="troubleshooting")

    def _kc_certificate(self, args, flags) -> Result:
        ok, out = admin.certificate(self.cluster, args)
        return Result(ok, out if ok else "", "" if ok else out,
                      objects_changed=ok, topic="certificates")

    def _kc_auth(self, args, flags) -> Result:
        if not args or args[0] != "can-i":
            return Result(False, err="usage: kubectl auth can-i <verb> <resource>")
        verb = args[1] if len(args) > 1 else "get"
        resource = args[2] if len(args) > 2 else "pods"
        user = flag(flags, "--as", default=self.cluster.current_user)
        allowed = can_i(self.cluster, verb, resource, self.ns(flags), user)
        if flags.get("--list"):
            return Result(True, "Resources    Non-Resource URLs  Resource Names  Verbs\n"
                                "*.*          []                 []              [*]"
                          if allowed else "no permissions", topic="rbac")
        return Result(True, "yes" if allowed else "no", topic="rbac")

    def _kc_api_resources(self, args, flags) -> Result:
        rows = [[rk.plural, ",".join(rk.short), rk.api_version, str(rk.namespaced),
                 rk.kind] for rk in REGISTRY]
        return Result(True, printers.table(
            ["NAME", "SHORTNAMES", "APIVERSION", "NAMESPACED", "KIND"], rows),
            topic="architecture")

    def _kc_cluster_info(self, args, flags) -> Result:
        nodes = self.cluster.list("Node")
        pods = self.cluster.list("Pod")
        return Result(True,
                      f"Kubernetes control plane is running at https://127.0.0.1:6443 "
                      f"(simulated)\n"
                      f"CoreDNS is running at https://127.0.0.1:6443/api/v1/namespaces/"
                      f"kube-system/services/kube-dns:dns/proxy\n\n"
                      f"cluster: {self.cluster.name}\n"
                      f"nodes:   {len(nodes)}\n"
                      f"pods:    {len(pods)}\n"
                      f"tick:    {self.cluster.tick}", topic="architecture")

    def _kc_version(self, args, flags) -> Result:
        return Result(True, "Client Version: v1.30.2 (k8s-practice-lab simulator)\n"
                            "Server Version: v1.30.2 (simulated)")

    def _kc_config(self, args, flags) -> Result:
        if not args:
            return Result(False, err="usage: kubectl config [view|current-context|"
                                     "get-contexts|set-cluster|set-credentials|"
                                     "set-context|use-context]")
        if flag(flags, "-n") and not flags.get("--namespace"):
            flags["--namespace"] = flags["-n"]
        ok, out = admin.kubeconfig_command(self.cluster, args, flags)
        topic = "kubeconfig" if args[0] not in ("set-context", "use-context") \
            else ("namespaces" if flags.get("--namespace") else "kubeconfig")
        return Result(ok, out if ok else "", "" if ok else out, topic=topic)

    def _kc_wait(self, args, flags) -> Result:
        reconcile(self.cluster, 15)
        return Result(True, "condition met", topic="")

    def _kc_port_forward(self, args, flags) -> Result:
        return Result(True, "Forwarding from 127.0.0.1:8080 -> 80  (simulated)\n"
                            "Press Ctrl-C to stop", topic="services")

    def _kc_diff(self, args, flags) -> Result:
        path = flag(flags, "-f", "--filename")
        if not path:
            return Result(False, err="usage: kubectl diff -f file.yaml")
        out = []
        for doc in self._read_manifest(path):
            rk = resolve_kind(doc.get("kind", ""))
            if rk is None:
                continue
            live = self.cluster.get(rk.kind, deep_get(doc, "metadata.namespace")
                                    or self.ns(flags), deep_get(doc, "metadata.name"))
            if live is None:
                out.append(f"+ {rk.kind}/{deep_get(doc, 'metadata.name')} (new)")
                continue
            if live.get("spec") != doc.get("spec"):
                out.append(f"~ {rk.kind}/{deep_get(doc, 'metadata.name')} spec differs")
        return Result(True, "\n".join(out) or "no differences")

    # ------------------------------------------------------------------
    # helm (handbook page 45)
    # ------------------------------------------------------------------
    def helm(self, tokens: List[str]) -> Result:
        args, flags = parse_flags(tokens)
        if not args:
            return Result(True, "Usage: helm [install|upgrade|uninstall|list|template]")
        action = args[0]
        namespace = self.ns(flags)
        if action in ("install", "upgrade", "template"):
            if len(args) < 3:
                return Result(False, err=f"usage: helm {action} <release> <chart-dir>")
            release, chart = args[1], args[2]
            values = self._chart_values(chart, flags)
            docs = self._render_chart(chart, release, namespace, values)
            if action == "template":
                return Result(True, miniyaml.dump_all(docs), topic="helm")
            lines = []
            for doc in docs:
                doc.setdefault("metadata", {}).setdefault("labels", {}).update({
                    "app.kubernetes.io/managed-by": "Helm",
                    "helm.sh/release": release})
                doc["metadata"].setdefault("annotations", {})["meta.helm.sh/release-name"] \
                    = release
                lines.append(apply(self.cluster, doc))
            self.cluster.put({"apiVersion": "v1", "kind": "ConfigMap",
                              "metadata": {"name": f"sh.helm.release.v1.{release}",
                                           "namespace": namespace,
                                           "labels": {"owner": "helm",
                                                      "name": release,
                                                      "status": "deployed"},
                                           "annotations": {},
                                           "uid": self.cluster.next_uid(),
                                           "creationTick": self.cluster.tick},
                              "data": {"chart": chart,
                                       "revision": "1" if action == "install" else "2"},
                              "spec": {}, "status": {}})
            header = (f"NAME: {release}\nLAST DEPLOYED: tick {self.cluster.tick}\n"
                      f"NAMESPACE: {namespace}\nSTATUS: deployed\nREVISION: "
                      f"{'1' if action == 'install' else '2'}\n\nRESOURCES:")
            return Result(True, header + "\n" + "\n".join("  " + ln for ln in lines),
                          objects_changed=True, topic="helm")
        if action == "list":
            rows = []
            for cm in self.cluster.list("ConfigMap", namespace):
                if label(cm, "owner") == "helm":
                    rows.append([label(cm, "name"), namespace,
                                 deep_get(cm, "data.revision", "1"), "deployed",
                                 deep_get(cm, "data.chart", "")])
            return Result(True, printers.table(
                ["NAME", "NAMESPACE", "REVISION", "STATUS", "CHART"], rows) or
                "No releases found", topic="helm")
        if action == "uninstall":
            release = args[1]
            removed = 0
            for obj in list(self.cluster.all_objects()):
                if label(obj, "helm.sh/release") == release or \
                        label(obj, "name") == release:
                    rk = resolve_kind(obj.get("kind", ""))
                    if rk is None:
                        continue
                    self.cluster.delete(rk.kind,
                                        deep_get(obj, "metadata.namespace", ""),
                                        deep_get(obj, "metadata.name"))
                    removed += 1
            return Result(True, f'release "{release}" uninstalled ({removed} objects)',
                          objects_changed=True, topic="helm")
        if action == "repo":
            return Result(True, "\"lab\" has been added to your repositories",
                          topic="helm")
        return Result(False, err=f"unknown helm command {action}")

    def _chart_values(self, chart: str, flags) -> dict:
        base = {}
        chart_dir = self._find_dir(chart)
        values_path = os.path.join(chart_dir, "values.yaml")
        if os.path.isfile(values_path):
            with open(values_path, encoding="utf-8") as handle:
                base = miniyaml.load(handle.read()) or {}
        for path in flags.get("--values", []):
            _merge(base, miniyaml.load(self._open_text(path)) or {})
        for override in flags.get("--set", []):
            key, _, value = override.partition("=")
            cursor = base
            parts = key.split(".")
            for part in parts[:-1]:
                cursor = cursor.setdefault(part, {})
            cursor[parts[-1]] = _coerce(value)
        return base

    def _relative(self, path: str) -> str:
        """Turn a path we produced ourselves back into a base-relative one.

        `_find_dir` hands back absolute paths, and some code paths feed those
        straight back in. Rather than teach the sandbox to trust absolute input
        -- which is precisely the hole we are closing -- we relativise first and
        let it be re-validated like anything else.
        """
        if not os.path.isabs(path):
            return path
        try:
            relative = os.path.relpath(os.path.realpath(path), self.base_dir)
        except ValueError:
            raise ShellError(f'"{path}" is not inside the lab directory') from None
        if relative.startswith(".."):
            raise ShellError(f'"{path}" is not inside the lab directory')
        return relative

    def _find_dir(self, path: str) -> str:
        # Directories are resolved through the same sandbox as files, so
        # `helm install x ../../..` cannot walk out of the project.
        path = self._relative(path)
        for prefix in ("", "charts", "manifests"):
            candidate = os.path.join(prefix, path) if prefix else path
            try:
                full = security.safe_path(self.base_dir, candidate,
                                          extra_roots=self.extra_roots)
            except security.PathRefused as exc:
                raise ShellError(str(exc)) from None
            if os.path.isdir(full):
                return full
        raise ShellError(f'path "{path}" not found')

    def _render_chart(self, chart: str, release: str, namespace: str,
                      values: dict) -> List[dict]:
        chart_dir = self._find_dir(chart)
        templates = os.path.join(chart_dir, "templates")
        source_dir = templates if os.path.isdir(templates) else chart_dir
        docs = []
        for entry in sorted(os.listdir(source_dir))[:512]:
            if not entry.endswith((".yaml", ".yml")) or entry == "values.yaml":
                continue
            text = self._open_text(
                os.path.join(self._relative(source_dir), entry))
            text = _render_template(text, {"Release": {"Name": release,
                                                       "Namespace": namespace},
                                           "Chart": {"Name": os.path.basename(chart_dir)},
                                           "Values": values})
            for doc in miniyaml.load_all(text):
                rk = resolve_kind(doc.get("kind", ""))
                if rk and rk.namespaced:
                    doc.setdefault("metadata", {})["namespace"] = namespace
                docs.append(doc)
        return docs

    # ------------------------------------------------------------------
    # kustomize (handbook page 46)
    # ------------------------------------------------------------------
    def kustomize(self, tokens: List[str], apply_after: bool = False,
                  flags: Optional[dict] = None) -> Result:
        args, own_flags = parse_flags(tokens)
        flags = flags or own_flags
        if not args:
            return Result(False, err="usage: kustomize build <dir>")
        target = args[1] if len(args) > 1 else "."
        directory = self._find_dir(target)
        kfile = None
        for candidate in ("kustomization.yaml", "kustomization.yml"):
            if os.path.isfile(os.path.join(directory, candidate)):
                kfile = os.path.join(directory, candidate)
                break
        if kfile is None:
            return Result(False, err=f"unable to find kustomization.yaml in {target}")
        kustomization = miniyaml.load(self._open_text(self._relative(kfile))) or {}

        docs: List[dict] = []
        # `resources:` legitimately contains `../../base`, so relative parents
        # are allowed -- but the result is re-validated against the sandbox, so
        # `../../../../etc` is not.
        for resource in (kustomization.get("resources", []) or [])[:256]:
            path = self._relative(os.path.join(directory, str(resource)))
            if os.path.isdir(os.path.join(self.base_dir, path)):
                docs.extend(self.kustomize(["build", path]).objects)  # type: ignore
            else:
                docs.extend(self._read_manifest(path))

        name_prefix = kustomization.get("namePrefix", "")
        name_suffix = kustomization.get("nameSuffix", "")
        common_labels = kustomization.get("commonLabels", {}) or {}
        namespace = kustomization.get("namespace")
        images = {i.get("name"): i for i in kustomization.get("images", []) or []}

        for doc in docs:
            meta = doc.setdefault("metadata", {})
            meta["name"] = f"{name_prefix}{meta.get('name', '')}{name_suffix}"
            meta.setdefault("labels", {}).update(common_labels)
            if namespace and (resolve_kind(doc.get("kind", "")) or
                              type("x", (), {"namespaced": True})).namespaced:
                meta["namespace"] = namespace
            for path in ("spec.template.metadata.labels", "spec.selector.matchLabels"):
                node = doc
                parts = path.split(".")
                ok = True
                for part in parts[:-1]:
                    if isinstance(node, dict) and part in node:
                        node = node[part]
                    else:
                        ok = False
                        break
                if ok and isinstance(node, dict):
                    node.setdefault(parts[-1], {}).update(common_labels)
            containers = (deep_get(doc, "spec.template.spec.containers", []) or
                          deep_get(doc, "spec.containers", []) or [])
            for container in containers:
                image_name = str(container.get("image", "")).split(":")[0]
                if image_name in images:
                    entry = images[image_name]
                    new_name = entry.get("newName", image_name)
                    new_tag = entry.get("newTag")
                    container["image"] = f"{new_name}:{new_tag}" if new_tag else new_name
            for patch in kustomization.get("patches", []) or []:
                _apply_patch(doc, patch)

        if apply_after:
            lines = [apply(self.cluster, doc) for doc in docs]
            return Result(True, "\n".join(lines), objects_changed=True, topic="kustomize")
        result = Result(True, miniyaml.dump_all(docs), topic="kustomize")
        result.objects = docs        # type: ignore[attr-defined]
        return result

    # ------------------------------------------------------------------
    # cluster administration (kubeadm / etcdctl / docker)
    # ------------------------------------------------------------------
    def kubeadm(self, tokens: List[str]) -> Result:
        args, flags = parse_flags(tokens)
        ok, out = admin.kubeadm(self.cluster, args, flags)
        topic = "cluster-lifecycle"
        if args and args[0] == "certs":
            topic = "certificates"
        return Result(ok, out if ok else "", "" if ok else out,
                      objects_changed=ok, topic=topic)

    def etcdctl(self, tokens: List[str], env: Dict[str, str]) -> Result:
        args, flags = parse_flags(tokens)
        ok, out = admin.etcdctl(self.cluster, args, flags, env, self.base_dir)
        return Result(ok, out if ok else "", "" if ok else out,
                      objects_changed=ok, topic="etcd-backup")

    def docker(self, tokens: List[str]) -> Result:
        tokens = list(tokens)
        for index, token in enumerate(tokens):          # docker -t means --tag
            if token == "-t" and index + 1 < len(tokens):
                tokens[index] = "--tag"
        args, flags = parse_flags(tokens)
        ok, out = admin.docker(self.cluster, args, flags)
        return Result(ok, out if ok else "", "" if ok else out,
                      objects_changed=ok, topic="images")

    # ------------------------------------------------------------------
    # sim -- lab-only controls
    # ------------------------------------------------------------------
    def sim(self, tokens: List[str]) -> Result:
        args, flags = parse_flags(tokens)
        if not args:
            return Result(True, SIM_HELP)
        action = args[0]

        if action == "tick":
            return self._tick(int(args[1]) if len(args) > 1 else 1)
        if action == "reset":
            self.cluster = build_cluster(self.cluster.name)
            return Result(True, "cluster reset to a fresh 4-node lab cluster",
                          objects_changed=True)
        if action == "load":
            if len(args) < 3:
                return Result(False, err="usage: sim load deploy/<name> <cpu-percent>")
            rk, name = self._resolve_target([args[1]])
            percent = float(args[2])
            key = f"{self.ns(flags)}/{(rk.kind if rk else 'Deployment')}/{name}"
            self.cluster.load[key] = percent
            return Result(True, f"synthetic CPU load for {key} set to {percent:.0f}% "
                                "(HPA will react on the next ticks)",
                          objects_changed=True, topic="hpa")
        if action == "chaos":
            if len(args) < 3:
                return Result(False, err="usage: sim chaos <pod-or-app> "
                                         "<crash|oom|imagepull|notready|clear>")
            target, mode = args[1], args[2]
            key = f"{self.ns(flags)}/pod/{target}"
            if mode == "clear":
                self.cluster.chaos.pop(key, None)
                for pod in self.cluster.list("Pod", self.ns(flags)):
                    if deep_get(pod, "metadata.name") == target:
                        pod.setdefault("status", {})["restartCount"] = 0
                return Result(True, f"chaos cleared for {target}", objects_changed=True,
                              topic="troubleshooting")
            if mode not in ("crash", "oom", "imagepull", "notready"):
                return Result(False, err=f"unknown chaos mode {mode}")
            self.cluster.chaos[key] = mode
            return Result(True, f"injected {mode} failure into {target} -- now practise "
                                "`kubectl describe pod` and `kubectl logs`",
                          objects_changed=True, topic="troubleshooting")
        if action == "node":
            if len(args) < 3:
                return Result(False, err="usage: sim node <name> <down|up|add|remove>")
            name, mode = args[1], args[2]
            if mode == "add":
                add_node(self.cluster, name)
                return Result(True, f"node {name} added", objects_changed=True)
            node = self.cluster.get("Node", "", name)
            if node is None:
                return Result(False, err=f'nodes "{name}" not found')
            if mode == "down":
                node.setdefault("status", {})["ready"] = False
                for pod in list(self.cluster.list("Pod")):
                    if deep_get(pod, "spec.nodeName") == name:
                        owners = deep_get(pod, "metadata.ownerReferences", []) or []
                        if owners:
                            self.cluster.delete("Pod",
                                                deep_get(pod, "metadata.namespace"),
                                                deep_get(pod, "metadata.name"))
                        else:
                            pod.setdefault("status", {}).update(
                                {"phase": "Failed", "reason": "NodeLost"})
                self.cluster.record("Warning", "NodeNotReady",
                                    f"Node {name} status is now: NotReady",
                                    f"node/{name}", "default")
                return Result(True, f"node {name} marked NotReady -- watch the pods "
                                    "reschedule", objects_changed=True)
            if mode == "up":
                node.setdefault("status", {})["ready"] = True
                return Result(True, f"node {name} is Ready again", objects_changed=True)
            if mode == "remove":
                self.cluster.delete("Node", "", name)
                for pod in list(self.cluster.list("Pod")):
                    if deep_get(pod, "spec.nodeName") == name:
                        self.cluster.delete("Pod", deep_get(pod, "metadata.namespace"),
                                            deep_get(pod, "metadata.name"))
                return Result(True, f"node {name} removed", objects_changed=True)
        if action == "connectivity":
            namespace = self.ns(flags)
            port = int(args[1]) if len(args) > 1 and args[1].isdigit() else None
            names, grid = netpolicy.matrix(self.cluster, namespace, port)
            if not names:
                return Result(True, "no Running pods in this namespace yet",
                              topic="network-policies")
            width = max(len(n) for n in names) + 2
            header = " " * width + "  ".join(f"{n[:9]:^9}" for n in names)
            rows = [f"from \\ to".ljust(width) + header[width:]]
            for index, name in enumerate(names):
                cells = []
                for verdict in grid[index]:
                    cells.append(f"{'ALLOW' if verdict.allowed else 'DENY':^9}")
                rows.append(name.ljust(width) + "  ".join(cells))
            denied = [(names[i], names[j], grid[i][j].reason)
                      for i in range(len(names)) for j in range(len(names))
                      if not grid[i][j].allowed]
            if denied:
                rows.append("")
                rows.append("why:")
                seen = set()
                for src, dst, reason in denied:
                    if reason in seen:
                        continue
                    seen.add(reason)
                    rows.append(f"  {src} -> {dst}: {reason}")
            return Result(True, "\n".join(rows), topic="network-policies")
        if action == "age-certs":
            days = int(args[1]) if len(args) > 1 else 300
            admin.age_certificates(self.cluster, days)
            return Result(True, f"advanced every certificate {days} days -- run "
                                "`kubeadm certs check-expiration`",
                          topic="certificates")
        if action == "rbac":
            mode = args[1] if len(args) > 1 else "on"
            self.cluster.rbac_enforced = mode == "on"
            return Result(True, f"RBAC enforcement {'enabled' if mode == 'on' else 'disabled'}",
                          topic="rbac")
        if action == "user":
            self.cluster.current_user = args[1] if len(args) > 1 else "admin"
            return Result(True, f"acting as user {self.cluster.current_user}",
                          topic="authentication")
        if action == "save":
            path = args[1] if len(args) > 1 else "cluster-state.json"
            full = self._resolve(path, write=True)
            with open(full, "w", encoding="utf-8") as handle:
                json.dump(self.cluster.snapshot(), handle, indent=2, default=str)
            return Result(True, f"saved cluster state to {path}")
        if action == "load-state":
            path = args[1] if len(args) > 1 else "cluster-state.json"
            snapshot = json.loads(self._open_text(path, limit=8 * 1024 * 1024))
            self.cluster = build_cluster(self.cluster.name)
            self.cluster.objects.clear()
            for obj in snapshot["objects"]:
                self.cluster.put(obj)
            self.cluster.tick = snapshot.get("tick", 0)
            self.cluster.load = snapshot.get("load", {})
            self.cluster.chaos = snapshot.get("chaos", {})
            return Result(True, f"restored {len(snapshot['objects'])} objects",
                          objects_changed=True)
        return Result(False, err=f"unknown sim action {action}\n{SIM_HELP}")


# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------
def _deployment_object(name: str, namespace: str, image: str, replicas: int) -> dict:
    labels = {"app": name}
    return {"apiVersion": "apps/v1", "kind": "Deployment",
            "metadata": {"name": name, "namespace": namespace, "labels": labels},
            "spec": {"replicas": replicas, "selector": {"matchLabels": labels},
                     "template": {"metadata": {"labels": labels},
                                  "spec": {"containers": [
                                      {"name": name, "image": image,
                                       "ports": [{"containerPort": 80}],
                                       "resources": {
                                           "requests": {"cpu": "100m",
                                                        "memory": "128Mi"},
                                           "limits": {"cpu": "500m",
                                                      "memory": "256Mi"}}}]}}}}


def _merge(base: dict, patch: dict) -> dict:
    for key, value in (patch or {}).items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _merge(base[key], value)
        else:
            base[key] = value
    return base


def _coerce(text: str) -> Any:
    if text.lower() in ("true", "false"):
        return text.lower() == "true"
    try:
        return int(text)
    except ValueError:
        return text


def _apply_patch(doc: dict, patch: Any) -> None:
    if isinstance(patch, dict) and "patch" in patch:
        target = patch.get("target", {})
        if target.get("kind") and target["kind"] != doc.get("kind"):
            return
        body = patch["patch"]
        if isinstance(body, str):
            parsed = miniyaml.load(body)
            if isinstance(parsed, dict):
                _merge(doc, parsed)


_TEMPLATE_RE = re.compile(r"\{\{-?\s*([^}]+?)\s*-?\}\}")


def _render_template(text: str, context: dict) -> str:
    """Very small Go-template subset: {{ .Values.foo.bar | default "x" }}"""
    def resolve(expression: str) -> str:
        default = None
        if "|" in expression:
            expression, _, filt = expression.partition("|")
            expression = expression.strip()
            filt = filt.strip()
            match = re.match(r'default\s+"?([^"]*)"?', filt)
            if match:
                default = match.group(1)
        if expression.startswith("quote"):
            expression = expression.split(None, 1)[-1]
        cursor: Any = context
        for part in expression.strip().lstrip(".").split("."):
            if not part:
                continue
            if isinstance(cursor, dict) and part in cursor:
                cursor = cursor[part]
            else:
                return default if default is not None else ""
        if isinstance(cursor, bool):
            return "true" if cursor else "false"
        return str(cursor)

    return _TEMPLATE_RE.sub(lambda m: resolve(m.group(1)), text)


def _evict_untolerated(cluster: Cluster) -> None:
    from .scheduler import _tolerates
    for pod in list(cluster.list("Pod")):
        node_name = deep_get(pod, "spec.nodeName")
        if not node_name:
            continue
        node = cluster.get("Node", "", node_name)
        if node is None:
            continue
        for taint in deep_get(node, "spec.taints", []) or []:
            if taint.get("effect") == "NoExecute" and not _tolerates(pod, taint):
                cluster.delete("Pod", deep_get(pod, "metadata.namespace"),
                               deep_get(pod, "metadata.name"))
                cluster.record("Warning", "TaintManagerEviction",
                               f"Evicting pod {deep_get(pod, 'metadata.name')} due to "
                               f"NoExecute taint {taint.get('key')}",
                               f"pod/{deep_get(pod, 'metadata.name')}",
                               deep_get(pod, "metadata.namespace", "default"))


def _fake_logs(cluster: Cluster, pod: dict) -> str:
    name = deep_get(pod, "metadata.name")
    reason = deep_get(pod, "status.reason", "")
    image = deep_get(pod, "spec.containers.0.image", "app")
    if reason == "ImagePullBackOff":
        return (f'Error from server (BadRequest): container "'
                f'{deep_get(pod, "spec.containers.0.name")}" in pod "{name}" is waiting '
                f"to start: trying and failing to pull image {image}")
    if reason == "CrashLoopBackOff":
        return "\n".join([
            f"[{name}] starting {image}",
            f"[{name}] FATAL: could not connect to database: connection refused",
            f"[{name}] exiting with code 1",
            "",
            f"(restart #{deep_get(pod, 'status.restartCount', 1)} -- "
            "add `--previous` on a real cluster to read the crashed container's logs)"])
    if reason == "OOMKilled":
        return (f"[{name}] allocating buffers...\n[{name}] allocating buffers...\n"
                "Killed (exit 137: the container exceeded resources.limits.memory)")
    if deep_get(pod, "status.phase") == "Succeeded":
        return f"[{name}] work item processed\n[{name}] done, exiting 0"
    if deep_get(pod, "status.phase") != "Running":
        return f'Error from server: pod "{name}" is not running (status: ' \
               f'{deep_get(pod, "status.phase")})'
    return "\n".join([
        f"[{name}] {image} started, listening on :80",
        f"[{name}] GET /healthz 200 0.4ms",
        f"[{name}] GET / 200 1.2ms",
        f"[{name}] GET /metrics 200 2.1ms"])


def _fake_exec(cluster: Cluster, pod: dict, command: List[str]) -> str:
    ns = deep_get(pod, "metadata.namespace", "default")
    joined = " ".join(command) if command else "sh"
    if joined.startswith("env"):
        lines = [f"HOSTNAME={deep_get(pod, 'metadata.name')}", "PATH=/usr/local/bin:/bin"]
        for container in deep_get(pod, "spec.containers", []) or []:
            for entry in container.get("env", []) or []:
                value = entry.get("value")
                if value is None:
                    ref = entry.get("valueFrom", {}) or {}
                    if "configMapKeyRef" in ref:
                        cm = cluster.get("ConfigMap", ns,
                                         deep_get(ref, "configMapKeyRef.name"))
                        value = (cm or {}).get("data", {}).get(
                            deep_get(ref, "configMapKeyRef.key"), "<missing>")
                    elif "secretKeyRef" in ref:
                        secret = cluster.get("Secret", ns,
                                             deep_get(ref, "secretKeyRef.name")) or {}
                        key = deep_get(ref, "secretKeyRef.key")
                        if key in (secret.get("stringData") or {}):
                            value = secret["stringData"][key]
                        else:
                            raw = (secret.get("data") or {}).get(key, "")
                            try:
                                value = base64.b64decode(str(raw)).decode()
                            except Exception:
                                value = str(raw)
                lines.append(f"{entry.get('name')}={value}")
            for source in container.get("envFrom", []) or []:
                cm = cluster.get("ConfigMap", ns, deep_get(source, "configMapRef.name"))
                for key, value in ((cm or {}).get("data") or {}).items():
                    lines.append(f"{key}={value}")
        for svc in cluster.list("Service", ns):
            upper = str(deep_get(svc, "metadata.name")).upper().replace("-", "_")
            lines.append(f"{upper}_SERVICE_HOST={deep_get(svc, 'spec.clusterIP')}")
        return "\n".join(lines)
    if joined.startswith(("cat ", "ls ")):
        path = joined.split(None, 1)[1].strip()
        for volume in deep_get(pod, "spec.volumes", []) or []:
            cm_name = deep_get(volume, "configMap.name")
            if not cm_name:
                continue
            for container in deep_get(pod, "spec.containers", []) or []:
                for mount in container.get("volumeMounts", []) or []:
                    if mount.get("name") != volume.get("name"):
                        continue
                    base = str(mount.get("mountPath", "")).rstrip("/")
                    cm = cluster.get("ConfigMap", ns, cm_name) or {}
                    if joined.startswith("ls") and path.rstrip("/") == base:
                        return "\n".join((cm.get("data") or {}).keys())
                    if path.startswith(base + "/"):
                        key = path[len(base) + 1:]
                        return str((cm.get("data") or {}).get(key, f"cat: {path}: "
                                                                   "No such file"))
        return f"cat: {path}: No such file or directory"
    if joined.startswith(("curl", "wget")):
        target = command[-1] if command else ""
        raw = re.sub(r"^https?://", "", target).split("/")[0]
        host, _, port_text = raw.partition(":")
        host = host.split(".")[0]
        port = int(port_text) if port_text.isdigit() else None

        svc = cluster.get("Service", ns, host)
        peer = None
        if svc is not None:
            endpoints = deep_get(svc, "status.endpoints", []) or []
            if not endpoints:
                return (f"curl: (7) Failed to connect to {host}: no endpoints behind "
                        "this Service -- check `kubectl get endpoints` and your "
                        "selector")
            peer = cluster.get("Pod", ns, endpoints[0].get("targetRef"))
            if port is None:
                ports = deep_get(svc, "spec.ports", []) or []
                port = int(deep_get(ports[0], "targetPort", 80)) if ports else 80
        else:
            peer = cluster.get("Pod", ns, host)
            if peer is None:
                return f"curl: (6) Could not resolve host: {host}"

        verdict = netpolicy.evaluate(cluster, pod, peer, port)
        if not verdict.allowed:
            return (f"curl: (28) Failed to connect to {host} port {port or 80}: "
                    "Connection timed out\n\n"
                    f"(NetworkPolicy: {verdict.reason})")
        if svc is None:
            return (f"<!DOCTYPE html><html><body><h1>Hello from "
                    f"{deep_get(peer, 'metadata.name')}</h1>\n"
                    f"direct pod IP {deep_get(peer, 'status.podIP')}"
                    f"</body></html>\n\n(allowed: {verdict.reason})")
        endpoints = deep_get(svc, "status.endpoints", []) or []
        return (f"<!DOCTYPE html><html><body><h1>Hello from "
                f"{endpoints[0].get('targetRef')}</h1>\n"
                f"served by Service {host} ({deep_get(svc, 'spec.clusterIP')}), "
                f"{len(endpoints)} endpoint(s) load balanced</body></html>"
                + (f"\n\n(allowed: {verdict.reason})"
                   if cluster.list("NetworkPolicy", ns) else ""))
    if joined.startswith("nslookup"):
        host = command[-1]
        svc = cluster.get("Service", ns, host.split(".")[0])
        if svc is None:
            return f"** server can't find {host}: NXDOMAIN"
        return (f"Server:    10.96.0.10\nAddress 1: 10.96.0.10 kube-dns.kube-system\n\n"
                f"Name:      {host}.{ns}.svc.cluster.local\n"
                f"Address 1: {deep_get(svc, 'spec.clusterIP')}")
    if joined in ("sh", "bash", "/bin/sh", "/bin/bash"):
        return (f"# (simulated shell inside {deep_get(pod, 'metadata.name')})\n"
                "# try: kubectl exec <pod> -- env | cat <file> | curl <svc> | nslookup <svc>")
    return f"$ {joined}\n(simulated: this command produced no output)"


HELP_TEXT = """k8s-practice-lab -- supported commands

kubectl:
  get / describe / explain / api-resources / cluster-info / version / events
  apply -f FILE|DIR      apply -k DIR        create ...        delete ...
  run / expose / scale / autoscale / set image
  rollout status|history|undo|restart        patch -p '{...}'
  label / annotate / taint / cordon / uncordon / drain
  logs / exec / top pods|nodes / auth can-i / config set-context
helm:      install | upgrade | uninstall | list | template | repo add
kustomize: build DIR      (or: kubectl apply -k DIR)
sim:       lab-only controls -- run `sim` on its own for the list
Type a topic name (e.g. `explain pods`) to pull the handbook page up beside you."""

SIM_HELP = """sim -- lab controls (not real kubectl)

  sim tick [n]                    advance the control loop n iterations
  sim reset                       rebuild a fresh 4-node cluster
  sim load deploy/<name> <pct>    set synthetic CPU load -> drives the HPA
  sim chaos <pod|app> <mode>      crash | oom | imagepull | notready | clear
  sim node <name> down|up|add|remove
  sim rbac on|off                 turn RBAC enforcement on (then `sim user bob`)
  sim user <name>                 act as a different user
  sim save [file] / sim load-state [file]"""
