"""Security choke points for the whole application.

Every dangerous primitive the lab needs -- opening a file whose name came from
outside, deciding whether an HTTP request may be served, capping how much work
one request can cause -- goes through this module, so the controls live in one
auditable place instead of being re-implemented (and forgotten) per call site.

Design principles applied here:

* **secure by default** -- the safe behaviour needs no configuration; the unsafe
  one needs an explicit, loud opt-in.
* **least privilege** -- the shell may only touch files inside the project
  directory, and only the extensions it actually uses.
* **defence in depth** -- the same request is checked for a valid token, a
  trusted Host, a trusted Origin and a sane Content-Type; no single check is
  load-bearing on its own.
* **fail closed** -- anything unparsable, oversized or ambiguous is rejected.

Vulnerability classes addressed (CWE / OWASP Top 10 2021):

    CWE-22   path traversal ................... safe_path, safe_name
    CWE-23   relative path traversal .......... safe_path
    CWE-59   link following .................. safe_path (realpath)
    CWE-73   external control of filename ..... safe_path
    CWE-78   OS command injection ............ shell_quote, LIVE_DENY_FLAGS
    CWE-79   cross-site scripting ............ json_for_script
    CWE-306  missing authentication .......... token / require_token
    CWE-350  reliance on reverse DNS ......... host_allowed (DNS rebinding)
    CWE-352  cross-site request forgery ...... origin_allowed, JSON_CONTENT_TYPE
    CWE-400  uncontrolled resource use ....... MAX_*, RateLimiter
    CWE-406  amplification ................... RateLimiter
    CWE-409  decompression bomb .............. MAX_ARCHIVE_BYTES
    CWE-497  exposure of system data ......... SERVER_TOKEN, generic errors
    CWE-524  cacheable sensitive response .... NO_STORE
    CWE-674  uncontrolled recursion .......... MAX_YAML_DEPTH
    CWE-1021 clickjacking .................... SECURITY_HEADERS (frame-ancestors)
    CWE-1327 binding to every interface ...... LOOPBACK_HOSTS, is_loopback

    A01 broken access control, A02 cryptographic failures (token entropy),
    A03 injection, A04 insecure design, A05 security misconfiguration,
    A07 identification/authentication failures, A08 software & data integrity.
"""
from __future__ import annotations

import hmac
import ipaddress
import os
import re
import secrets
import shlex
import threading
import time
from typing import Dict, Iterable, Optional, Tuple

# ---------------------------------------------------------------------------
# 1. resource ceilings  (CWE-400, CWE-409, CWE-674, CWE-770)
#
# Every one of these is a "how much can a single request cost me" limit. They
# are deliberately generous for a teaching tool and deliberately finite.
# ---------------------------------------------------------------------------
MAX_REQUEST_BYTES = 1 * 1024 * 1024        # POST body
MAX_YAML_BYTES = 512 * 1024                # one manifest
MAX_YAML_LINES = 20_000
MAX_YAML_DEPTH = 64                        # recursion guard for the parser
MAX_COMMAND_CHARS = 4_096                  # one shell line
MAX_COMMANDS_PER_BATCH = 200               # /api/run-many
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024       # any zip we build or read
MAX_ARCHIVE_MEMBERS = 5_000
MAX_LOG_ENTRIES = 4_000
MAX_UPLOAD_PATH = 255
SUBPROCESS_TIMEOUT = 60                    # live mode
DOCKER_TIMEOUT = 1_800                     # image builds are slow

# ---------------------------------------------------------------------------
# 2. filesystem containment  (CWE-22, CWE-23, CWE-59, CWE-73)
# ---------------------------------------------------------------------------

#: Extensions the lab is ever allowed to read from disk on request.
READABLE_SUFFIXES = (".yaml", ".yml", ".json", ".kubectl", ".txt", ".md",
                     ".tpl", ".png", ".svg", ".properties", ".conf", ".env")

#: Extensions the lab is ever allowed to write.
WRITABLE_SUFFIXES = (".yaml", ".yml", ".json", ".svg", ".html", ".txt")

#: A single path segment: no separators, no dots-only, no control characters.
SAFE_SEGMENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

#: Names of the handbook page images.
PAGE_IMAGE = re.compile(r"^page_\d{1,3}\.(png|jpg|jpeg|webp)$")

#: Lab script file names.
LAB_FILE = re.compile(r"^[0-9]{2}-[a-z0-9-]{1,60}\.kubectl$")

#: Handbook topic keys and diagram keys.
TOPIC_KEY = re.compile(r"^[a-z0-9][a-z0-9_-]{0,60}$")


class PathRefused(ValueError):
    """Raised when a requested path escapes its sandbox."""


def safe_name(name: str, pattern: re.Pattern) -> Optional[str]:
    """Return *name* only if it matches *pattern* exactly.

    Used for the routes that take an identifier from the URL. Matching an
    allowlist is the only file-name check that cannot be tricked by encoding:
    ``%2e%2e%2f``, ``..\\``, NUL bytes and unicode look-alikes all simply fail
    to match.
    """
    if not isinstance(name, str) or len(name) > MAX_UPLOAD_PATH:
        return None
    if "\x00" in name:
        return None
    return name if pattern.fullmatch(name) else None


def safe_path(base: str, candidate: str, *, write: bool = False,
              must_exist: bool = False,
              extra_roots: Iterable[str] = ()) -> str:
    """Resolve *candidate* and prove it stays inside *base*.

    This is the single gate for every file the simulated shell touches.

    It defeats, in order:

    * absolute paths -- ``os.path.join('/app', '/etc/passwd')`` silently
      discards ``/app``, which is exactly how "join with a base directory"
      becomes an arbitrary-file bug, so absolute input is rejected outright;
    * ``..`` traversal, including mixed separators on Windows;
    * symlinks pointing outside the sandbox (we compare *real* paths);
    * NUL-byte and control-character truncation tricks;
    * unexpected file types -- only the suffixes above are allowed.

    :param extra_roots: additional directories that are also acceptable, e.g.
        an explicitly chosen state directory.
    """
    if not isinstance(candidate, str) or not candidate:
        raise PathRefused("empty path")
    if "\x00" in candidate or any(ord(ch) < 32 for ch in candidate):
        raise PathRefused("path contains control characters")
    if len(candidate) > 1024:
        raise PathRefused("path is unreasonably long")

    normalised = candidate.replace("\\", "/")
    if os.path.isabs(candidate) or os.path.isabs(normalised) or \
            re.match(r"^[A-Za-z]:", candidate):
        raise PathRefused(f'absolute paths are not allowed here: "{candidate}"')
    if normalised.startswith("~"):
        raise PathRefused("home-relative paths are not allowed here")

    roots = [os.path.realpath(base)] + [os.path.realpath(r) for r in extra_roots]
    target = os.path.realpath(os.path.join(roots[0], candidate))

    inside = False
    for root in roots:
        try:
            if os.path.commonpath([root, target]) == root:
                inside = True
                break
        except ValueError:                      # different drive on Windows
            continue
    if not inside:
        raise PathRefused(
            f'"{candidate}" resolves outside the lab directory. Paths must stay '
            "inside the project so a lab script can never read or overwrite "
            "the rest of your machine.")

    suffixes = WRITABLE_SUFFIXES if write else READABLE_SUFFIXES
    if os.path.splitext(target)[1].lower() not in suffixes and \
            not os.path.isdir(target):
        raise PathRefused(
            f'"{candidate}" has a file type this lab does not handle '
            f"(allowed: {', '.join(suffixes)})")

    if must_exist and not os.path.exists(target):
        raise PathRefused(f'the path "{candidate}" does not exist')
    return target


# ---------------------------------------------------------------------------
# 3. shell generation  (CWE-78, CWE-88)
# ---------------------------------------------------------------------------

#: Flags that turn a "read-only" CLI into an arbitrary-code-execution primitive.
#: helm's post-renderer runs any binary you name; kubectl's plugin loader and
#: exec credential plugins do the same, as does a kubeconfig you did not write.
LIVE_DENY_FLAGS = (
    "--post-renderer", "--post-renderer-args", "--kubeconfig", "--plugin",
    "--as-group", "--token", "--client-key", "--client-certificate",
    "--password", "--server", "--tls-server-name", "--insecure-skip-tls-verify",
)

#: Programs live mode may hand to the operating system, and nothing else.
LIVE_PROGRAMS = ("kubectl", "helm", "kustomize", "kubeadm", "etcdctl", "docker")


def shell_quote(value: str) -> str:
    """POSIX-quote a value that is about to be written into a generated script.

    Everything the exporter interpolates -- namespaces, image names, hostnames,
    registry paths -- is quoted here, so a value containing ``;`` or ``$(...)``
    lands in the script as data instead of as a command substitution.
    """
    return shlex.quote(str(value))


def live_command_refusal(tokens) -> Optional[str]:
    """Explain why a live (real-cluster) command must not run, or return None.

    Live mode is the only place the lab hands anything to the real operating
    system, so it gets its own allowlist even though the caller has already
    authenticated.
    """
    if not tokens:
        return "empty command"
    if tokens[0] not in LIVE_PROGRAMS:
        return f"{tokens[0]} is not one of: {', '.join(LIVE_PROGRAMS)}"
    for token in tokens[1:]:
        head = token.split("=", 1)[0]
        if head in LIVE_DENY_FLAGS:
            return (f"{head} is refused in live mode: it can point the CLI at "
                    "another cluster or make it execute an arbitrary binary. "
                    "Run that command yourself in a terminal if you mean it.")
        if "\x00" in token:
            return "argument contains a NUL byte"
    return None


# ---------------------------------------------------------------------------
# 4. HTTP: identity, origin, headers  (CWE-306, CWE-352, CWE-350, CWE-1021)
# ---------------------------------------------------------------------------

#: 256 bits from the OS CSPRNG, regenerated every time the server starts.
def new_token() -> str:
    return secrets.token_urlsafe(32)


def token_matches(expected: str, presented: Optional[str]) -> bool:
    """Constant-time comparison, so the token cannot be guessed byte by byte."""
    if not expected:
        return True                              # token disabled (tests)
    if not presented:
        return False
    return hmac.compare_digest(expected, presented)


LOOPBACK_HOSTS = frozenset({"localhost", "127.0.0.1", "::1", "[::1]",
                            "0:0:0:0:0:0:0:1"})


def is_loopback(address: str) -> bool:
    host = (address or "").strip().strip("[]")
    if host in LOOPBACK_HOSTS or host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def host_allowed(host_header: Optional[str], port: int,
                 extra: Iterable[str] = ()) -> bool:
    """Reject a request whose Host header is not one we serve on.

    This is the DNS-rebinding control (CWE-350). Without it, a page on
    ``evil.example`` can re-point its own hostname at 127.0.0.1 and then read
    the lab's responses, because to the browser it is still same-origin with
    ``evil.example``. Checking Host means such a request arrives labelled
    ``Host: evil.example`` and is refused.
    """
    if not host_header:
        return False
    name = host_header.rsplit(":", 1)[0] if not host_header.startswith("[") \
        else host_header.split("]")[0] + "]"
    allowed = set(LOOPBACK_HOSTS) | {f"127.0.0.1:{port}", f"localhost:{port}"}
    allowed |= {e.lower() for e in extra}
    return host_header.lower() in allowed or name.lower() in allowed \
        or is_loopback(name)


def origin_allowed(origin: Optional[str], referer: Optional[str],
                   fetch_site: Optional[str], port: int) -> bool:
    """Cross-origin request forgery check (CWE-352).

    Three independent signals, any one of which is enough to accept and any one
    of which is enough to refuse:

    * ``Sec-Fetch-Site`` -- set by every current browser, cannot be forged by
      page script; ``same-origin`` and ``none`` (typed in the address bar) pass.
    * ``Origin`` -- must be a loopback origin on our port.
    * ``Referer`` -- fallback for the handful of clients without the above.

    Non-browser clients (curl, the test suite) send none of them and are
    accepted, because they cannot be driven by a hostile web page -- they still
    need the session token.
    """
    if fetch_site in ("same-origin", "none"):
        return True
    if fetch_site in ("cross-site", "same-site"):
        return False
    for value in (origin, referer):
        if not value:
            continue
        try:
            from urllib.parse import urlparse
            parsed = urlparse(value)
        except ValueError:
            return False
        if not is_loopback(parsed.hostname or ""):
            return False
        if parsed.port and parsed.port != port:
            return False
    return True


JSON_CONTENT_TYPE = "application/json"

#: Content-Security-Policy. ``script-src`` carries a per-response nonce and no
#: ``unsafe-inline``, so injected markup cannot execute even if it reaches the
#: DOM. ``connect-src 'self'`` and ``img-src 'self' data:`` mean a successful
#: injection still has nowhere to send what it steals. ``frame-ancestors 'none'``
#: is the clickjacking control (CWE-1021), ``base-uri``/``form-action`` close the
#: two classic CSP bypasses.
CSP_TEMPLATE = (
    "default-src 'none'; "
    "script-src 'nonce-{nonce}'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob:; "
    "font-src 'self'; "
    "connect-src 'self'; "
    "form-action 'none'; "
    "frame-ancestors 'none'; "
    "base-uri 'none'; "
    "object-src 'none'; "
    "worker-src 'none'; "
    "manifest-src 'none'; "
    "upgrade-insecure-requests"
)

#: Sent on every response. Values chosen to match the OWASP Secure Headers
#: project's baseline for a same-origin single-page application.
SECURITY_HEADERS: Dict[str, str] = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Cross-Origin-Embedder-Policy": "require-corp",
    "Permissions-Policy": ("accelerometer=(), autoplay=(), camera=(), "
                           "display-capture=(), encrypted-media=(), "
                           "geolocation=(), gyroscope=(), magnetometer=(), "
                           "microphone=(), midi=(), payment=(), "
                           "publickey-credentials-get=(), screen-wake-lock=(), "
                           "serial=(), usb=(), xr-spatial-tracking=()"),
    "X-Permitted-Cross-Domain-Policies": "none",
}

NO_STORE = "no-store, no-cache, must-revalidate, private"

#: Deliberately uninformative: the version of the server is not the client's
#: business (CWE-200).
SERVER_TOKEN = "k8s-practice-lab"


def new_nonce() -> str:
    return secrets.token_urlsafe(16)


def json_for_script(payload: str) -> str:
    """Make a JSON literal safe to embed inside a ``<script>`` element.

    ``</script>`` inside a string ends the element as far as the HTML parser is
    concerned, which turns any embedded data into markup (CWE-79). The line and
    paragraph separators are escaped because they are literal line breaks in
    JavaScript source but not in JSON.
    """
    return (payload.replace("<", "\\u003c").replace(">", "\\u003e")
                   .replace("&", "\\u0026").replace("\u2028", "\\u2028")
                   .replace("\u2029", "\\u2029"))


# ---------------------------------------------------------------------------
# 5. rate limiting  (CWE-400 / CWE-770, OWASP API4 unrestricted consumption)
# ---------------------------------------------------------------------------
class RateLimiter:
    """A tiny token bucket, per (client, bucket-name).

    Guards the endpoints where one cheap request causes expensive work: zip
    building, whole-cluster SVG rendering, and the docker driver.
    """

    def __init__(self, capacity: int, per_seconds: float):
        self.capacity = capacity
        self.per_seconds = per_seconds
        self._buckets: Dict[str, Tuple[float, float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        with self._lock:
            tokens, last = self._buckets.get(key, (float(self.capacity), now))
            tokens = min(self.capacity,
                         tokens + (now - last) * self.capacity / self.per_seconds)
            if tokens < 1.0:
                self._buckets[key] = (tokens, now)
                return False
            self._buckets[key] = (tokens - 1.0, now)
            if len(self._buckets) > 4096:        # bound our own memory too
                self._buckets.clear()
            return True


# ---------------------------------------------------------------------------
# 6. redaction for logs  (CWE-532 insertion of sensitive information into logs)
# ---------------------------------------------------------------------------
_SECRET_PATTERNS = (
    re.compile(r"(--(?:token|password|client-key|secret)[= ])(\S+)", re.I),
    re.compile(r"((?:api[_-]?key|passwd|password|secret|token)\s*[=:]\s*)(\S+)", re.I),
    re.compile(r"(Authorization:\s*Bearer\s+)(\S+)", re.I),
    re.compile(r"(eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})\.[A-Za-z0-9_-]+"),
)


def redact(text: str) -> str:
    """Strip anything that looks like a credential before it is written down.

    The lab's own Secrets are fake, but the exported transcript is a file people
    paste into issues and chat, and live mode can put real flags in it.
    """
    out = str(text)
    for pattern in _SECRET_PATTERNS[:-1]:
        out = pattern.sub(lambda m: m.group(1) + "***redacted***", out)
    out = _SECRET_PATTERNS[-1].sub(r"\1.***redacted***", out)
    return out
